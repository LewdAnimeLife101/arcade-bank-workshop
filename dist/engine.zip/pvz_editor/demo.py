"""Synthetic samples; no private bank or account data."""
import xml.etree.ElementTree as ET
from .core import load_profile, signature_for, NAMES

def demo_bytes(name='ProbesvZealot2'):
    profile=load_profile();fields=profile['fields'] if name==NAMES[0] else profile['companion_fields'][name]
    root=ET.Element('Bank',version='1');sections={}
    for spec in fields:
        section=sections.get(spec['section'])
        if section is None:section=ET.SubElement(root,'Section',name=spec['section']);sections[spec['section']]=section
        kind='flag' if spec['type']=='bool' else spec['type']
        value=spec.get('default','' if kind in ('string','text') else 0)
        if spec['bank_key']=='PlayerHandle':value='1-S2-1-1234567'
        if spec['bank_key']=='PlayerName':value='Synthetic example'
        if spec['bank_key']=='Rank':value='D-'
        key=ET.SubElement(section,'Key',name=spec['bank_key'])
        ET.SubElement(key,'Value',**{kind:str(int(value)) if kind=='flag' else str(value)})
    if name!=NAMES[2]:ET.SubElement(root,'Signature',value=signature_for(root,'1-S2-1-1234567','1-S2-1-7654321',name))
    return ET.tostring(root,encoding='utf-8',xml_declaration=True)
