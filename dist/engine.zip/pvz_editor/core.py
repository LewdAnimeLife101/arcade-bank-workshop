"""Source-derived Probes vs Zealot 2.118 progression and preference banks.

Native text leaves are retained verbatim but contribute an empty string to
signature value canonicalization. Corroborated against the observed main bank;
ordinary primitive signing also matched its companion options bank.
"""
from dataclasses import dataclass
from pathlib import Path
from importlib import resources
import copy, hashlib, json, re
import xml.etree.ElementTree as ET
from zrc_editor.common import BankError
from zwl_editor.fixed import parse_fixed, format_fixed

NAMES=('ProbesvZealot2','PvsZ2GameplayOptions','PvZ2Options2')
HANDLE=re.compile(r'\d+-S2-\d+-\d+')

def load_profile():
    return json.loads(resources.files('pvz_editor').joinpath('map_profile.json').read_text(encoding='utf-8'))

@dataclass(eq=True)
class State:
    values:dict
    def clone(self):return copy.deepcopy(self)

def inspect_root(root):
    if root.tag!='Bank' or root.attrib!={'version':'1'} or (root.text or '').strip():raise BankError('Expected a version 1 Bank document.')
    sections={};nodes={};signature=None
    for section in root:
        if not isinstance(section.tag,str):continue
        if (section.tail or '').strip():raise BankError('Unexpected bank text.')
        if section.tag=='Signature':
            if signature is not None or set(section.attrib)!={'value'} or not re.fullmatch('[0-9A-Fa-f]{40}',section.get('value','')) or len(section) or (section.text or '').strip():raise BankError('Malformed or duplicate signature.')
            signature=section;continue
        if section.tag!='Section' or set(section.attrib)!={'name'} or not section.get('name') or section.get('name') in sections or (section.text or '').strip():raise BankError('Malformed or duplicate section.')
        sections[section.get('name')]=section
        for node in section:
            if not isinstance(node.tag,str):continue
            pair=section.get('name'),node.get('name')
            if node.tag!='Key' or set(node.attrib)!={'name'} or not node.get('name') or pair in nodes or (node.text or '').strip() or (node.tail or '').strip():raise BankError('Malformed or duplicate key.')
            leaves=[x for x in node if isinstance(x.tag,str)]
            if len(leaves)!=1 or leaves[0].tag!='Value':raise BankError('Only primitive Value records are supported for this profile.')
            leaf=leaves[0]
            if len(leaf.attrib)!=1 or len(leaf) or (leaf.text or '').strip() or (leaf.tail or '').strip():raise BankError('Malformed primitive value.')
            kind,value=next(iter(leaf.attrib.items()))
            decode(kind,value)
            nodes[pair]=node
    return sections,nodes,signature

def decode(kind,value):
    if kind in ('string','text'):return value
    if kind=='int':
        if not re.fullmatch(r'-?\d+',value):raise BankError('Invalid bank integer.')
        n=int(value)
        if not -2147483648<=n<=2147483647:raise BankError('Bank integer exceeds signed 32-bit storage.')
        return n
    if kind=='fixed':return parse_fixed(value)
    if kind=='flag' and value in ('0','1'):return value=='1'
    raise BankError('Unsupported or malformed primitive value.')

def signature_for(root,player,author,name):
    if not HANDLE.fullmatch(player or '') or not HANDLE.fullmatch(author or ''):raise BankError('Original account and map-author handles are required.')
    if name not in NAMES:raise BankError('Unsupported exact bank name.')
    sections,nodes,_=inspect_root(root);parts=[author,player,name]
    for section in sorted(sections):
        parts.append(section)
        for pair in sorted(x for x in nodes if x[0]==section):
            leaf=nodes[pair].find('Value');kind,value=next(iter(leaf.attrib.items()))
            parts.extend([pair[1],'Value',kind,'' if kind=='text' else value])
    payload=''.join(parts)
    if not payload.isascii():raise BankError('Non-ASCII primitive signing content remains outside the corroborated codec scope.')
    return hashlib.sha1(payload.encode('ascii')).hexdigest().upper()

def matches_structure(root):
    sections={x.get('name'):{k.get('name') for k in x.findall('Key')} for x in root.findall('Section')}
    main={'HumanStats','VampireStats','TotalStats','PlayerInfo'}.issubset(sections) and 'PlayerHandle' in sections['PlayerInfo']
    old={'GameplayOptions','PlayerOptions'}.issubset(sections) and {'AutoCastRepairAbility','SaveProbeSkin'}.issubset(sections['GameplayOptions'])
    new={'Night','Vespene','ProbeBuildingSkin','ProbeSpiritName'}.issubset(sections.get('Options',set()))
    return sum((main,old,new))==1

def rank(points):
    return 'S-'+str((points-12000)//1000+1) if points>=12000 else ['D-','D','D+','C-','C','C+','B-','B','B+','A-','A','A+'][max(0,points)//1000]

def level_xp(level):return 0 if level==0 else 100+50*level*(level-1)

def loader_checks(values):
    for section in ['HumanStats','VampireStats','TotalStats']:
        points,wins,losses,games=(values[section+'/'+k] for k in ['Points','Wins','Losses','Games'])
        if points>=501000:raise BankError(f'{section}: map rejects rank points of 501,000 or more.')
        if wins>0 and (points-1000)//wins>375:raise BankError(f'{section}: rank points require more wins. The map checks (Points - 1000) / Wins <= 375.')
        if min(wins,losses,games)<0 or games-wins-losses not in (0,1):raise BankError(f'{section}: Games must equal Wins + Losses, optionally plus one unfinished match.')

def validate(state,profile,before=None):
    specs={x['key']:x for x in profile['fields']}
    if set(state.values)!=set(specs):raise BankError('Incomplete or unexpected editor state.')
    for key,spec in specs.items():
        value=state.values[key]
        if before is not None and value==before.values[key]:continue
        kind=spec['type']
        if not spec.get('editable',True) and before is not None:
            section=spec['section']
            if spec['bank_key']=='Games' and section in ('HumanStats','VampireStats','TotalStats'):
                # An earlier preview may already have populated this derived
                # value. It is always overwritten from the new edited inputs.
                if any(state.values[section+'/'+k]!=before.values[section+'/'+k] for k in ('Wins','Losses')):continue
            if spec['bank_key']=='Rank' and section in ('HumanStats','VampireStats','TotalStats') and state.values[section+'/Points']!=before.values[section+'/Points']:continue
            raise BankError(spec['label']+': this field is derived or read-only.')
        if kind=='bool':
            if type(value)!=bool:raise BankError(spec['label']+': expected an on/off value.')
        elif kind in ('int','fixed'):
            scale=4096 if kind=='fixed' else 1
            if type(value)!=int or value<spec.get('min',0)*scale or (spec.get('max') is not None and value>spec['max']*scale):raise BankError(spec['label']+': outside its supported range.')
        elif not isinstance(value,str):raise BankError(spec['label']+': expected text.')

class Bank:
    def __init__(self,raw,path=None,profile=None,*,player='',author=''):
        self.raw,self.path,self.player,self.author=raw,path,player,author
        self.bank_name=Path(path).stem if path else NAMES[0]
        self.profile=copy.deepcopy(profile or load_profile());self.errors=[];self.warnings=[];self.checks={};self.state=None;self.signature_verified=False
        try:
            if self.bank_name not in NAMES:raise BankError('Open the original main or supported options bank, retaining its exact name.')
            if self.bank_name!=NAMES[0]:self.profile['fields']=self.profile['companion_fields'][self.bank_name]
            if len(raw)>4194304:raise BankError('Bank exceeds 4 MB.')
            text=raw.decode('utf-8-sig')
            if '<!DOCTYPE' in text.upper() or '<!ENTITY' in text.upper():raise BankError('DTD/entity declarations are unsupported.')
            self.root=ET.fromstring(text,parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True,insert_pis=True)))
            sections,nodes,signature=inspect_root(self.root)
            if not matches_structure(self.root):raise BankError('Bank structure does not match this map profile.')
            required={NAMES[0]:'HumanStats',NAMES[1]:'GameplayOptions',NAMES[2]:'Options'}[self.bank_name]
            if required not in sections:raise BankError('Bank filename does not match its contents.')
            if signature is not None:
                self.signature_verified=signature_for(self.root,player,author,self.bank_name)==signature.get('value').upper()
                if not self.signature_verified:raise BankError('Original native signature does not match the account, author and bank name.')
            elif self.bank_name!=NAMES[2]:raise BankError('Original native signature required for this bank.')
            self.checks['native_signature']=self.signature_verified if signature is not None else 'Not used by Options2 loader'
            values={}
            for spec in self.profile['fields']:
                node=nodes.get((spec['section'],spec['bank_key']))
                if node is None:values[spec['key']]=spec.get('default','' if spec['type'] in ('string','text') else False if spec['type']=='bool' else 0);continue
                kind,lexical=next(iter(node.find('Value').attrib.items()))
                expected='flag' if spec['type']=='bool' else spec['type']
                # The map's reset command historically writes literal string "0"
                # to XP; its subsequent GetAsInt result is zero.
                if kind=='string' and expected=='int' and spec['bank_key']=='XP' and lexical=='0':values[spec['key']]=0;continue
                if kind!=expected:raise BankError(f'{spec["key"]}: unexpected stored primitive type {kind}.')
                values[spec['key']]=decode(kind,lexical)
            self.state=State(values)
            if self.bank_name==NAMES[0]:
                identity=values['PlayerInfo/PlayerHandle']
                if identity and identity!=player:raise BankError('Saved PlayerHandle differs from the original folder account.')
                loader_checks(values);self.checks['map_loader_relationships']=True
            self.warnings.extend(['Source-derived offline validation; published-match load/save has not been tested.','PvZ2MMR is a separate encrypted rating bank and is not edited.'])
            if self.bank_name==NAMES[0]:self.warnings.append('Achievements are saved flags. Reward activations additionally require role XP; newly enabled rewards raise the required XP in the preview. Match-history fields remain read-only.')
            else:self.warnings.append('Cosmetic and ability selections remain read-only; preference toggles do not grant their runtime unlock requirements.')
        except (BankError,UnicodeDecodeError,ET.ParseError) as exc:self.errors.append(str(exc))
    @classmethod
    def read(cls,path,profile=None,*,player='',author=''):
        path=Path(path);return cls(path.read_bytes(),path,profile,player=player,author=author)
    def signature_status(self):return 'Not used by Options2' if self.bank_name==NAMES[2] and self.root.find('Signature') is None else 'Verified' if self.signature_verified else 'Mismatch'
    def render(self,target):
        if self.errors:raise BankError('Read-only: '+'; '.join(self.errors))
        validate(target,self.profile,self.state)
        effective=target.clone();v=effective.values;notes=[]
        if self.bank_name==NAMES[0]:
            for spec in self.profile['fields']:
                if spec.get('requires_xp') and v[spec['key']] and (not self.state.values[spec['key']] or target.values[spec['requires_xp']]!=self.state.values[spec['requires_xp']]):
                    key=spec['requires_xp'];needed=level_xp(spec['requires_level'])
                    if v[key]<needed:v[key]=needed;notes.append(f'{spec["label"]}: raised {key} to {needed} XP (level {spec["requires_level"]}).')
            for section in ['HumanStats','VampireStats','TotalStats']:
                if any(v[section+'/'+k]!=self.state.values[section+'/'+k] for k in ['Wins','Losses']):
                    offset=self.state.values[section+'/Games']-self.state.values[section+'/Wins']-self.state.values[section+'/Losses']
                    v[section+'/Games']=v[section+'/Wins']+v[section+'/Losses']+offset
                    if v[section+'/Games']>2147483646:raise BankError(section+': combined wins/losses overflow supported game count.')
                    notes.append(section+': updated Games from wins, losses and the original unfinished-match offset.')
                if v[section+'/Points']!=self.state.values[section+'/Points']:v[section+'/Rank']=rank(v[section+'/Points']);notes.append(section+': updated Rank from points.')
            loader_checks(v)
        changed={k for k in v if v[k]!=self.state.values[k]}
        if not changed:return self.raw,effective,['No changes; original bytes preserved.']
        root=copy.deepcopy(self.root);sections,nodes,signature=inspect_root(root)
        for spec in self.profile['fields']:
            if spec['key'] not in changed:continue
            value=v[spec['key']];kind='flag' if spec['type']=='bool' else spec['type']
            lexical=str(int(value)) if kind=='flag' else format_fixed(value) if kind=='fixed' else str(value)
            section=sections.get(spec['section'])
            if section is None:section=ET.SubElement(root,'Section',name=spec['section']);sections[spec['section']]=section
            node=nodes.get((spec['section'],spec['bank_key']))
            if node is None:node=ET.SubElement(section,'Key',name=spec['bank_key']);leaf=ET.SubElement(node,'Value')
            else:leaf=node.find('Value');leaf.attrib.clear()
            leaf.set(kind,lexical)
        if signature is not None:signature.set('value',signature_for(root,self.player,self.author,self.bank_name))
        ET.indent(root,space='    ');raw=ET.tostring(root,encoding='utf-8',xml_declaration=True)+b'\n'
        fresh=Bank(raw,self.path,player=self.player,author=self.author)
        if fresh.errors or fresh.state!=effective:raise BankError('Output failed original-context read-back validation: '+'; '.join(fresh.errors))
        return raw,effective,notes+['Changed fields and documented dependencies written; unrelated keys preserved.']
