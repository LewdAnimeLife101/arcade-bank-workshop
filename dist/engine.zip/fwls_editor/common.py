"""Fallen World resources and explicit atomic copy export."""
from pathlib import Path
import hashlib
import json
import os
import sys
import tempfile
import uuid
import re

from zwl_editor.common import BankError, HANDLE, INT_MIN, INT_MAX, integer
from zwl_editor.fixed import parse_fixed


def numeric_input(text, label):
    """Accept unambiguous thousands separators in UI fields, never bank XML."""
    text=str(text).strip()
    if ',' in text:
        if not re.fullmatch(r'[+-]?[0-9]{1,3}(?:,[0-9]{3})+(?:\.[0-9]+)?',text):
            raise BankError(label+": use a number such as 1000 or 1,000; use a dot for decimals.")
        text=text.replace(',','')
    if not text: raise BankError(label+": enter a number; the field is empty.")
    return text


def fixed_input(text,label):
    try: return parse_fixed(numeric_input(text,label))
    except BankError as exc:
        if str(exc).startswith(label+':'): raise
        raise BankError(label+": "+str(exc)+" Enter a number, for example 1000 or 1000.5.") from exc


def resource_path(relative):
    root = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent.parent))
    parts = Path(relative).parts
    return root/parts[0]/"fallen"/Path(*parts[1:]) if parts and parts[0] in ("data", "docs") else root/relative


def load_profile():
    return json.loads(resource_path("data/map_profile.json").read_text(encoding="utf-8"))


def write_bank(destination, payload, source, *, replace=False):
    """Revalidate, stage/fsync, retain replacement backup, atomically commit."""
    from .core import Bank
    if not source.original_verified():
        raise BankError("The original bank must pass schema and native signature validation before export.")
    given = Path(destination)
    if given.is_symlink():
        raise BankError("Refusing a symbolic-link destination.")
    destination = given.resolve()
    if source.path is not None:
        if destination == source.path or destination.parent == source.path.parent:
            raise BankError("Copies only: choose a separate export folder; original bank directories are not overwritten.")
        if destination.exists() and source.path.exists() and os.path.samefile(destination, source.path):
            raise BankError("Copies only: the destination refers to the original bank file.")
    if destination.suffix.lower() != ".sc2bank" or destination.stem != source.bank_name:
        raise BankError("Keep the original mode's exact bank filename when exporting.")
    output = Bank(payload, destination, source.profile, player=source.player, author=source.author)
    if output.errors:
        raise BankError("Refusing invalid output: "+"; ".join(output.errors))
    def unchanged():
        if source.path is not None:
            try:
                if source.path.stat().st_size > 4*1024*1024:
                    raise BankError("The original grew beyond the supported4MB limit. Reload before export.")
                with source.path.open("rb") as stream:
                    original = stream.read(4*1024*1024+1)
                if len(original) > 4*1024*1024:
                    raise BankError("The original grew beyond the supported4MB limit. Reload before export.")
                digest = hashlib.sha256(original).hexdigest()
            except OSError as exc:
                raise BankError("The original is unavailable. Reload before exporting.") from exc
            if digest != source.digest:
                raise BankError("The original changed after opening. Reload before exporting.")
    unchanged()
    exists = destination.exists()
    if exists and not replace:
        raise BankError("The destination exists. Choose a new file or explicitly replace it.")
    destination.parent.mkdir(parents=True, exist_ok=True)
    old = destination.read_bytes() if exists else None
    token = uuid.uuid4().hex
    fd, name = tempfile.mkstemp(prefix=".fallen-", suffix=".tmp", dir=destination.parent)
    staged = Path(name)
    backup = None
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        if staged.read_bytes() != payload:
            raise BankError("Staged output verification failed.")
        unchanged()
        if exists:
            if destination.is_symlink() or destination.read_bytes() != old:
                raise BankError("The destination changed during export.")
            backup = destination.with_name(destination.name+".backup-"+token)
            with backup.open("xb") as stream:
                stream.write(old)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(staged, destination)
        else:
            os.link(staged, destination)  # Fail rather than clobber a racing file.
            staged.unlink()
        if destination.read_bytes() != payload:
            raise BankError("Output read-back failed; replacement backup was retained.")
        return backup
    finally:
        staged.unlink(missing_ok=True)

