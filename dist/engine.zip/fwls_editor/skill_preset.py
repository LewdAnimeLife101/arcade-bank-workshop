"""Funded skill requests; Extras are deliberately absent from map loadouts."""
from dataclasses import dataclass
import re
import xml.etree.ElementTree as ET
from .common import BankError
from .companion import Loadout, NODES, parse, estimate
from .presets import maximize, trophy_points, describe

SPECIAL_CHOICES = ('Income & experience', 'Buff chance & experience', 'Balanced')
EMPTY_COMPANION = b'<Bank version="1"><Section name="Loadout"/></Bank>'


def funded(before, profile, priority=SPECIAL_CHOICES[0]):
    if priority not in SPECIAL_CHOICES: raise BankError('Choose a supported Special priority.')
    target, _ = maximize(before, profile)
    target.values['ascension_level'] = max(65, target.values['ascension_level'])
    points = [0]*180
    for tier, nodes in enumerate(NODES[:8], 1):
        for index, (_, base, _) in enumerate(nodes):
            points[(tier-1)*20+index] = base+(15 if tier <= 7 else 0)
    budget = trophy_points(target, profile)
    # Priorities describe the tradeoff explicitly. No invented trophy wallet.
    special = [0]*4
    order = (0,1,2,3) if priority == SPECIAL_CHOICES[0] else (3,1,2,0)
    if priority == 'Balanced':
        for i in (1,2):
            for rank in range(1,11):
                if rank*15 <= budget: special[i]+=1; budget-=rank*15
        while True:
            affordable=[i for i in (0,3) if special[i]<20 and 15*(special[i]+1)<=budget]
            if not affordable: break
            i=min(affordable,key=lambda n:(special[n],n))
            special[i]+=1; budget-=special[i]*15
    else:
        for i in order:
            for rank in range(1,NODES[8][i][1]+1):
                if rank*15>budget: break
                special[i]+=1; budget-=rank*15
    points[160:164]=special
    loadout=Loadout('AllSkills',tuple(points))
    result=estimate(loadout,skill_tiers=target.skill_tiers,skill_level=target.values['skill_level'],
                    ascension_level=target.values['ascension_level'],trophy_points=trophy_points(target,profile))
    if result.applied!=result.requested or result.remaining_skill<125000:
        raise BankError('The preset cannot fund its requests and the full Extras reserve.')
    notes = [describe(before,target,profile),
        'All regular skills reach their rank-IV caps. All five Ascendancy skills reach their caps.',
        f'Special priority: {priority}. Income {special[0]}/20; Hero XP {special[1]}/10; Skill XP {special[2]}/10; Buff Chance {special[3]}/20.',
        f'Regular skills cost 945,270 SP. Ascendancy costs 45 points. Remaining SP after loading: {result.remaining_skill:,}.',
        f'Special leaves {result.remaining_trophy:,} trophy points. All Special caps cost 7,950; trophy flags cannot fund all of them.',
        'Extras access is unlocked and 125,000 SP is reserved, but the map does not save or auto-load Extras purchases.',
        'In each match buy Starting Minerals 10/10 and Percent HP Chance 10/10 manually (110,000 SP total). Zombie Speed 5/5 costs another 15,000 and makes enemies faster; it is optional.',
        'This raises ascensions to at least 65 (within the 0.89 limit of 1,000) and skill level to 10,000. It does not produce a low-level profile.',
        'Only the selected skill companion loadout and Auto choice change. Other loadouts and settings are preserved. Install the main bank with the synchronized FWLSBankChk comparison file; historical snapshots stay unchanged.',
        'Load on first hero selection in a fresh match; repeated manual loading has different spending behavior. Edited loadout acceptance remains untested in the published map.']
    for tier,nodes in enumerate(NODES,1):
        label=f'Tier {tier}' if tier<=7 else 'Ascendancy' if tier==8 else 'Special'
        notes.append(label+': '+', '.join(re.sub(r'(?<=[a-z])(?=[A-Z])',' ',name)+' '+str(points[(tier-1)*20+i])+'/'+str(base+(15 if tier<=7 else 0)) for i,(name,base,_) in enumerate(nodes)))
    return target,loadout,'\n\n'.join(notes)


def render_companion(raw, slot, loadout, *, auto):
    """Edit one existing or empty slot, preserving other XML and settings."""
    before=parse(raw)
    if type(slot) is not int or not 1<=slot<=5: raise BankError('Loadout slot must be 1–5.')
    if type(auto) is not bool: raise BankError('Auto must be on or off.')
    if loadout.name!='AllSkills' or len(loadout.points)!=180: raise BankError('Unsupported preset loadout.')
    root=ET.fromstring(raw,parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True,insert_pis=True)))
    if root.find('Signature') is not None: raise BankError('Signed companion files are unsupported; no signature will be removed.')
    section=root.find("Section[@name='Loadout']")
    if section is None:
        raise BankError('No Loadout section. Save a skill loadout in this map first.')
    def set_value(name,kind,value):
        node=section.find(f"Key[@name='{name}']")
        if node is None:node=ET.SubElement(section,'Key',name=name)
        node[:]=[];ET.SubElement(node,'Value',**{kind:value})
    set_value(str(slot),'string',loadout.name+' '+' '.join(map(str,loadout.points))+' ')
    # When Auto is off, explicitly turn it off rather than pointing to old data.
    set_value('Auto','int',str(slot if auto else 0))
    payload=ET.tostring(root,encoding='utf-8',xml_declaration=True)
    after=parse(payload)
    expected=dict(before.loadouts);expected[slot]=loadout
    if after.loadouts!=expected or after.auto!=(slot if auto else 0):raise BankError('Companion read-back mismatch.')
    if (after.particles_off,after.has_mutator_preset)!=(before.particles_off,before.has_mutator_preset):raise BankError('Companion settings changed.')
    return payload


@dataclass
class SkillPlan:
    main_digest: str
    before: object
    target: object
    companion_raw: bytes
    companion_output: bytes
    slot: int
    auto: bool
    priority: str
    text: str
