"""Synthetic demonstration banks; no real player data is packaged."""
import xml.etree.ElementTree as ET
from .common import load_profile
from .core import State, Bank, MAIN_FIELDS, SECTION, _payloads, _xp_heroes
from .codec import BANK_KEYS, encode
from zrc_editor.core import signature_for

PLAYER = '1-S2-1-1234567'
AUTHOR = '1-S2-1-7654321'


def demo_state(profile=None):
    profile = profile or load_profile()
    values = {name: 0 for name in MAIN_FIELDS}
    values['skill_level'] = 1
    values.update(damage_dealt='0', damage_taken='0', play_time=0)
    return State(values, tuple('0' * len(p['trophies']) for p in profile['trophy_pages']),
                 (0,) * len(_xp_heroes(profile)), tuple(s.get('min', 0) for s in profile.get('skill_tiers', profile.get('tiers', []))), (1,) * len(profile['heroes']))


def demo_bytes(profile=None, *, state=None, player=PLAYER, author=AUTHOR):
    profile = profile or load_profile()
    state = state or demo_state(profile)
    root = ET.Element('Bank', version='1')
    section = ET.SubElement(root, 'Section', name=SECTION)
    for group, plain in _payloads(state, player).items():
        node = ET.SubElement(section, 'Key', name=BANK_KEYS[group])
        ET.SubElement(node, 'Value', string=encode(plain, player, group))
    ET.SubElement(root, 'Signature', value=signature_for(root, player, author, 'FWLSBank'))
    return ET.tostring(root, encoding='utf-8', xml_declaration=True)


def demo_bank(profile=None):
    profile = profile or load_profile()
    return Bank(demo_bytes(profile), profile=profile, player=PLAYER, author=AUTHOR)


create_demo = demo_bank
