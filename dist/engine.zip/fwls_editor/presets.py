"""Reviewed capped progression, with history and uncapped progression retained."""
from .core import validate


def trophy_points(state,profile):
    return sum(t['points'] for p,page in enumerate(profile['trophy_pages'])
               for n,t in enumerate(page['trophies']) if state.trophies[p][n]=='1' or (p,n)==(0,0))


def summary(state,profile):
    level=state.values['skill_level'];asc=state.values['ascension_level']
    total=asc*2499750000+25*level*(level-1)+state.values['current_xp']
    return (f"Derived trophy points: {trophy_points(state,profile):,} (includes the automatically granted first trophy).\n"
            f"Skill points before allocated Skill Point Increase: {level*(15+5*(asc//5)):,}. Ascendancy points before spending: {asc:,}.\n"
            f"Derived lifetime skill XP: {total:,}. The legacy stored XP field stays unchanged.")


def describe(before,target,profile):
    lines=[]
    for spec in profile['fields']:
        key=spec['key']
        if before.values[key]!=target.values[key]:lines.append(f"{spec['label']}: {before.values[key]} → {target.values[key]}")
    for hero in profile['heroes']:
        n=hero.get('bank_index')
        if n is not None and before.hero_xp[n]!=target.hero_xp[n]:lines.append(f"{hero['label']} XP: {before.hero_xp[n]:,} → {target.hero_xp[n]:,}")
        n=hero['tier_index']
        if before.hero_tiers[n]!=target.hero_tiers[n]:lines.append(f"{hero['label']} evolution: {before.hero_tiers[n]} → {target.hero_tiers[n]}")
    for n,spec in enumerate(profile['skill_tiers']):
        if before.skill_tiers[n]!=target.skill_tiers[n]:lines.append(f"{spec['label']}: rank {before.skill_tiers[n]} → {target.skill_tiers[n]}")
    for p,page in enumerate(profile['trophy_pages']):
        for n,trophy in enumerate(page['trophies']):
            if before.trophies[p][n]!=target.trophies[p][n]:lines.append(f"{page['label']} / {trophy['label']}: "+('unlocked' if target.trophies[p][n]=='1' else 'locked'))
    return '\n'.join(lines or ['No changes.'])+'\n\n'+summary(target,profile)


def maximize(before,profile):
    target=before.clone()
    target.values['skill_level']=10000;target.values['current_xp']=0
    target.values['ascension_level']=max(2,target.values['ascension_level'])
    target.hero_xp=tuple(159510 for _ in target.hero_xp)
    target.skill_tiers=tuple(s['max'] for s in profile['skill_tiers'])
    evolutions=list(target.hero_tiers)
    for hero in profile['heroes']:
        if hero.get('ordinary_max_tier',1)>1:
            n=hero['tier_index'];evolutions[n]=max(evolutions[n],hero['ordinary_max_tier'])
    target.hero_tiers=tuple(evolutions)
    target.trophies=tuple(''.join(old[n] if t.get('restricted') else '1' for n,t in enumerate(page['trophies'])) for old,page in zip(before.trophies,profile['trophy_pages']))
    validate(target,profile,before=before)
    return target,[
        'Skill level 10,000; all eleven saved hero XP records at level 100; all seven skill-tier ranks at 4.',
        'Marine ordinary evolution reaches tier 2. Existing higher tiers are retained; other heroes have no supported evolution chain.',
        'All 92 trophy flags are unlocked, including Tester (+15 trophy points). Total: 6,935 trophy points. This does not recreate qualifying matches or grant staff commands.',
        'Ascensions have no natural cap. This preset preserves them and only raises them to 2 if needed for Pirate Ship access.',
        'Kills, score, missions, deaths, waves, healing, minerals, damage, play time and legacy XP are unchanged.',
        'Unlock flags do not replay purchase costs. Skill spending plans and settings in FWLSBank2 are untouched; review allocations in game.',
        'Offline rendering and signature verification do not establish published-map acceptance.'
    ]
