"""Review, stage and explicitly save a funded main/companion preset."""
import tkinter as tk
from tkinter import filedialog,messagebox
from pathlib import Path
import uuid
import customtkinter as ctk
from .common import BankError
from .skill_preset import SkillPlan, SPECIAL_CHOICES, EMPTY_COMPANION, funded, render_companion
from .companion import parse


class SkillsPanel(ctk.CTkFrame):
    def __init__(self,master,editor):
        super().__init__(master,fg_color='transparent')
        self.editor=editor;self.plan=None;self.applied=None
        self.slot=tk.StringVar(value='5');self.priority=tk.StringVar(value=SPECIAL_CHOICES[0]);self.auto=tk.BooleanVar(value=True)
        editor.note(self,'Unlock all + funded skills: maximizes ordinary progression, regular skills and Ascendancy. Skill level becomes 10,000 and ascensions at least 65. Special uses the available trophy budget. Extras access and funding are included; purchase Extras manually each match.')
        editor.note(self,'This updates two banks together. The companion is found beside your opened current bank. Save any loadout in game once to create it. Other slots and settings stay unchanged. Choose a slot carefully: its existing loadout will be replaced.')
        controls=ctk.CTkFrame(self,fg_color='transparent');controls.pack(fill='x',padx=10,pady=8)
        ctk.CTkLabel(controls,text='Loadout slot').pack(side='left',padx=5)
        ctk.CTkOptionMenu(controls,variable=self.slot,values=['1','2','3','4','5'],width=70).pack(side='left',padx=5)
        ctk.CTkOptionMenu(controls,variable=self.priority,values=list(SPECIAL_CHOICES),width=210).pack(side='left',padx=12)
        ctk.CTkCheckBox(controls,text='Auto-load on first hero selection',variable=self.auto).pack(side='left',padx=8)
        actions=ctk.CTkFrame(self,fg_color='transparent');actions.pack(fill='x',padx=10,pady=8)
        ctk.CTkButton(actions,text='Review unlock all + skills',width=210,command=self.review).pack(side='left',padx=4)
        self.apply_button=ctk.CTkButton(actions,text='Apply reviewed changes',width=180,command=self.apply,state='disabled');self.apply_button.pack(side='left',padx=4)
        self.undo_button=ctk.CTkButton(actions,text='Undo',width=85,command=self.undo,state='disabled');self.undo_button.pack(side='left',padx=4)
        saves=ctk.CTkFrame(self,fg_color='transparent');saves.pack(fill='x',padx=10,pady=8)
        self.export_button=ctk.CTkButton(saves,text='Export both copies…',width=190,command=self.export,state='disabled');self.export_button.pack(side='left',padx=4)
        self.replace_button=ctk.CTkButton(saves,text='Replace both current banks',width=225,command=self.replace,state='disabled',fg_color='#765039');self.replace_button.pack(side='left',padx=4)
        editor.note(self,'Special priorities choose which bonus stops short of its cap. Extras: Starting Minerals and Percent HP Chance cost 110,000 SP together. Zombie Speed costs another 15,000 SP and makes enemies faster. None of these Extras purchases can be saved in this map version.')
        self.box=ctk.CTkTextbox(self,height=350,wrap='word');self.box.pack(fill='both',expand=True,padx=10,pady=8)
        self.reset()

    def text(self,value):
        self.box.configure(state='normal');self.box.delete('1.0','end');self.box.insert('1.0',value);self.box.configure(state='disabled')

    def reset(self):
        self.plan=self.applied=None
        for b in (self.apply_button,self.undo_button,self.export_button,self.replace_button):b.configure(state='disabled')
        self.text('Review lists every proposed progression change and the chosen skill-loadout slot. No files change until an explicit export or replacement.')

    def companion(self):
        e=self.editor
        if e.demo_mode:return EMPTY_COMPANION
        from arcade_editor.saving import current_path,read_bounded
        path=current_path('fallen',e.bank).with_name('FWLSBank2.SC2Bank')
        if not path.is_file():raise BankError('Save a named skill loadout in game first to create FWLSBank2, then review again.')
        return read_bounded(path)

    def settings(self):return int(self.slot.get()),bool(self.auto.get()),self.priority.get()

    def review(self):
        try:
            if self.applied:raise BankError('Undo the staged skill preset before reviewing another one.')
            e=self.editor;before=e.collect();raw=self.companion();slot,auto,priority=self.settings()
            target,loadout,notes=funded(before,e.profile,priority);e.bank.render(target)
            companion_output=render_companion(raw,slot,loadout,auto=auto)
            original=parse(raw).loadouts.get(slot)
            notes=f'Slot {slot}: '+(f'replace “{original.name}”' if original else 'use empty slot')+f' with AllSkills. Auto-load: {"ON" if auto else "OFF"}.\n\n'+notes
            self.plan=SkillPlan(e.bank.digest,before,target,raw,companion_output,slot,auto,priority,notes)
            self.text(notes+'\n\nApply stages both changes. Then use Export both copies or Replace both current banks here. No files written.')
            self.apply_button.configure(state='normal')
        except (ValueError,OSError) as exc:
            self.plan=None;self.apply_button.configure(state='disabled');messagebox.showerror('Skill preset blocked',str(exc),parent=self)

    def apply(self):
        try:
            e=self.editor;p=self.plan
            if p is None:raise BankError('Review the skill preset first.')
            if (p.slot,p.auto,p.priority)!=self.settings() or p.main_digest!=e.bank.digest or e.collect()!=p.before:
                raise BankError('Edits or choices changed since review. Review again.')
            if self.companion()!=p.companion_raw:raise BankError('The companion changed since review. Review again.')
            e.work=p.target.clone();e.refresh();self.applied=p;self.plan=None
            e.plan=e.applied=None;e.apply_button.configure(state='disabled');e.undo_button.configure(state='disabled')
            self.apply_button.configure(state='disabled');self.undo_button.configure(state='normal')
            self.export_button.configure(state='normal' if not e.demo_mode else 'disabled')
            self.replace_button.configure(state='normal' if not e.demo_mode else 'disabled')
            e.status.set('Unlocks and funded skill loadout staged. Use the paired save buttons on Skills & unlock all. No files written.')
        except (ValueError,OSError) as exc:messagebox.showerror('Apply blocked',str(exc),parent=self)

    def undo(self):
        try:
            e=self.editor;p=self.applied
            if p is None:raise BankError('No skill preset is staged.')
            if e.bank.digest!=p.main_digest or e.collect()!=p.target:raise BankError('Later edits would be discarded. Restore them before undoing.')
            e.work=p.before.clone();e.refresh();self.reset();e.status.set('Skill preset undone; earlier pending edits restored.')
        except ValueError as exc:messagebox.showerror('Undo blocked',str(exc),parent=self)

    def prepare(self):
        e=self.editor;p=self.applied
        if e.demo_mode:raise BankError('Demo data cannot replace or export a current bank pair.')
        if p is None:raise BankError('Review and apply the skill preset first.')
        if p.main_digest!=e.bank.digest or e.collect()!=p.target or (p.slot,p.auto,p.priority)!=self.settings():
            raise BankError('The staged preset changed. Undo it and review again before saving both banks.')
        payload=e.bank.render(p.target)[0]
        from arcade_editor.saving import validate_fallen_pair
        validate_fallen_pair(e.bank,p.companion_raw,payload,p.companion_output)
        return p,payload

    def replace(self):
        try:
            p,payload=self.prepare();e=self.editor
            from arcade_editor.saving import replace_fallen_pair,backup_directory
            if not messagebox.askyesno('At the main menu — replace both banks?',
                f'Confirm SC2 is closed OR you are at its main menu outside every match.\n\nReplace FWLSBank and FWLSBank2 in:\n{e.bank.path.parent}\n\nSlot {p.slot} becomes AllSkills; Auto-load {"ON" if p.auto else "OFF"}.\nIndependent backups of BOTH originals:\n{backup_directory()}\n\nEach file is replaced atomically. A process interruption can leave a partial pair; both originals remain recoverable. Stay out of matches until saving finishes. Menu state is not detected.',parent=self):return
            updated,_,backup=replace_fallen_pair(e.bank,p.companion_raw,payload,p.companion_output,between_matches_confirmed=True)
            e.set_bank(updated,False);e.tabs.set('Skills & unlock all')
            e.status.set(f'Both banks saved and verified. Original pair: {backup}')
            self.text(f'Both banks saved. Original pair: {backup}\n\nStart a new match and choose your first hero. '+
                ('AllSkills loads automatically.' if p.auto else f'Select slot {p.slot} (AllSkills) and click Load once.')+
                '\nPurchase Extras manually each match. Published-match acceptance of this preset remains untested.')
        except (ValueError,OSError) as exc:messagebox.showerror('Paired replacement blocked',str(exc),parent=self)

    def export(self):
        try:
            p,payload=self.prepare()
            chosen=filedialog.askdirectory(title='Choose a parent folder for a new Fallen World export',parent=self)
            if not chosen:return
            from arcade_editor.saving import export_fallen_pair
            folder=export_fallen_pair(self.editor.bank,p.companion_raw,payload,p.companion_output,Path(chosen)/('Fallen-AllSkills-'+uuid.uuid4().hex[:10]))
            self.editor.status.set(f'Both copies exported to {folder}. Current banks unchanged; edits remain pending.')
        except (ValueError,OSError) as exc:messagebox.showerror('Paired export blocked',str(exc),parent=self)
