"""Read-only FWLSBank2 loadout inspection for Fallen World 0.84.

This module never writes the companion bank. A loadout is a requested spending
plan, not saved purchases. The estimate models its first application in a fresh
match, before any manual spending. See docs/fallen/companion.txt for evidence.
"""
from __future__ import annotations

from dataclasses import dataclass
import re
import xml.etree.ElementTree as ET


class CompanionError(ValueError):
    pass


@dataclass(frozen=True)
class Loadout:
    name: str
    points: tuple[int, ...]


@dataclass(frozen=True)
class Companion:
    loadouts: dict[int, Loadout]
    auto: int = 0
    particles_off: bool = False
    has_mutator_preset: bool = False


# (behavior ID, base cap, runtime unlock level). The latter follows
# gf_SkillpointsSortList's category ordering, including its index mismatch.
NODES = (
    (('AttackDamage',15,1),('AttackSpeed',15,1),('SpellDamage',15,1),('Health',10,1),('Armor',10,1),('EnergyRegeneration',10,1)),
    (('AttackDamage',30,1),('AttackSpeed',30,1),('SpellDamage',30,1),('CritChance',20,3),('Health',20,4),('HealthRegen',15,1),('Armor',20,3),('MovementSpeed',20,1),('EnergyShield',25,2),('EnergyShieldRegeneration',15,4),('SpellCritChance',15,4),('DamageReduction',30,2)),
    (('AttackDamage',45,1),('AttackSpeed',45,1),('SpellDamage',45,1),('SplashDamage',30,2),('CritDamage',25,3),('Health',20,4),('HealthRegen',15,1),('EnergyShieldArmor',25,2),('CooldownReduction',30,3),('EnergyRegeneration',20,4),('MultiCrit',20,1)),
    (('AttackDamage',60,1),('AttackSpeed',60,1),('SpellDamage',60,1),('CritChance',25,3),('MovementSpeed',25,4),('Health',30,1),('Armor',50,1),('DamageReduction',40,4),('EnergyShield',50,1),('EnergyShieldRegeneration',25,3),('SpellCritChance',25,2),('EnergyRegeneration',20,2),('CooldownReduction',25,4)),
    (('AttackDamage',75,1),('AttackSpeed',75,1),('SpellDamage',75,1),('SplashDamage',30,2),('CritDamage',50,3),('MultiCrit',30,4),('Health',50,1),('Armor',50,1),('EnergyShield',50,2),('EnergyShieldArmor',50,3),('CooldownReduction',30,2),('EnergyRegeneration',30,4),('HealthRegen',20,1)),
    (('AttackDamage',90,1),('AttackSpeed',90,1),('SpellDamage',90,1),('CritChance',30,3),('SpellCritChance',30,4),('Health',50,1),('Armor',50,1),('DamageReduction',50,4),('EnergyShield',50,3),('MovementSpeed',40,2),('CooldownReduction',30,2),('EnergyRegeneration',30,2)),
    (('AttackDamage',105,1),('AttackSpeed',105,1),('SpellDamage',105,1),('CritChance',50,2),('CritDamage',75,2),('MultiCrit',50,3),('SpellCritChance',50,3),('SplashDamage',65,4),('Health',75,1),('HealthRegen',50,2),('DamageReduction',50,4),('EnergyShield',100,1),('EnergyShieldArmor',75,2),('EnergyShieldRegeneration',50,3),('Armor',75,1),('CooldownReduction',50,4),('EnergyRegeneration',50,3),('MovementSpeed',75,2)),
    (('OffensiveMultiplier',10,1),('DefensiveMultiplier',10,1),('UtilityMultiplier',10,1),('SkillpointIncrease',10,1),('SharedPower',5,1)),
    (('Income',20,1),('HeroExperience',10,1),('SkillExperience',10,1),('BuffChance',20,1)),
)


def parse(raw: bytes) -> Companion:
    """Inspect explicit companion bytes; not an identity/schema detector."""
    if not isinstance(raw, bytes) or len(raw) > 2_000_000:
        raise CompanionError('Companion input must be at most 2 MB.')
    try:
        text = raw.decode('utf-8-sig')
    except UnicodeDecodeError as exc:
        raise CompanionError('Companion banks must use UTF-8.') from exc
    if '\x00' in text or '<!DOCTYPE' in text.upper() or '<!ENTITY' in text.upper():
        raise CompanionError('DTD/entity declarations are unsupported.')
    from zrc_editor.core import _inspect_root
    try:
        root = ET.fromstring(text)
        _, nodes, _ = _inspect_root(root)
    except (ValueError, ET.ParseError) as exc:
        raise CompanionError('Unsupported companion bank structure.') from exc

    def value(section, key, kind, default):
        node = nodes.get((section, key))
        if node is None:
            return default
        leaves = list(node)
        if len(leaves) != 1 or leaves[0].tag != 'Value' or set(leaves[0].attrib) != {kind}:
            raise CompanionError(f'{section}/{key}: expected a {kind} Value.')
        return leaves[0].get(kind)

    loadouts = {}
    for slot in range(1, 6):
        text = value('Loadout', str(slot), 'string', None)
        if text is None:
            continue
        words = text.split()
        if len(words) != 181 or not words[0]:
            raise CompanionError(f'Loadout {slot}: expected a name and 180 point counts.')
        if any(not re.fullmatch(r'[0-9]+', word) or len(word)>10 or int(word)>2147483647 for word in words[1:]):
            raise CompanionError(f'Loadout {slot}: invalid point count.')
        loadouts[slot] = Loadout(words[0], tuple(map(int, words[1:])))
    auto = int(value('Loadout', 'Auto', 'int', '0'))
    # Exactly the map's normalization of a stored out-of-range auto selection.
    auto = auto if 0 <= auto <= 5 else 0
    particles = value('Settings', 'ParticlesOff', 'flag', '0') == '1'
    return Companion(loadouts, auto, particles, ('MutatorPreset','Saved') in nodes)


@dataclass(frozen=True)
class Estimate:
    requested: int
    applied: int
    remaining_skill: int
    remaining_ascension: int
    remaining_trophy: int
    notes: tuple[str, ...]


def estimate(loadout: Loadout, *, skill_tiers, skill_level: int,
             ascension_level: int, trophy_points: int) -> Estimate:
    """Estimate one fresh-game load; never generate or adjust currency."""
    if len(loadout.points) != 180 or any(type(n) is not int or not 0 <= n <= 2147483647 for n in loadout.points):
        raise CompanionError('Expected 180 nonnegative integer point counts.')
    if len(skill_tiers) != 7 or any(type(n) is not int or not 0 <= n <= 4 for n in skill_tiers):
        raise CompanionError('Expected seven skill tier levels in 0..4.')
    if any(type(n) is not int or not 0 <= n <= 2147483647 for n in (skill_level,ascension_level,trophy_points)):
        raise CompanionError('Invalid progression budget.')
    remaining = {'ascension': ascension_level, 'trophy': trophy_points}
    applied = [0]*180
    notes = []
    # Runtime loads Ascendency and Special before normal skill tiers.
    for tier in (8,9,1,2,3,4,5,6,7):
        if tier == 1:
            remaining['skill'] = skill_level*(15+3*applied[143]+5*(ascension_level//5))
            if remaining['skill'] > 2147483647:
                raise CompanionError('Derived skill-point total exceeds the map integer range.')
        level = max(1,skill_tiers[0]) if tier == 1 else (skill_tiers[tier-1] if tier <= 7 else 1)
        currency = 'ascension' if tier == 8 else 'trophy' if tier == 9 else 'skill'
        for index in range(20):
            offset = (tier-1)*20+index
            wanted = loadout.points[offset]
            if not wanted:
                continue
            if index >= len(NODES[tier-1]):
                notes.append(f'Tier {tier}, node {index+1}: unused node; {wanted} requested points ignored.')
                continue
            behavior, base_cap, unlock = NODES[tier-1][index]
            cap = base_cap+5*(level-1) if tier <= 7 and level >= 1 else base_cap if tier >= 8 else 0
            if level < unlock:
                cap = 0
            target = min(wanted,cap)
            count = 0
            while count < target:
                cost = 1 if tier == 8 else (15 if tier == 9 else tier)*(count+1)
                if cost > remaining[currency]:
                    break
                remaining[currency] -= cost
                count += 1
            applied[offset] = count
            if count < wanted:
                reason = 'tier/node locked' if cap == 0 else 'cap reached' if count == cap else f'insufficient {currency} points'
                notes.append(f'Tier {tier} / {behavior}: {count}/{wanted} points ({reason}).')
    return Estimate(sum(loadout.points),sum(applied),remaining['skill'],remaining['ascension'],remaining['trophy'],tuple(notes))


def report(companion: Companion, state, *, trophy_points: int) -> str:
    """Read-only per-loadout report; caller supplies verified trophy total."""
    lines = ['Companion bank: read-only. No companion file is changed.',
             'Skill loadouts are spending plans, not purchased unlocks.',
             'Estimates assume a fresh match before manual spending; live behavior is untested.',
             f'Auto-load: {companion.auto or "Off"}; particles: {"off" if companion.particles_off else "on"}.',
             'Tier 10 Extras are not included in this map version\'s saved loadouts.']
    if companion.auto and companion.auto not in companion.loadouts:
        lines.append('Auto-load selects an empty slot; the map does nothing.')
    if not companion.loadouts:
        lines.append('No saved skill-point loadouts.')
    for slot,loadout in sorted(companion.loadouts.items()):
        result = estimate(loadout,skill_tiers=state.skill_tiers,
                          skill_level=state.values['skill_level'],
                          ascension_level=state.values['ascension_level'],
                          trophy_points=trophy_points)
        lines.append(f'Slot {slot}: {loadout.name} — {result.applied}/{result.requested} requested points can be assigned.')
        lines.extend(result.notes)
    return '\n'.join(lines)
