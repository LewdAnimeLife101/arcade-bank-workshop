"""Fallen World 0.89 signed current-save comparison, not snapshot history.

Source: shipped gf_BankGuardRange/Compare/MirrorPut. This module never writes
files, changes recovery snapshots, grants staff rights or changes ownership.
Pair output must be installed with its corresponding main bank outside a match.
"""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET

from .common import BankError, HANDLE, INT_MAX
from .codec import shift, KEYS
from .core import MAIN_FIELDS, validate
from zrc_editor.core import _inspect_root, signature_for

NAME = 'FWLSBankChk'
FILENAME = NAME + '.SC2Bank'
LIMIT = 4 * 1024 * 1024
TRACKED_FIELDS = MAIN_FIELDS + ('play_time',)
STATUS = ('ok', 'behind', 'lost', 'edit', 'range')


def range_notes(state):
    """Source guard range rules; not a claim about earned/gameplay maxima."""
    v = state.values
    notes = []
    for key in ('kills', 'missions', 'deaths', 'highest_wave'):
        if v[key] < 0:
            notes.append(key.replace('_', ' ') + ' must not be negative')
    level = v['skill_level']
    if not 1 <= level <= 10000:
        notes.append('skill level must be within 1–10,000')
    elif v['current_xp'] < 0 or (level < 10000 and v['current_xp'] >= level * 50):
        notes.append('current XP must be nonnegative and below 50 × skill level below level 10,000')
    if v['total_xp'] != 0:
        notes.append('legacy total XP must be zero')
    if not 0 <= v['ascension_level'] <= 1000:
        notes.append('ascensions must be within 0–1,000')
    return notes


def record_for(bank, state):
    return bank.player + ' ' + ' '.join(str(state.values[k]) for k in TRACKED_FIELDS)


def _key(player):
    if not HANDLE.fullmatch(player or '') or len(player) < 13 or player[11] not in '0123456789':
        raise BankError('A supported original player handle is required for the comparison bank.')
    return KEYS[int(player[11])]


def _parse(bank, raw):
    if not isinstance(raw, bytes) or not raw or len(raw) > LIMIT:
        raise BankError('Comparison bank must be a nonempty file of at most 4 MB.')
    try:
        text = raw.decode('utf-8-sig')
        if '\x00' in text or '<!DOCTYPE' in text.upper() or '<!ENTITY' in text.upper():
            raise BankError('DTD/entity declarations are unsupported in comparison banks.')
        root = ET.fromstring(text, parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True, insert_pis=True)))
        sections, nodes, signature = _inspect_root(root)
        node = nodes.get(('M', 'r'))
        leaves = [] if node is None else [x for x in node if isinstance(x.tag, str)]
        if len(leaves) != 1 or leaves[0].tag != 'Value' or set(leaves[0].attrib) != {'string'}:
            raise BankError('Expected the comparison record M/r; keep the exact FWLSBankChk.SC2Bank filename.')
        record = shift(leaves[0].get('string'), _key(bank.player), decrypt=True)
        words = record.split()
        if len(words) != 13 or words[0] != bank.player:
            raise BankError('Comparison record does not match this player or the supported 0.89 layout.')
        for word in words[1:]:
            if not re.fullmatch(r'-?(?:0|[1-9][0-9]{0,9})', word) or not -2147483648 <= int(word) <= INT_MAX:
                raise BankError('Unsupported integer in the comparison record.')
        verified = signature is not None and signature.get('value').upper() == signature_for(root, bank.player, bank.author, NAME)
        return root, sections, nodes, signature, record, verified
    except (UnicodeError, ET.ParseError) as exc:
        raise BankError('Malformed comparison bank XML.') from exc


def inspect_guard(main_bank, raw, *, target_state=None, snapshots_exist=False):
    """Predict source comparison using verified main context and supplied bytes.

    A missing file is explicit None. Signature mismatches are reported for
    diagnosis, but render_guard refuses to overwrite such existing files.
    """
    if not main_bank.original_verified():
        raise BankError('Verify the original main bank before checking its comparison bank.')
    if type(snapshots_exist) is not bool:
        raise BankError('Snapshot presence must be explicit true or false.')
    state = main_bank.state if target_state is None else target_state
    validate(state, main_bank.profile)
    notes = range_notes(state)
    code = 4 if notes else 0
    record, verified = None, False
    if raw is None:
        if snapshots_exist:
            notes.append('comparison file is missing but snapshots exist')
            code = max(code, 2)
    else:
        _, _, _, _, record, verified = _parse(main_bank, raw)
        if not verified:
            notes.append('comparison signature does not match this account, map author and exact filename')
            code = max(code, 2)
        values = tuple(map(int, record.split()[1:]))
        up = down = False
        for name, old in zip(TRACKED_FIELDS, values):
            new = state.values[name]
            if new != old:
                up |= new > old
                down |= new < old
                notes.append(name.replace('_', ' ') + f': {new - old:+d}')
        code = max(code, 3 if up else 1 if down else 0)
    return {'code': code, 'status': STATUS[code], 'notes': notes,
            'record': record, 'signature_verified': verified,
            'mirror_present': raw is not None, 'snapshots_exist': snapshots_exist,
            'live_acceptance_tested': False}


def render_guard(main_bank, target_state, original_mirror=None):
    """Return signed current-state comparison bytes, preserving existing extras.

    None means the caller has explicitly established/selected a missing mirror.
    A supplied invalid signature or foreign record is never silently replaced.
    Historical FWLSBankSnap files are deliberately outside this API.
    """
    if not main_bank.original_verified():
        raise BankError('Verify the original main bank before generating a paired comparison bank.')
    validate(target_state, main_bank.profile, before=main_bank.state)
    problems = range_notes(target_state)
    if problems:
        raise BankError('Fallen World 0.89: ' + '; '.join(problems))
    # Verify that the corresponding main output is representable as well.
    main_bank.render(target_state)
    wanted = record_for(main_bank, target_state)
    if original_mirror is not None:
        root, sections, nodes, signature, previous, verified = _parse(main_bank, original_mirror)
        if not verified:
            raise BankError('Original FWLSBankChk signature is invalid for this account and map author; it will not be replaced.')
        if previous == wanted:
            return original_mirror, ['Comparison bank already matches the edited main bank.']
    else:
        root = ET.Element('Bank', version='1')
        section = ET.SubElement(root, 'Section', name='M')
        node = ET.SubElement(section, 'Key', name='r')
        ET.SubElement(node, 'Value', string='')
        signature = ET.SubElement(root, 'Signature', value='0' * 40)
        sections, nodes, _ = _inspect_root(root)
    node = nodes[('M', 'r')]
    next(x for x in node if isinstance(x.tag, str)).set('string', shift(wanted, _key(main_bank.player)))
    signature.set('value', signature_for(root, main_bank.player, main_bank.author, NAME))
    output = ET.tostring(root, encoding='utf-8', xml_declaration=True)
    check = inspect_guard(main_bank, output, target_state=target_state)
    if not check['signature_verified'] or check['code'] or check['record'] != wanted:
        raise BankError('Paired comparison bank did not pass signed read-back and 0.89 comparison checks.')
    return output, [
        'FWLSBankChk signed comparison record synchronized with the edited FWLSBank.',
        'Install both files together outside every match. Historical recovery snapshots are unchanged.',
        'The audited 0.89 comparison and range checks pass offline; account-list restrictions remain and live acceptance is untested.',
    ]
