"""Starcode 1.5 character shifts, transcribed from the packaged Galaxy script.

No compression/hash layer is used by FWLSBank's seven payloads. Positions in
KEY_POSITIONS are one-based handle character positions, in encryption order.
"""
from .common import BankError, HANDLE

ALPHABET = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!$%/()=?,.-;:_^#+* @{[]}|~`"
KEYS = (
    "Filthy_FiLtHy_Cheaters", "Hurrr_durrr_I_wanna_cheat",
    "Stop_trying_to_cHeAt", "SeriouslyJustPlayTheGame", "JustFuCk_OfALready",
    "ThIs_GaMe_Is_ToO_gRiNdY", "IfYourReadingThis_ChokeOnADick",
    "FuCk_HoW_mAnY_ofthesedoihavetomake", "WellIsntThisMagical",
    "HowManyTimesDoIHaveToTellYouToStopCheating",
)
KEY_POSITIONS = {
    'main': (10,), 'trophies': (8, 9), 'hero_xp': (11, 12),
    'skill_tiers': (9, 13), 'damage': (10,), 'play_time': (11,),
    'hero_tiers': (10,),
}
BANK_KEYS = {
    'main': 'tHe_AdMiN_sAiD_iT_wAs_Ok',
    'trophies': 'i_JuSt_WaNtEd_MoRe_Sp', 'hero_xp': 'I_dIDnT_cHeAt',
    'skill_tiers': 'DoNt_ChEaT_kIdS', 'damage': 'dAmAgE_iS_nOt_ChEaTiNg',
    'play_time': 'tImE_iS_aN_iLlUsIoN', 'hero_tiers': 'mY_dOg_dId_iT',
}
INDEX = {ch: i for i, ch in enumerate(ALPHABET)}


def shift(text, key, *, decrypt=False):
    if not isinstance(text, str) or len(text) > 16384:
        raise BankError('Starcode payload is invalid or too long.')
    if not key or any(ch not in INDEX for ch in text + key):
        raise BankError('Unsupported character in Starcode payload or key.')
    direction = -1 if decrypt else 1
    return ''.join(ALPHABET[(INDEX[ch] + direction * INDEX[key[i % len(key)]]) % len(ALPHABET)] for i, ch in enumerate(text))


def transform(text, player, group, *, decrypt=False):
    if not HANDLE.fullmatch(player or '') or len(player) < 13:
        raise BankError('A complete original player handle is required for Starcode.')
    positions = KEY_POSITIONS[group]
    for position in reversed(positions) if decrypt else positions:
        char = player[position - 1]
        if char not in '0123456789':
            raise BankError('Unsupported account handle layout for this map cipher.')
        text = shift(text, KEYS[int(char)], decrypt=decrypt)
    return text


def encode(text, player, group):
    return transform(text, player, group)


def decode(text, player, group):
    return transform(text, player, group, decrypt=True)
