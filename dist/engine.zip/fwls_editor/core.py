"""Source-derived FWLSBank reader/writer with account-bound native signatures."""
from dataclasses import dataclass, field
from pathlib import Path
import copy
import hashlib
import re
import xml.etree.ElementTree as ET

from .common import BankError, integer, load_profile, INT_MAX
from .codec import BANK_KEYS, encode, decode
from zrc_editor.core import _inspect_root, signature_for

SECTION = '|||||'
MAIN_FIELDS = ('kills', 'score', 'missions', 'deaths', 'highest_wave', 'healing',
               'minerals', 'skill_level', 'current_xp', 'total_xp', 'ascension_level')
LIMIT = 4 * 1024 * 1024


@dataclass(eq=True)
class State:
    values: dict = field(default_factory=dict)
    trophies: tuple = ()
    hero_xp: tuple = ()
    skill_tiers: tuple = ()
    hero_tiers: tuple = ()

    def clone(self):
        return copy.deepcopy(self)


def _xp_heroes(profile):
    return sorted((h for h in profile['heroes'] if h.get('bank_index') is not None), key=lambda h: h['bank_index'])


def _decimal(value, label):
    if not isinstance(value, str) or not re.fullmatch(r'0|[1-9][0-9]{0,999}', value):
        raise BankError(label + ': expected a nonnegative decimal integer of at most 1000 digits.')
    return value


def validate(state, profile, *, before=None):
    if not isinstance(state, State) or set(state.values) != set(MAIN_FIELDS) | {'damage_dealt', 'damage_taken', 'play_time'}:
        raise BankError('Incomplete or unexpected Fallen World editor state.')
    specs = {f['key']: f for f in profile['main_fields']}
    for name in MAIN_FIELDS:
        spec = specs[name]
        value = state.values[name]
        if type(value) is not int:
            raise BankError(spec['label'] + ': expected a whole number.')
        integer(value, spec['label'], spec.get('min', 0), spec.get('max', INT_MAX))
        if before is not None and spec.get('editable', True) is False and value != before.values[name]:
            raise BankError(spec['label'] + ' is preserved read-only.')
    for name in ('damage_dealt', 'damage_taken'):
        _decimal(state.values[name], name.replace('_', ' ').title())
    if type(state.values['play_time']) is not int:
        raise BankError('Play time must be whole seconds.')
    integer(state.values['play_time'], 'Play time', 0, INT_MAX)
    if type(state.trophies) is not tuple or len(state.trophies) != len(profile['trophy_pages']):
        raise BankError('Unexpected trophy page count.')
    for index, (word, page) in enumerate(zip(state.trophies, profile['trophy_pages'])):
        if not isinstance(word, str) or len(word) != len(page['trophies']) or any(c not in '01' for c in word):
            raise BankError('Trophy page ' + str(index + 1) + ': expected one 0/1 flag per trophy.')
        if before is not None:
            for n, trophy in enumerate(page['trophies']):
                if trophy.get('restricted', False) and word[n] != before.trophies[index][n]:
                    raise BankError(trophy['label'] + ' is account-restricted and preserved read-only.')
    heroes = _xp_heroes(profile)
    if type(state.hero_xp) is not tuple or len(state.hero_xp) != len(heroes):
        raise BankError('Unexpected hero XP count.')
    for value, hero in zip(state.hero_xp, heroes):
        if type(value) is not int:
            raise BankError(hero['label'] + ': XP must be a whole number.')
        integer(value, hero['label'] + ' XP', 0, hero.get('max_xp', 159510))
    if type(state.skill_tiers) is not tuple or len(state.skill_tiers) != 7:
        raise BankError('Expected seven saved skill-tier ranks.')
    for value, spec in zip(state.skill_tiers, profile.get('skill_tiers', profile.get('tiers', []))):
        if type(value) is not int:
            raise BankError('Skill-tier ranks must be whole numbers.')
        integer(value, spec['label'], 0, spec['max'])
    if type(state.hero_tiers) is not tuple or len(state.hero_tiers) != len(profile['heroes']):
        raise BankError('Unexpected hero evolution count.')
    for n, value in enumerate(state.hero_tiers):
        if type(value) is not int:
            raise BankError('Evolution tiers must be whole numbers.')
        integer(value, 'Hero evolution', 1, 5)
        hero = profile['heroes'][n]
        if before is not None and value != before.hero_tiers[n]:
            maximum = hero.get('editable_max_tier', hero.get('ordinary_max_tier', 2 if hero.get('evolution_editable', False) else 1))
            if maximum == 1 or value > maximum:
                raise BankError(hero['label'] + ': unsupported evolution tier; existing value is preserved read-only.')
    if before is not None and (state.values['skill_level'], state.values['current_xp']) != (before.values['skill_level'], before.values['current_xp']):
        if state.values['current_xp'] >= 50 * state.values['skill_level']:
            raise BankError('Current XP must be below the next level threshold (50 × skill level).')


def _numbers(words, count, label, *, default=0, short=False, maximum=INT_MAX):
    if len(words) > count or not short and len(words) != count:
        raise BankError(label + ': unsupported word count.')
    return tuple(integer(w, label, 0, maximum) for w in words) + (default,) * (count - len(words))


class Bank:
    def __init__(self, raw, path=None, profile=None, *, player='', author=''):
        self.raw = raw
        self.path = Path(path).resolve() if path is not None else None
        self.profile = profile or load_profile()
        self.bank_name = self.path.stem if self.path else 'FWLSBank'
        native_backup=self.path is not None and self.path.parent.name.casefold()=='backup' and re.fullmatch(r'FWLSBank_backup_[0-9]+',self.path.stem,re.I)
        if native_backup or self.bank_name.casefold()=='fwlsbank':self.bank_name='FWLSBank'
        inferred_player = inferred_author = ''
        author_folder=(self.path.parent.parent if native_backup else self.path.parent) if self.path is not None else None
        if author_folder is not None and author_folder.parent.name.casefold() == 'banks':
            inferred_player, inferred_author = author_folder.parent.parent.name, author_folder.name
        self.player, self.author = player or inferred_player, author or inferred_author
        self.digest = hashlib.sha256(raw).hexdigest()
        self.state = None
        self.errors, self.warnings, self.checks = [], [], {}
        self.signature_verified = False
        self.present = set()
        self._signature_status = 'Unverified'
        try:
            if len(raw) > LIMIT:
                raise BankError('Bank exceeds the 4 MB limit.')
            text = raw.decode('utf-8-sig')
            if '<!DOCTYPE' in text.upper() or '<!ENTITY' in text.upper():
                raise BankError('DTD/entities are unsupported.')
            self.root = ET.fromstring(text, parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True, insert_pis=True)))
            self.sections, self.nodes, signature = _inspect_root(self.root)
            if (SECTION, 'tHiS_gAmE_sUcKs') in self.nodes:
                raise BankError('Legacy rank migration is present. Load and save once in the current map before editing.')
            if self.bank_name not in self.profile.get('bank_names', ['FWLSBank']):
                raise BankError('Keep a recognized Fallen World bank filename.')
            payloads = {}
            for group, keyname in BANK_KEYS.items():
                node = self.nodes.get((SECTION, keyname))
                if node is None:
                    if group in ('main', 'trophies', 'hero_xp', 'skill_tiers'):
                        raise BankError('Required Fallen World record is missing: ' + group)
                    continue
                leaves = [leaf for leaf in node if isinstance(leaf.tag, str)]
                if len(leaves) != 1 or leaves[0].tag != 'Value' or set(leaves[0].attrib) != {'string'}:
                    raise BankError('Expected string payload at ' + keyname)
                payloads[group] = decode(leaves[0].get('string'), self.player, group)
                self.present.add(group)
            main = payloads['main'].split()
            if len(main) != 12 or main[0] != self.player:
                raise BankError('Main progression payload does not match the original player handle or schema.')
            values = dict(zip(MAIN_FIELDS, _numbers(main[1:], 11, 'Main progression')))
            damage = payloads.get('damage', self.player + ' 0 0').split()
            time = payloads.get('play_time', self.player + ' 0').split()
            evo = payloads.get('hero_tiers', self.player).split()
            if len(damage) != 3 or len(time) != 2 or not evo or any(words[0] != self.player for words in (damage, time, evo)):
                raise BankError('An auxiliary payload does not match the original player handle or schema.')
            values.update(damage_dealt=_decimal(damage[1], 'Damage dealt'), damage_taken=_decimal(damage[2], 'Damage taken'), play_time=integer(time[1], 'Play time'))
            words = payloads['trophies'].split()
            pages = self.profile['trophy_pages']
            if len(words) > len(pages):
                raise BankError('More trophy pages than this map schema supports.')
            words += [''] * (len(pages) - len(words))
            trophies = []
            for word, page in zip(words, pages):
                if len(word) > len(page['trophies']) or any(c not in '01' for c in word):
                    raise BankError('Unsupported trophy flag layout.')
                trophies.append(word.ljust(len(page['trophies']), '0'))
            self.state = State(values, tuple(trophies),
                _numbers(payloads['hero_xp'].split(), len(_xp_heroes(self.profile)), 'Hero XP', short=True, maximum=159510),
                _numbers(payloads['skill_tiers'].split(), 7, 'Skill tiers'),
                _numbers(evo[1:], len(self.profile['heroes']), 'Hero evolution', default=1, short=True, maximum=5))
            validate(self.state, self.profile)
            self.checks['structure'] = self.checks['source_bounds'] = True
            if signature is None:
                self._signature_status = 'Missing'
                raise BankError('Original native signature is required before editing.')
            self.signature_verified = signature_for(self.root, self.player, self.author, self.bank_name) == signature.get('value').upper()
            self._signature_status = 'Verified' if self.signature_verified else 'Mismatch'
            self.checks['signature'] = self.signature_verified
            if not self.signature_verified:
                raise BankError('Original native signature does not match the player, author and exact bank name.')
            self.warnings.append('Schema audited against cached publication 0.84; live acceptance of edited banks is untested.')
        except (BankError, ValueError, UnicodeError, ET.ParseError) as exc:
            self.errors.append(str(exc))

    @classmethod
    def read(cls, path, profile=None, *, player='', author=''):
        path = Path(path).resolve()
        with path.open('rb') as stream:
            raw = stream.read(LIMIT + 1)
        return cls(raw, path, profile, player=player, author=author)

    def signature_status(self):
        return self._signature_status

    def original_verified(self):
        if self.errors or not self.signature_verified:
            return False
        signature = self.root.find('Signature')
        return signature is not None and signature_for(self.root, self.player, self.author, self.bank_name) == signature.get('value', '').upper()

    def render(self, target):
        if not self.original_verified():
            raise BankError('Read-only: ' + '; '.join(self.errors or ['Original is unverified.']))
        validate(target, self.profile, before=self.state)
        if target == self.state:
            return self.raw, []
        root = copy.deepcopy(self.root)
        sections, nodes, signature = _inspect_root(root)
        changes = []
        for group, plain in _payloads(target, self.player).items():
            if plain == _payloads(self.state, self.player)[group]:
                continue
            keyname = BANK_KEYS[group]
            node = nodes.get((SECTION, keyname))
            if node is None:
                node = ET.SubElement(sections[SECTION], 'Key', name=keyname)
                ET.SubElement(node, 'Value', string='')
            node.find('Value').set('string', encode(plain, self.player, group))
            changes.append(group.replace('_', ' ').title() + ' updated')
        signature.set('value', signature_for(root, self.player, self.author, self.bank_name))
        output = ET.tostring(root, encoding='utf-8', xml_declaration=True)
        result = Bank(output, self.path, self.profile, player=self.player, author=self.author)
        if result.errors or result.state != target:
            raise BankError('Output round-trip failed: ' + '; '.join(result.errors))
        return output, changes


def _payloads(state, player):
    return {
        'main': player + ' ' + ' '.join(str(state.values[k]) for k in MAIN_FIELDS),
        'trophies': ' '.join(state.trophies) + ' ',
        'hero_xp': ' '.join(map(str, state.hero_xp)) + ' ',
        'skill_tiers': ' '.join(map(str, state.skill_tiers)) + ' ',
        'damage': player + ' ' + state.values['damage_dealt'] + ' ' + state.values['damage_taken'],
        'play_time': player + ' ' + str(state.values['play_time']),
        'hero_tiers': player + ' ' + ' '.join(map(str, state.hero_tiers)),
    }
