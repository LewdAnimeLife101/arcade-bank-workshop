"""Fallen World Last Stand profile."""
