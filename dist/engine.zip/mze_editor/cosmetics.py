"""Eligibility for the saved Sec/skn worker appearance in publication 2.58.

No donor or account entitlement is created here. The map's custom-skin restore
path merely checks key existence, but its selection UI requires a true flag;
this editor follows that stricter visible eligibility rule.
"""
from importlib import resources
import json
from zrc_editor.common import BankError

def metadata():
    return json.loads(resources.files('mze_editor').joinpath('cosmetics.json').read_text(encoding='utf-8'))

def eligible(spec,values):
    if 'requires_prestige' in spec:return values.get('PHR',0)>=spec['requires_prestige']
    if 'requires_flag' in spec:return values.get(spec['requires_flag']) is True
    return False

def choices(values):
    """Eligible choices plus the currently stored value, which can be retained."""
    result=[]
    for spec in metadata()['cosmetics']:
        if eligible(spec,values):
            suffix=' · prestige '+str(spec['requires_prestige']) if spec.get('requires_prestige') else ''
            result.append({'value':spec['value'],'label':spec['label']+suffix})
    current=values.get('skn','')
    if current not in {x['value'] for x in result}:
        result.append({'value':current,'label':'Existing skin (preserved): '+(current or 'no saved choice')})
    return result

def validate_selection(values,before):
    selected=values.get('skn','');original=before.get('skn','')
    if not isinstance(selected,str):raise BankError('Worker appearance: expected a skin code.')
    specs={x['value']:x for x in metadata()['cosmetics']};spec=specs.get(selected)
    dependency=None
    if spec:dependency='PHR' if 'requires_prestige' in spec else spec.get('requires_flag')
    changed=selected!=original or (dependency is not None and values.get(dependency)!=before.get(dependency))
    if not changed:return
    if not spec:raise BankError('Worker appearance: only verified eligible choices may be selected; existing unknown/account-specific choices can be preserved unchanged.')
    if not eligible(spec,values):
        requirement=('prestige '+str(spec['requires_prestige'])) if 'requires_prestige' in spec else ('the existing '+spec['label']+' unlock flag')
        raise BankError('Worker appearance '+spec['label']+' requires '+requirement+'. Choose another appearance or restore its prerequisite.')

def field(values):
    return {'key':'skn','section':'Sec','label':'Saved worker appearance','group':'Cosmetic selections','type':'string','default':'','editable':True,'options':choices(values),
            'description':'Choose an appearance already eligible from prestige or a true custom-skin unlock flag. Choices refresh after previewing prerequisite edits. Event, personal and direct donor choices are preserved only; this does not grant donor membership. Lowering a selected appearance prerequisite is blocked.'}
