"""Named game-menu availability and coupled bank prerequisite plans.

The selections themselves are match-local. These plans change only audited bank
requirements; they never create invented saved ability or equipment keys.
"""
from importlib import resources
import json
from zrc_editor.common import BankError
from .core import SPECS

def catalog():
    rows=[]
    for name in ('unlocks.json','unlock_extras.json'):
        data=json.loads(resources.files('mze_editor').joinpath(name).read_text(encoding='utf-8'))
        rows.extend(data if isinstance(data,list) else data['rows'])
    return rows

def satisfied(requirement,values):
    value=values[requirement['field']]
    return ('min' not in requirement or value>=requirement['min']) and ('equals' not in requirement or value==requirement['equals'])

def available(row,values):
    return any(all(satisfied(r,values) for r in branch) for branch in row.get('alternatives',[row.get('requirements',[])]))

def requirement_text(requirement):
    key=requirement['field'];spec=SPECS[key]
    if 'equals' in requirement:
        return spec['label']+('' if requirement['equals'] is True else ' = '+str(requirement['equals']))
    value=requirement['min']/(4096 if spec['type']=='fixed' else 1)
    return spec['label']+' at least '+format(value,'g')

def describe(values):
    rows=[]
    for item in catalog():
        met=available(item,values)
        branches=item.get('alternatives',[item.get('requirements',[])])
        needed=' OR '.join(' + '.join(requirement_text(r) for r in b) or 'Available by default' for b in branches)
        external=not item.get('grantable',True)
        mode=item.get('mode','All')
        note=item.get('runtime_note','')
        description=item.get('description','')+' Requirements: '+needed+'.'
        if mode!='All':description+=' Mode: '+mode+'.'
        if note:description+=' '+note
        label=item['label']+(' · '+mode if mode!='All' else '')
        row={'id':'unlock-status:'+item['id'],'label':label,'group':item['group'],
             'kind':'info','value':'External requirement' if external else 'Bank requirements met' if met else 'Requirements missing',
             'description':description,
             'readonly':True,'automatic':True}
        if not external and not met:row['action']='unlock:'+item['id']
        rows.append(row)
    return rows

def apply_grants(target,grants):
    for key,minimum in grants.items():
        spec=SPECS.get(key)
        if not spec or not spec.get('editable',True):raise BankError('Unlock plan references an unsupported field: '+key)
        target.values[key]=True if minimum is True else max(target.values[key],minimum)

def grant(state,identity):
    target=state.clone()
    items=catalog()
    if identity=='all':
        chosen=[row for row in items if row.get('grantable',True)]
        for key,spec in SPECS.items():
            if (key.startswith('achievement_') or key.startswith('challenge_')) and spec.get('editable',True):target.values[key]=True
        apply_grants(target,{'PHR':100,'easy_complete':True,'NIVO':200*4096,'WINS':50*4096,
                             'role_a':100,'role_e':100,'role_i':100,'role_f':100,'role_o':100,
                             'NIGHTELITE':35*4096,'elite_complete':True,
                             'NIGHTNMAR':35*4096,'nightmare_complete':True,
                             'HL':35*4096,'hell_complete':True,
                             'ims':35,'impossible_complete':True,'impossible_dna':True})
    else:
        chosen=[row for row in items if row['id']==identity]
        if not chosen:raise BankError('Unknown game unlock.')
        if not chosen[0].get('grantable',True):raise BankError('This option depends on runtime account access, not editable bank progression.')
    for row in chosen:apply_grants(target,row.get('grants',{}))
    return target,['Updated the saved prerequisites for '+('all supported bank-based unlocks' if identity=='all' else chosen[0]['label'])+'. Required completion markers are included even when the highest-night record was already reached. Match choices, event rules and external account eligibility remain controlled by the map.']
