"""Conservative source-derived editor for MineralZ Evolution 2.58 Banks.SC2Bank."""
from dataclasses import dataclass
from pathlib import Path
import copy, json
from importlib import resources
import xml.etree.ElementTree as ET
from zrc_editor.common import BankError
from zrc_editor.core import _inspect_root, signature_for
from zwl_editor.fixed import parse_fixed, format_fixed

FIELDS={"NIVO":("Probe level",0,200),"NIGHTMNHD":("Normal highest night",0,36),
        "NIGHTELITE":("Elite highest night",0,51)}
def load_profile():
    return json.loads(resources.files("mze_editor").joinpath("map_profile.json").read_text(encoding="utf-8"))
@dataclass(eq=True)
class State:
    values: dict
    def clone(self): return copy.deepcopy(self)
def validate(state,before=None):
    if set(state.values)!=set(FIELDS): raise BankError("Incomplete MineralZ Evolution editor state.")
    for key,(label,low,high) in FIELDS.items():
        value=state.values[key]
        if before is not None and value==before.values[key]:
            continue
        if isinstance(value,bool) or not isinstance(value,int) or not low*4096<=value<=high*4096:
            raise BankError(f"{label}: must be between {low} and {high}.")
class Bank:
    def __init__(self,raw,path=None,profile=None,*,player="",author=""):
        self.raw,self.path,self.player,self.author=raw,path,player,author
        self.bank_name=Path(path).stem if path else "Banks"; self.profile=profile or load_profile()
        self.errors=[]; self.warnings=[]; self.checks={}; self.state=None; self.signature_verified=False
        try:
            if len(raw)>4*1024*1024: raise BankError("Bank exceeds the 4 MB limit.")
            text=raw.decode("utf-8-sig")
            if "<!DOCTYPE" in text.upper() or "<!ENTITY" in text.upper(): raise BankError("DTD/entities are unsupported.")
            self.root=ET.fromstring(text,parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True,insert_pis=True)))
            _,nodes,signature=_inspect_root(self.root)
            if signature is None: raise BankError("Original native signature is required before editing.")
            self.signature_verified=signature_for(self.root,self.player,self.author,self.bank_name)==signature.get("value","").upper()
            self.checks["signature"]=self.signature_verified
            if not self.signature_verified: raise BankError("Original native signature does not match the player, author and exact bank name.")
            def fixed(key,default=None):
                node=nodes.get(("Sec",key)); leaf=node.find("Value") if node is not None else None
                if node is None and default is not None:return default
                if leaf is None or set(leaf.attrib)!={"fixed"}: raise BankError(f"Missing fixed Sec/{key}.")
                return parse_fixed(leaf.get("fixed"))
            # VERSION is written by reset/admin paths, never read by this loader.
            # Its absence/value is not a schema or publication discriminator.
            # Validate only relationships directly enforced by this source's loader.
            if fixed("NIVO") >= 51*4096 and fixed("NIVEXP") != fixed("NIVO")*1224:
                raise BankError("Unsupported original: Sec/NIVEXP does not match Sec/NIVO x 1224.")
            if fixed("KILLED") != fixed("NIGHTMNHD")*4788:
                raise BankError("Unsupported original: Sec/KILLED does not match Sec/NIGHTMNHD x 4788.")
            if fixed("NIGHTNMAR",0) >= 4096 and fixed("XPNB",0) != fixed("NIGHTNMAR")*1655:
                raise BankError("Unsupported original: Sec/XPNB does not match Sec/NIGHTNMAR x 1655.")
            if fixed("NIGHTNMAR",0) >= 35*4096 and fixed("XPNQ",0) != 59120*4096:
                raise BankError("Unsupported original: Sec/XPNQ is missing the Nightmare completion marker.")
            values={}
            for key in FIELDS:
                values[key]=fixed(key)
            self.state=State(values)
            # Existing source-tolerated values may be displayed even when they are
            # outside this editor's writable range; bounds apply when edited.
            self.warnings.append("Static source validation only; published-match acceptance has not been tested.")
        except (BankError,UnicodeDecodeError,ET.ParseError) as exc: self.errors.append(str(exc))
    @classmethod
    def read(cls,path,profile=None,*,player="",author=""):
        p=Path(path).resolve(); return cls(p.read_bytes(),p,profile,player=player,author=author)
    def signature_status(self): return "Verified" if self.signature_verified else "Mismatch"
    def render(self,target):
        if self.errors or not self.signature_verified: raise BankError("Read-only: "+"; ".join(self.errors))
        changed={key for key in FIELDS if target.values[key]!=self.state.values[key]}
        if not changed:
            return self.raw,["No fields changed; original bytes preserved."]
        validate(target,self.state); root=copy.deepcopy(self.root); _,nodes,signature=_inspect_root(root); values=dict(target.values)
        writes={key:values[key] for key in changed}
        if "NIVO" in changed: writes["NIVEXP"]=values["NIVO"]*1224
        if "NIGHTMNHD" in changed: writes["KILLED"]=values["NIGHTMNHD"]*4788
        if "NIGHTELITE" in changed and values["NIGHTELITE"]>=35*4096: writes["HEAL"]=21634*4096
        for key,value in writes.items():
            node=nodes.get(("Sec",key))
            if node is None:
                section=next(s for s in root.findall("Section") if s.get("name")=="Sec")
                node=ET.SubElement(section,"Key",name=key); ET.SubElement(node,"Value",fixed=format_fixed(value))
            else: node.find("Value").set("fixed",format_fixed(value))
        signature.set("value",signature_for(root,self.player,self.author,self.bank_name)); ET.indent(root,space="    ")
        raw=ET.tostring(root,encoding="utf-8",xml_declaration=True)+b"\n"; fresh=Bank(raw,self.path,self.profile,player=self.player,author=self.author)
        if fresh.errors or fresh.state!=target: raise BankError("Output failed signed read-back validation.")
        return raw,["Native signature and dependencies for changed fields regenerated; unrelated keys preserved."]
