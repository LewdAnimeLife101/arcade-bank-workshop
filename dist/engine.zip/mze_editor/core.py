"""Source-derived MineralZ Evolution 2.58 codec; no game or bank I/O on render."""
from dataclasses import dataclass
from pathlib import Path
import copy, json
from importlib import resources
import xml.etree.ElementTree as ET
from zrc_editor.common import BankError
from zrc_editor.core import _inspect_root, signature_for
from zwl_editor.fixed import parse_fixed, format_fixed
from .hashing import achievement_location

SCALE = 4096

def load_profile():
    return json.loads(resources.files('mze_editor').joinpath('map_profile.json').read_text(encoding='utf-8'))

SPECS = {x['key']: x for x in load_profile()['fields']}
FIELDS = {k: (v['label'], v.get('min', 0), v.get('max')) for k, v in SPECS.items()}

@dataclass(eq=True)
class State:
    values: dict
    def clone(self): return copy.deepcopy(self)

def validate(state, before=None):
    if set(state.values) != set(SPECS):
        raise BankError('Incomplete MineralZ Evolution editor state.')
    changed = {k for k in SPECS if before is None or state.values[k] != before.values[k]}
    for key in changed:
        spec, value = SPECS[key], state.values[key]
        if not spec.get('editable', True):
            raise BankError(spec['label'] + ': preserved read-only.')
        if spec['type'] == 'bool':
            if type(value) is not bool: raise BankError(spec['label'] + ': must be on or off.')
        else:
            scale = SCALE if spec['type'] == 'fixed' else 1
            if type(value) is not int or not spec.get('min', 0)*scale <= value <= spec['max']*scale:
                raise BankError(f"{spec['label']}: must be between {spec.get('min',0)} and {spec['max']}.")
            if spec.get('options') and value not in {x['value'] for x in spec['options']}:
                raise BankError(spec['label'] + ': select a supported option.')
    # Recheck equipped choices when their own field or its prerequisite changes.
    for cosmetic in load_profile()['building_cosmetics']:
        key = 'building_' + cosmetic['key']
        requirement = cosmetic['requirements'].get(str(state.values[key]))
        if requirement and (key in changed or requirement in changed):
            needed = 100 if requirement.startswith('role_') else 1
            if state.values[requirement] < needed:
                raise BankError(f"{SPECS[key]['label']} requires {SPECS[requirement]['label']}" + (' of at least 100.' if needed == 100 else '.'))

class Bank:
    def __init__(self, raw, path=None, profile=None, *, player='', author=''):
        self.raw, self.path, self.player, self.author = raw, path, player, author
        self.bank_name = Path(path).stem if path else 'Banks'
        self.profile = profile or load_profile()
        self.errors, self.warnings, self.checks = [], [], {}
        self.state, self.signature_verified = None, False
        try:
            if len(raw) > 4*1024*1024: raise BankError('Bank exceeds the 4 MB limit.')
            text = raw.decode('utf-8-sig')
            if '<!DOCTYPE' in text.upper() or '<!ENTITY' in text.upper(): raise BankError('DTD/entities are unsupported.')
            self.root = ET.fromstring(text, parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True, insert_pis=True)))
            _, nodes, signature = _inspect_root(self.root)
            if signature is None: raise BankError('Original native signature is required before editing.')
            self.signature_verified = signature_for(self.root, self.player, self.author, self.bank_name) == signature.get('value', '').upper()
            self.checks['signature'] = self.signature_verified
            if not self.signature_verified: raise BankError('Original native signature does not match the player, author and exact bank name.')

            def read(section, key, kind='fixed', default=None):
                node = nodes.get((section,key))
                if node is None and default is not None: return default
                leaf = node.find('Value') if node is not None else None
                if leaf is None or set(leaf.attrib) != {kind}: raise BankError(f'Missing or invalid {kind} {section}/{key}.')
                value = leaf.get(kind)
                if kind == 'fixed': return parse_fixed(value)
                if kind == 'int':
                    try: result = int(value)
                    except ValueError as exc: raise BankError(f'Invalid integer {section}/{key}.') from exc
                    if not -(2**31) <= result < 2**31: raise BankError(f'Integer overflow {section}/{key}.')
                    return result
                if kind == 'flag':
                    if value not in ('0','1','true','false'): raise BankError(f'Invalid flag {section}/{key}.')
                    return value in ('1','true')
                return value
            fixed = lambda key, default=None: read('Sec',key,'fixed',default)
            # VERSION is reset/admin metadata; the loader does not require it.
            if fixed('NIVO') >= 51*SCALE and fixed('NIVEXP') != fixed('NIVO')*1224:
                raise BankError('Unsupported original: Sec/NIVEXP does not match Sec/NIVO x 1224.')
            if fixed('KILLED') != fixed('NIGHTMNHD')*4788:
                raise BankError('Unsupported original: Sec/KILLED does not match Sec/NIGHTMNHD x 4788.')
            if fixed('NIGHTNMAR',0) >= SCALE and fixed('XPNB',0) != fixed('NIGHTNMAR')*1655:
                raise BankError('Unsupported original: Sec/XPNB does not match Sec/NIGHTNMAR x 1655.')
            if fixed('NIGHTNMAR',0) >= 35*SCALE and fixed('XPNQ',0) != 59120*SCALE:
                raise BankError('Unsupported original: Sec/XPNQ is missing the Nightmare completion marker.')
            if fixed('CODID',0) == 17*SCALE:
                raise BankError('Map-side CODID rejection marker present; this editor does not remove it.')
            values = {}
            for key,spec in SPECS.items():
                if key.startswith('role_'):
                    encoded = read('Sec',spec['storage_key'],'int',0)
                    values[key] = (abs(encoded) // spec['multiplier']) * (-1 if encoded < 0 else 1)
                elif key.startswith('achievement_'):
                    section, bankkey, expected = achievement_location(int(key.split('_')[1]))
                    values[key] = read(section,bankkey,'string','') == expected
                elif key.startswith('challenge_'):
                    values[key] = read('kev','ks'+key.split('_')[1],'flag',False)
                elif key.startswith('building_'):
                    values[key] = read('skk',key.removeprefix('building_'),'int',0)
                elif key in ('easy_complete','special_normal'):
                    bankkey,marker = ('EASY',35) if key == 'easy_complete' else ('ZUHIB',121186)
                    values[key] = fixed(bankkey,0) == marker*SCALE
                else:
                    kind = spec['type']
                    values[key] = read('Sec',key,kind,'' if kind=='string' else 0)
            self.state = State(values)
            self.warnings.extend([
                'Static source validation only; published-match acceptance has not been tested.',
                'Original native signature and supported record relationships are checked. Preserved prestige and Impossible checks are not validated by this profile.',
                'Prestige, Impossible account-dependent checks, donor entitlement and the selected probe cosmetic remain preserved read-only.',
                'Skills, colours, specialities and role mastery are calculated by the map from levels, completion markers and role wins; there are no separate saved unlock switches.'
            ])
        except (BankError, UnicodeDecodeError, ET.ParseError, ValueError) as exc:
            self.errors.append(str(exc))

    @classmethod
    def read(cls,path,profile=None,*,player='',author=''):
        p=Path(path).resolve()
        return cls(p.read_bytes(),p,profile,player=player,author=author)

    def signature_status(self): return 'Verified' if self.signature_verified else 'Mismatch'

    def render(self,target):
        if self.errors or not self.signature_verified: raise BankError('Read-only: '+'; '.join(self.errors))
        validate(target,self.state)
        changed={k for k in SPECS if target.values[k]!=self.state.values[k]}
        if not changed: return self.raw,['No fields changed; original bytes preserved.']
        root=copy.deepcopy(self.root)
        _,nodes,signature=_inspect_root(root)
        writes={}
        values=target.values
        def put(section,key,kind,value): writes[(section,key)]=(kind,value)
        def fixed(key,value): put('Sec',key,'fixed',value)
        for key in changed:
            value,spec=values[key],SPECS[key]
            if key.startswith('role_'): put('Sec',spec['storage_key'],'int',value*spec['multiplier'])
            elif key.startswith('achievement_'):
                section,bankkey,expected=achievement_location(int(key.split('_')[1]))
                put(section,bankkey,'string',expected if value else None)
            elif key.startswith('challenge_'):
                # Remove false flags: the saved-skin loader checks key existence.
                put('kev','ks'+key.split('_')[1],'flag',True if value else None)
                if key=='challenge_0' and value: put('reset','cs1','flag',True)
            elif key.startswith('building_'): put('skk',key.removeprefix('building_'),'int',value)
            elif key=='easy_complete': fixed('EASY',(35 if value else 0)*SCALE)
            elif key=='special_normal': fixed('ZUHIB',(121186 if value else 0)*SCALE)
            else: put('Sec',key,spec['type'],value)
        if 'NIVO' in changed: fixed('NIVEXP',values['NIVO']*1224)
        if 'NIGHTMNHD' in changed: fixed('KILLED',values['NIGHTMNHD']*4788)
        if 'NIGHTELITE' in changed and values['NIGHTELITE']>=35*SCALE: fixed('HEAL',21634*SCALE)
        if 'NIGHTNMAR' in changed:
            fixed('XPNB',values['NIGHTNMAR']*1655)
            if values['NIGHTNMAR']>=35*SCALE: fixed('XPNQ',59120*SCALE)
        if 'HL' in changed:
            fixed('HAL',values['HL']*1631)
            if values['HL']>=35*SCALE: fixed('HLO',25265*SCALE)
        for (section_name,key),(kind,value) in writes.items():
            section=next((s for s in root.findall('Section') if s.get('name')==section_name),None)
            node=nodes.get((section_name,key))
            if value is None:
                if node is not None: section.remove(node)
                continue
            if section is None: section=ET.SubElement(root,'Section',name=section_name)
            if node is None:
                node=ET.SubElement(section,'Key',name=key)
                leaf=ET.SubElement(node,'Value')
            else: leaf=node.find('Value')
            leaf.attrib.clear()
            leaf.set(kind,format_fixed(value) if kind=='fixed' else ('1' if value else '0') if kind=='flag' else str(value))
        signature.set('value',signature_for(root,self.player,self.author,self.bank_name))
        ET.indent(root,space='    ')
        raw=ET.tostring(root,encoding='utf-8',xml_declaration=True)+b'\n'
        fresh=Bank(raw,self.path,self.profile,player=self.player,author=self.author)
        if fresh.errors or fresh.state!=target: raise BankError('Output failed signed read-back validation: '+'; '.join(fresh.errors))
        return raw,['Native signature and changed-field dependencies regenerated; unrelated fields preserved.']
