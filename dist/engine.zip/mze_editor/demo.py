import xml.etree.ElementTree as ET
from zrc_editor.core import signature_for
def demo_bytes():
    root=ET.Element("Bank",version="1"); sec=ET.SubElement(root,"Section",name="Sec")
    values={"NIVO":1,"NIVEXP":1224,"NIGHTMNHD":0,"KILLED":0,"NIGHTELITE":0,"HEAL":0,"NIGHTNMAR":0,"XPNB":0,"XPNQ":0,"HL":0,"HAL":0,"HLO":0,"WINS":0,"VERSION":6}
    for key,value in values.items():
        node=ET.SubElement(sec,"Key",name=key); ET.SubElement(node,"Value",fixed=str(value))
    ET.SubElement(root,"Signature",value=signature_for(root,"1-S2-1-1234567","1-S2-1-7654321","Banks"))
    return ET.tostring(root,encoding="utf-8",xml_declaration=True)
