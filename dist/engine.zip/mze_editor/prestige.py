"""MineralZ Evolution 2.58 prestige triplet and derived unlocks.

Galaxy BankInit 2600–2612; progression writer 15155–15181; restoration
writer 16374–16389. Q12 literal 1.2=4915, floor multiplication and
truncating division are corroborated by the workspace SC2 native v5
diagnostic goldens. ABEMZEProbe20261025 subsequently matched all 146
forward/inverse/transition/overflow checks. This is isolated native arithmetic
evidence, not an observed edited-bank load in the published map.
"""
from zrc_editor.common import BankError

SCALE = 4096
FACTOR = 4915
CURVE_STAGES = 42
INT_MAX = 2147483647
# Highest identified unlock milestone, NOT a source hard cap on rank.
ALL_KNOWN_UNLOCKS_RANK = 100
PASSIVE_ROLE_CAP = 40

PERKS = (
    (1, 'Plasma Collector', 'Probe gathers one extra Plasma.'),
    (1, 'Red Laser', 'Probe gathers one extra Red Crystal.'),
    (1, 'Gas Gatherer', 'Probe gathers one extra Vespene.'),
    (2, 'Psi Storm', 'Adds the Psi Storm ability.'),
    (3, 'Damage Aura', 'Increases damage of nearby offensive units and structures.'),
    (4, 'Accumulative Reserves', 'Produces 24 times the current night of each mineral every night.'),
    (5, 'Hallucinator', 'Adds the ability to summon hallucinations.'),
    (6, 'Chrono Accelerator', 'Adds the ability to accelerate targets.'),
    (7, 'Crazy Mineralz', 'Produces a random mineral every second, scaled by night.'),
    (8, 'Speed Up', 'Adds the ability to speed up generators.'),
    (9, 'Healer Satellite', 'Adds the ability to deploy Healer Satellites.'),
    (10, 'Destroyer', 'Increases probe damage, doubles rock bounty and True Archon duration, and enables rock one-shot.'),
    (11, 'Guardian Shield', 'Adds the ability to permanently protect targets.'),
    (12, 'Core Inside', 'Allows a core inside the probe; its colour follows the chosen role.'),
)

def _integer(value, label, *, nonnegative=True):
    low = 0 if nonnegative else -2147483648
    if type(value) is not int or not low <= value <= INT_MAX:
        raise BankError(f'{label}: expected a signed 32-bit'+(' nonnegative' if nonnegative else '')+' integer.')
    return value

def curve_value(stages):
    """Raw Q12 PR for 0…42 earned recurrence stages, without overflow."""
    _integer(stages, 'Prestige recurrence stages')
    if stages > CURVE_STAGES:
        raise BankError('Prestige recurrence stops after 42 stages; later ranks use PHR2.')
    raw = 0
    for _ in range(stages):
        raw = ((raw + 39*SCALE) * FACTOR) // SCALE
        if raw > INT_MAX:
            raise BankError('Prestige recurrence overflow.')
    return raw

def curve_rank(pr_raw):
    """Source loader's repeated divide/subtract count; source-valid noncanonical
    PR values are allowed. Negative PR has zero stages in the original loader.
    """
    _integer(pr_raw, 'PR raw fixed value', nonnegative=False)
    count = 0
    while pr_raw >= 40*SCALE:
        # Inputs are positive while in the loop: // equals truncation to zero.
        pr_raw = (pr_raw*SCALE)//FACTOR - 39*SCALE
        count += 1
        if count > CURVE_STAGES:
            raise BankError('Prestige recurrence failed to converge within its fixed storage range.')
    return count

def validate_triplet(rank, pr_raw, extra):
    """Validate the source's dependency, keeping writable ranks nonnegative.

    PR is not required to equal the canonical writer output: the game's loader
    only counts its stages. This avoids rejecting source-valid old rounding.
    """
    _integer(rank, 'Prestige rank')
    _integer(extra, 'Additional prestige ranks')
    count = curve_rank(pr_raw)
    if count + extra != rank or (extra > 0 and rank < 42):
        raise BankError('Prestige dependencies do not match: inverse(PR) + PHR2 must equal PHR; additional ranks require PHR at least 42.')
    return count

def plan(rank):
    """Return atomic Sec writes: PHR int, PR raw fixed, PHR2 int.

    Unlike performing an in-game prestige reset, editing the saved triplet does
    not consume/reset level, XP, wins or difficulty records. Always write all
    three together, including PHR2=0 when reducing the rank below 43.
    """
    _integer(rank, 'Prestige rank')
    pr = curve_value(min(rank, CURVE_STAGES))
    extra = max(0, rank-CURVE_STAGES)
    validate_triplet(rank, pr, extra)
    return {'PHR': rank, 'PR': pr, 'PHR2': extra}

def unlock_summary(rank):
    """Describe source-derived unlocks; selected perk is a match-local choice."""
    values = plan(rank)
    base = curve_rank(values['PR'])
    return {
        'available_perks': [name for required,name,_ in PERKS if base >= required],
        'passive_role_level': min(rank, PASSIVE_ROLE_CAP),
        'prestige_cosmetic_indices': [i for i,required in enumerate((10,20,30,40,50)) if rank >= required],
        'prestige_achievement_indices': [i for i,required in zip(range(10,16),(1,5,12,20,40,100)) if rank >= required],
        'secret_worker_skin': rank >= 100,
        'note': 'Choose one prestige perk in-game. Rank 12 unlocks all 14 perk choices; passive role bonuses cap at 40. Rank 100 reaches every identified prestige unlock.'
    }
