"""Port of the map's signed-int32 achievement hash (Galaxy lines 1106–1194).

This is the achievement encoding, distinct from the native bank signature.
"""
ALPHABET = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'

def signed(value):
    return (value + 2**31) % 2**32 - 2**31

def positive(value):
    value = signed(value)
    return signed(-value) if value < 0 else value

def hash_int(text, seed, multiplier):
    value = seed
    for char in text:
        position = ALPHABET.find(char)
        value = positive(value * multiplier + max(position, 0) + 1)
    for multiplier, increment in [(-2048144777, -1028477379),
                                   (668265263, 374761393),
                                   (-1640531535, -2048144777)]:
        value = positive(value * multiplier + increment)
    return value

def hash_string(text):
    output = ''
    for value in (hash_int(text, 17, 131), hash_int(text, 8191, 257)):
        # None of the audited achievement inputs reaches signed INT_MIN.
        if value < 0:
            raise ValueError('Unsupported negative achievement hash.')
        for _ in range(8):
            output += ALPHABET[value % 62]
            value //= 62
    return output

def achievement_location(index):
    key = 'ach' + str(index)
    return hash_string('achievements'), hash_string(key), hash_string(key + 'true')
