"""Native-corroborated Q12 port of MineralZ Evolution 2.58 Impossible records.

Arithmetic source: SCRIPTS.galaxy 2547-2555, 9897-9915, 12505-12562.
The isolated ABEMZEProbe20261025 map corroborated 30 complete account/night
cases, six expected zero-divisor exclusions, all constant/intermediate values
and 21 Round tie/adjacent cases. This establishes arithmetic equivalence on
those cases, not acceptance of an edited bank in a published Arcade match.

ims is a highest-night record, not a number of wins. im encodes that record.
is is the night-35 win marker. imval is a separate DNA-qualified marker.
The final worker skin requires the two markers plus probe level 200.
"""
from dataclasses import dataclass
import re
from zwl_editor.common import BankError, trunc_div
from zwl_editor.fixed import SCALE, parse_fixed, int_fixed, wrap32, divide, sqrt_raw

MODEL_VERIFIED = True
MODEL_EVIDENCE = {
    'diagnostic':'ABEMZEProbe20261025',
    'native_output_sha256':'10a197bd41ba3ceecc4b1d440b28ab39f94a371e1d3f078e559764aeb85a0c50',
    'source_archive_sha256':'fe86e707f0dc45556ce2079dea830b696a75706ceb99a579b8b5e73c9794c57e',
    'complete_cases':30,'zero_divisor_cases':6,'round_cases':21,
    'published_match_tested':False,
}
MAX_NIGHT = 52427  # 10*n + remainder (<10) must fit a positive signed Q12.


def multiply(a, b):
    return wrap32((a*b)//SCALE)


def modulo(a, b):
    if b == 0:
        raise BankError('Impossible arithmetic has a zero modulo divisor for this account.')
    return wrap32(a-trunc_div(a,b)*b)


def round_candidate(raw):
    """SC2 Round: nearest integer, ties toward positive infinity.

    Corroborated at 21 positive/negative/tie-adjacent raw values in the
    isolated ABEMZEProbe20261025 diagnostic.
    """
    return wrap32(((raw+SCALE//2)//SCALE)*SCALE)


def _root(raw):
    if raw<=0:
        raise BankError('Impossible arithmetic requires a positive square-root input.')
    return sqrt_raw(raw)


def _product(values):
    result=values[0]
    for item in values[1:]:result=multiply(result,item)
    return result


def handle_term(player):
    if not re.fullmatch(r'[1-5]-S2-[1-9]-[0-9]+',player or ''):
        raise BankError('Impossible records require the original SC2 player handle.')
    # Source replaces characters 1..8 (inclusive) with "0", not just the
    # prefix. Thus the first digit of an ordinary account suffix is removed.
    integer=int('0'+player[8:])
    if integer>2147483647:
        raise BankError('Impossible handle slice exceeds signed integer storage.')
    return int_fixed(integer)


def constants_candidate():
    """The source's nine sequential constants, returned as raw Q12."""
    values=[multiply(modulo(parse_fixed('86.2'),_root(5*SCALE)),parse_fixed('47.42'))]
    for literal in ('1229.3','9139.1','12213.1','113.1','678.9','422.4','397.4','333.22'):
        # The final source expression deliberately skips constant 8 and starts
        # with constant 7 (auto25233686_ai, not auto25233686_ae).
        previous=values[:-1] if literal=='333.22' else values
        terms=[modulo(parse_fixed(literal),_root(v)) for v in reversed(previous)]
        terms.append(modulo(parse_fixed(literal),_root(5*SCALE)))
        result=round_candidate(_product(terms))
        if literal!='333.22':result=multiply(result,2*SCALE)
        values.append(result)
    return tuple(values)


@dataclass(frozen=True)
class Parameters:
    shield_modulus:int
    heal:int
    dna_marker:int
    constants:tuple


def parameters_candidate(player):
    constants=constants_candidate()
    inputs=[constants[0],86*SCALE,*constants[1:]]
    def branch(roots,final_root):
        terms=[modulo(v,_root(r*SCALE)) for v,r in zip(inputs,roots)]
        terms.append(modulo(handle_term(player),65537*SCALE))
        residue=modulo(_product(terms),_root(final_root*SCALE))
        return divide(round_candidate(multiply(residue,10000*SCALE)),1000*SCALE)
    shield_base=branch((5,8,3,2,7,3,6,7,5,3),3)
    shield_modulus=abs(modulo(shield_base,10*SCALE))
    if not shield_modulus:
        raise BankError('Impossible shield divisor is zero for this account.')
    heal=branch((3,2,7,8,17,3,2,5,11,5),10)
    dna_marker=branch((2,3,6,5,7,3,2,5,11,5),10)
    return Parameters(shield_modulus,heal,dna_marker,constants)


def calculate_candidate(player,night):
    """Return record and win/DNA markers using corroborated integer arithmetic."""
    if type(night) is not int or not 0<=night<=MAX_NIGHT:
        raise BankError(f'Impossible highest night must be between 0 and {MAX_NIGHT}.')
    p=parameters_candidate(player)
    encoded=night*10*SCALE+abs(modulo(night*10*SCALE,p.shield_modulus))
    if encoded>=2**31:raise BankError('Impossible encoded record overflows positive fixed storage.')
    shield35=abs(modulo(350*SCALE,p.shield_modulus))
    if p.heal==0:raise BankError('Impossible win-marker divisor is zero for this account.')
    win=multiply(divide(shield35,p.heal),parse_fixed('3.4'))
    return {'ims':night,'im':encoded,'is':win,'imval':p.dna_marker}


def plan(player,night,*,completed=None,dna_complete=None):
    """Return coupled writes only; caller preserves unspecified markers.

    completed=True reproduces the normal night-35 win token even when a later
    highest-night record is selected. dna_complete is an independent marker;
    it does not assert the user's account has actually completed that match.
    False clears the explicit marker; None preserves its original bytes.
    """
    if not MODEL_VERIFIED:
        raise BankError('Impossible arithmetic requires native diagnostic verification before export.')
    if any(x is not None and type(x) is not bool for x in (completed,dna_complete)):
        raise BankError('Impossible completion selections must be on or off.')
    if completed is True and night<35:
        raise BankError('Impossible completion requires a highest-night record of at least 35.')
    values=calculate_candidate(player,night)
    if completed is False and values['is']==0:
        raise BankError('This account has a zero-valued win token; clearing to zero would still match the game unlock check.')
    if dna_complete is False and values['imval']==0:
        raise BankError('This account has a zero-valued DNA token; clearing to zero would still match the game unlock check.')
    writes={'ims':values['ims'],'im':values['im']}
    if completed is not None:writes['is']=values['is'] if completed else 0
    if dna_complete is not None:writes['imval']=values['imval'] if dna_complete else 0
    return writes


def check_candidate(values,player):
    """Report modeled relationships; this is not an authorization/load verdict."""
    expected=calculate_candidate(player,values['ims'])
    return {'record':values.get('im',0)==expected['im'],
            'completed':values.get('is',0)==expected['is'],
            'dna_complete':values.get('imval',0)==expected['imval']}
