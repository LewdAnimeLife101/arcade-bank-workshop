"""Audited preset plans for MineralZ Evolution and Probes vs Zealot.

Only s['work'] is replaced, after the profile's complete signed read-back.
No filesystem/game I/O. Reduced counters do not establish genuine play history.
"""
from zrc_editor.common import BankError

COVERAGE = {
    'mineralz_evolution_258': {
        'partial': True,
        'summary': 'All supported achievements, challenge unlocks, skills, colours, workers, prestige rewards and ordinary role cosmetics.',
        'differences': 'Both modes retain probe level 200 and prestige 100. Full uses the supported highest-night bounds and 1,000 wins per ordinary role. Reduced public records use night 35 and 100 wins per ordinary role, retaining every bank-based unlock.',
        'limits': ['High night bounds are arithmetic/loader support limits, not normal gameplay wave limits.',
                   'No extra donor, tester, administrator, event or Mercenary eligibility is granted.',
                   'Choose the unlocked worker, skill, speciality and role in-game. Current cosmetic choices are preserved.',
                   'Neither preset proves a history of legitimate matches; published-map load/save remains unobserved.'],
    },
    'probes_zealot_2118': {
        'partial': True,
        'summary': 'All 207 saved achievement flags and 32 level rewards, plus every identified rank skin on the main progression bank.',
        'differences': 'Both modes retain level 200 and every reward. Full uses 500,000 rank points and source achievement milestones. Reduced public records use Probe S100 and Zealot S50, the minimum rank tiers for all identified rank skins, with a finite match-counter template. Wins fund each selected rank.',
        'limits': ['Gameplay options banks contain preferences, not progression unlocks; opening one leaves its settings unchanged and explains which main bank to open.',
                   'Encrypted PvZ2MMR, identity, previous-match records and cosmetic/ability selections are preserved.',
                   'Reduced counters are an authored template, not verified earned history. Achievement flags can describe historical milestones beyond current counters. Level 200 remains visible.',
                   'Offline signed read-back does not confirm published-map acceptance.'],
    },
}
METADATA = COVERAGE


def _evolution(state, plausible):
    from mze_editor.unlocks import grant
    from mze_editor.core import SPECS
    target, notes = grant(state, 'all')
    values = target.values
    # Every ordinary role has a 100-win cosmetic. WIP Mercenary has a separate
    # account gate and is intentionally not modified by a progression preset.
    for key in ('role_a', 'role_e', 'role_i', 'role_f', 'role_o'):
        values[key] = 100 if plausible else max(values[key], 1000)
    values['WINS'] = 100 * 4096 if plausible else max(values['WINS'], 399 * 4096)
    for key in ('NIGHTMNHD', 'NIGHTELITE', 'NIGHTNMAR', 'HL'):
        values[key] = (35 if plausible else SPECS[key]['max']) * 4096
    values['ims'] = 35 if plausible else SPECS['ims']['max']
    notes.append('Every bank-based unlock remains available in both modes, including ordinary role cosmetics and explicit difficulty-completion markers.')
    notes.append('Highest nights normalized to 35 and ordinary role wins to 100.' if plausible else 'Highest nights use documented arithmetic/loader support bounds; these are not claims about normal gameplay wave caps.')
    return target, notes


def _probes(bank, state, plausible):
    from pvz_editor.core import NAMES, level_xp
    target = state.clone()
    if bank.bank_name != NAMES[0]:
        return target, ['This is a preference bank. Progression unlocks are stored in ProbesvZealot2.SC2Bank; open that main bank to apply either unlock preset. No preference, ability or cosmetic selection was changed.']
    values = target.values
    for spec in bank.profile['fields']:
        if spec['type'] == 'bool' and spec.get('editable', True) and spec['section'] in ('Achievments', 'AchievmentsHuman', 'AchievmentsVampire', 'Rewards'):
            values[spec['key']] = True
    role_targets = {
        'HumanStats': (111000, 51), # S100: (points-12000)//1000 + 1
        'VampireStats': (61000, 45), # S50; highest Zealot rank-skin tier
    }
    for section, (minimum_points, minimum_level) in role_targets.items():
        points = minimum_points if plausible else 500000
        values[section+'/Points'] = points
        values[section+'/XP'] = level_xp(200)
        # Use the ceiling rather than exploiting the source's integer-division
        # remainder. Avoid the source's zero-wins exception entirely.
        minimum_wins = max(1, (points - 1000 + 374)//375)
        values[section+'/Wins'] = minimum_wins if plausible else max(values[section+'/Wins'], 2500, minimum_wins)
        if plausible:
            values[section+'/Losses'] = (minimum_wins+2)//3
            values[section+'/WinningStreak'] = 3
            values[section+'/Hours'] = 20*(values[section+'/Wins'] + values[section+'/Losses'])
        else:
            values[section+'/WinningStreak'] = min(values[section+'/WinningStreak'], values[section+'/Wins'])
            values[section+'/Hours'] = max(values[section+'/Hours'],150000)
    values['TotalStats/Points'] = (values['HumanStats/Points'] + values['VampireStats/Points'])//2
    values['TotalStats/Wins'] = values['HumanStats/Wins'] + values['VampireStats/Wins']
    values['TotalStats/Losses'] = values['HumanStats/Losses'] + values['VampireStats/Losses']
    values['TotalStats/Hours'] = values['HumanStats/Hours'] + values['VampireStats/Hours']
    values['TotalStats/XP'] = min(level_xp(200), values['HumanStats/XP'] + values['VampireStats/XP'])
    values['TotalStats/WinningStreak'] = 3 if plausible else min(values['TotalStats/WinningStreak'],values['TotalStats/Wins'])
    if plausible:
        values['HumanStats/KilledVampires'] = values['HumanStats/Wins']
        values['VampireStats/KilledBuilders'] = 3*values['VampireStats/Wins']
        values['VampireStats/KilledSlayers'] = values['VampireStats/Wins']
        values['VampireStats/KilledUnits'] = 10*values['VampireStats/Wins']
    else:
        # Highest direct lifetime-kill achievement milestones in this source.
        values['HumanStats/KilledVampires'] = max(values['HumanStats/KilledVampires'],2500)
        values['VampireStats/KilledBuilders'] = max(values['VampireStats/KilledBuilders'],2500)
        values['VampireStats/KilledUnits'] = max(values['VampireStats/KilledUnits'], values['VampireStats/KilledBuilders'] + values['VampireStats/KilledSlayers'])
    return target, [
        'Enabled all 207 saved achievements and 32 rewards. Role XP and rank points fund every identified level reward and rank skin.',
        'Reduced mode retains visible level 200 with Probe S100 and Zealot S50. Match counters use a finite authored template; this is not proof of earned history.' if plausible else 'Full mode uses level 200, 500,000 rank points and the documented lifetime-win, time and kill achievement milestones.',
        'Games and rank text are recalculated by the codec. Encrypted MMR, identity, previous-match records and companion preferences are preserved.',
    ]


def apply(s, plausible: bool):
    """Validate a complete preset and update only the pending in-memory state."""
    if type(plausible) is not bool:
        raise BankError('Choose a supported preset mode.')
    bank = s['bank']
    if s['profile'] == 'mineralz_evolution_258':
        target, notes = _evolution(s['work'], plausible)
    elif s['profile'] == 'probes_zealot_2118':
        target, notes = _probes(bank, s['work'], plausible)
    else:
        raise BankError('This preset module does not support that map profile.')
    # render validates all original protections and dependent fields, signs in
    # the original account context, then constructs and compares a fresh bank.
    # No session mutation occurs if any check fails.
    _raw, effective, render_notes = bank.render(target)
    s['work'] = effective
    return notes + render_notes
