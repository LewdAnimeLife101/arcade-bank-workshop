"""Bounded primitive SC2 bank XML reader used by the Mineralz profile."""
from pathlib import Path
import hashlib
import xml.etree.ElementTree as ET
from zwl_editor.common import BankError,integer,INT_MIN,INT_MAX
from zwl_editor.fixed import parse_fixed

class XMLBank:
    def parse(self,raw,path):
        if len(raw)>4*1024*1024: raise BankError("Bank exceeds the 4 MB limit.")
        try: text=raw.decode("utf-8-sig")
        except UnicodeDecodeError as exc: raise BankError("Expected UTF-8 SC2 bank.") from exc
        if "<!DOCTYPE" in text.upper() or "<!ENTITY" in text.upper(): raise BankError("DTD/entities are unsupported.")
        try: self.root=ET.fromstring(text,parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True,insert_pis=True)))
        except ET.ParseError as exc: raise BankError(f"Invalid XML: {exc}") from exc
        if self.root.tag!="Bank": raise BankError("Expected Bank root.")
        self.raw,self.path=raw,path
        self.digest=hashlib.sha256(raw).hexdigest()
        self.values={}; sections=set()
        for section in self.root.findall("Section"):
            name=section.get("name")
            if name is None or name in sections: raise BankError("Missing or duplicate section.")
            sections.add(name)
            for key in section.findall("Key"):
                k=key.get("name")
                if k is None or (name,k) in self.values: raise BankError("Missing or duplicate key.")
                self.values[(name,k)]=key

    def get(self,section,key,kind,default=None,required=False):
        node=self.values.get((section,key))
        if node is None:
            if required: raise BankError(f"Missing {section}/{key}.")
            return default
        children=[e for e in node if isinstance(e.tag,str)]
        if len(children)!=1 or children[0].tag!="Value" or set(children[0].attrib)!={kind} or len(children[0]) or any((s or "").strip() for s in (node.text,children[0].text,children[0].tail)):
            raise BankError(f"{section}/{key}: expected one {kind} Value.")
        text=children[0].get(kind)
        if kind=="int": return integer(text,f"{section}/{key}",INT_MIN,INT_MAX)
        if kind=="fixed": return parse_fixed(text)
        if kind=="flag":
            if text not in ("0","1"): raise BankError("Invalid flag.")
            return text=="1"
        return text
