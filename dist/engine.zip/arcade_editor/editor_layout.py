"""Presentation-only grouping; stable field identities and codecs stay unchanged."""
import json,re

ORDER=['Progress & resources','Heroes','Skills & perks','Equipment & glyphs',
       'Achievements & challenges','Records & history','Appearance','Settings','Advanced & preserved']

def organize(rows,pid,profile):
    heroes={str(h['id']):h.get('name',h.get('label','Hero '+str(h['id']))) for h in profile.get('heroes',[]) if 'id' in h}
    heroes={key:('Blood Elf' if name=='BloodElf' else name) for key,name in heroes.items()}
    for row in rows:
        group=row['group'];label=row['label'];category=None
        if pid=='reign':
            try:path=json.loads(row['id']);key=path[-1][-1] if isinstance(path[-1],list) else ''
            except (ValueError,TypeError):key=''
            match=re.fullmatch(r'Hero(\d+)GSlot(\d+)GStat(Type|Value|QP|T)',key)
            if match:
                hero,slot,_=match.groups();slot=int(slot)
                row['group']=('Equipped glyphs' if slot>=91 else 'Glyph storage')+' · '+heroes.get(hero,'Reserved hero '+hero)
                category='Equipment & glyphs' if hero in heroes else 'Advanced & preserved'
                row['description']='Advanced glyph encoding. '+row.get('description','')
            elif group=='Perks':
                category='Skills & perks'
                if label.startswith('Perk '):
                    row['group']='Unmapped & unused perks';category='Advanced & preserved'
                elif 'Damage Enhancement' in label:row['group']='Damage perks'
                elif 'Mastery' in label:row['group']='Hero mastery perks'
                elif any(x in label for x in ('Item','Glyph','Charm','Find')):row['group']='Equipment & loot perks'
                else:row['group']='General perks'
            elif group in ('Ascendancy','Hero perk records'):
                name=next((n for n in heroes.values() if label.replace(' ','').startswith(n.replace(' ',''))),None)
                if name:row['group']=('Ascendancy' if group=='Ascendancy' else 'Hero perks')+' · '+name
                category='Skills & perks' if name else 'Advanced & preserved'
            elif group in ('Time and records','Shop records'):
                name=label.split(' · ')[0] if ' · ' in label else 'Global'
                row['group']=('Records' if group=='Time and records' else 'Dungeon clears')+' · '+name
                category='Records & history'
        if category is None and group=='Progress' and label in ('Highest wave','Best solo difficulty'):
            row['group']='Best records';category='Records & history'
        if category is None:
            if 'reserved' in label.lower() or group in ('Preserved fields','Format','Identity (read-only)','Previous match (read-only)'):
                category='Advanced & preserved'
            elif group.startswith(('Soul jewel','Glyph')) or group=='Charms':category='Equipment & glyphs'
            elif group.startswith('Hero') or group in ('Heroes','Evolutions','Worker unlocks'):category='Heroes'
            elif any(x in group.lower() for x in ('achievement','challenge','troph')):category='Achievements & challenges'
            elif any(x in group.lower() for x in ('cosmetic','colour','customization')):category='Appearance'
            elif group=='Settings':category='Settings'
            elif any(x in group.lower() for x in ('perk','skill','specialit','ascend','talent','mastery','reward')):category='Skills & perks'
            elif any(x in group.lower() for x in ('record','night','history','kills','wins','counter','difficulty')):category='Records & history'
            else:category='Progress & resources'
        row['category']=category
    rank={name:i for i,name in enumerate(ORDER)}
    return sorted(rows,key=lambda r:rank[r['category']])
