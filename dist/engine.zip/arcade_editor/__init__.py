"""One offline application with isolated StarCraft II bank profiles."""
__version__ = "0.14.0"
