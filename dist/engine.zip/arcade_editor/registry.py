"""Explicit profile registry and conservative structural suggestions."""
from dataclasses import dataclass
from importlib import import_module
from pathlib import Path
import xml.etree.ElementTree as ET

from zwl_editor.common import BankError

@dataclass(frozen=True)
class Profile:
    id: str
    label: str
    map_id: int
    bank_name: str
    package: str
    description: str

PROFILES=(
    Profile("probes_zealot_2118","Probes vs Zealot 2 Updated · 2.118",308522,"ProbesvZealot2","pvz_editor","Probe and Zealot progression, achievements, rewards and saved preferences."),
    Profile("unity","Zombie World Unity · 0.928",293070,"zombieworldu","zwu_editor","Talents, TP, prestige, class kills, wins and evolutions."),
    Profile("liberty","Zombie World Liberty · 0.233",345748,"DirectStrike","zwl_editor","Per-hero progression, ascensions, challenges, souls and dust."),
    Profile("mineralz","Mineralz Survival 2 · 2.62",369775,"MineralzSurvival2","mineralz_editor","Probe level, experience, nights, wins, streaks and achievements."),
    Profile("reign","Zombie World: Reign of Chaos · 0.291",326447,"HackersWillBeBanned","zrc_editor","Softcore and Hardcore progress, currencies, perks and records."),
    Profile("fallen","Fallen World: Last Stand New Beginning · 0.84",379420,"FWLSBank","fwls_editor","Saved skill progression, hero XP, tier unlocks, trophies and records."),
    Profile("mineralz_evolution_258","MineralZ Evolution [Updated] · 2.58",344126,"Banks","mze_editor","Prestige, perk choices, difficulty records, role wins, achievements and eligible cosmetics."),
)
BY_ID={p.id:p for p in PROFILES}

def get_profile(profile_id):
    try: return BY_ID[profile_id]
    except KeyError as exc: raise BankError("Unknown editor profile.") from exc

def suggest(raw:bytes):
    """Suggest by typed structure, never equate it with proof of writer version."""
    if len(raw)>4*1024*1024: raise BankError("Bank exceeds the 4 MB limit.")
    try: text=raw.decode("utf-8-sig")
    except UnicodeDecodeError as exc: raise BankError("Only UTF-8 banks are supported.") from exc
    if "<!DOCTYPE" in text.upper() or "<!ENTITY" in text.upper(): raise BankError("DTD/entity declarations are unsupported.")
    try: root=ET.fromstring(text)
    except ET.ParseError as exc: raise BankError(f"Invalid XML: {exc}") from exc
    if root.tag!="Bank": raise BankError("Expected an SC2 Bank document.")
    sections={s.get("name"):{k.get("name") for k in s.findall("Key")} for s in root.findall("Section")}
    matches=[]
    if {"PlayerIDNumber","TP"}.issubset(sections): matches.append(BY_ID["unity"])
    if {"Primary","Version","Purchases"}.issubset(sections): matches.append(BY_ID["liberty"])
    if {"CP1","CP2","Achievements","version"}.issubset(sections.get("sec",set())): matches.append(BY_ID["mineralz"])
    if {"Statistics","Evolutions","GameDecoder"}.issubset(sections) and "KeyVariant" in sections["GameDecoder"]: matches.append(BY_ID["reign"])
    if {"tHe_AdMiN_sAiD_iT_wAs_Ok","I_dIDnT_cHeAt","DoNt_ChEaT_kIdS"}.issubset(sections.get("|||||",set())): matches.append(BY_ID["fallen"])
    if {"NIVO","NIVEXP","NIGHTMNHD","KILLED","NIGHTELITE"}.issubset(sections.get("Sec",set())): matches.append(BY_ID["mineralz_evolution_258"])
    from pvz_editor.core import matches_structure
    if matches_structure(root): matches.append(BY_ID["probes_zealot_2118"])
    return matches

def inspect(path:Path,profile_id="auto",player="",author=""):
    path=Path(path)
    if path.stat().st_size>4*1024*1024: raise BankError("Bank exceeds the 4 MB limit.")
    matches=suggest(path.read_bytes())
    if profile_id=="auto":
        if len(matches)!=1: raise BankError("No unique profile suggestion. Select a supported map explicitly.")
        profile=matches[0]
    else: profile=get_profile(profile_id)
    if len(matches)!=1 or matches[0].id!=profile.id: raise BankError("The bank structure does not uniquely match the selected profile.")
    module=import_module(profile.package+".core")
    if profile.id=="unity": bank=module.Bank.read(path)
    elif profile.id in ("reign","fallen","mineralz_evolution_258","probes_zealot_2118"): bank=module.Bank.read(path,player=player,author=author)
    else: bank=module.Bank.read(path,player=player)
    return {"ok":not bank.errors,"profile":profile.id,"map_id":profile.map_id,"profile_label":profile.label,
            "errors":bank.errors,"warnings":bank.warnings,"checks":getattr(bank,"checks",{}),
            "signature":bank.signature_status() if profile.id in ("unity","reign","fallen","mineralz_evolution_258","probes_zealot_2118") else "Not used by this profile",
            "writer_map_version_proven":False,"live_game_acceptance_tested":False,"read_only":True}
