"""Pending-edit RPG presets; never writes a bank or invents account access.

The history template is deliberately authored, not reconstructed history. Game
dependencies are delegated to the audited per-map plans and signed renderers.
"""

COVERAGE = {
    'reign': {
        'summary': 'Supported perks, 11 heroes at level 105/evolution 8, mastery, charms, equipment, glyphs and content unlocks; equips reviewed powerful loadouts where saved carriers exist.',
        'differences': 'Both variants apply the same progression, loadouts and reserves of at least 10 million gems/1 million rubies. Full raises display history to at least 1 million kills, wave 500 and 1,290 hours. The template uses 129 hours, 250,000 kills, wave 150 and reconciled per-hero counters. Functional solo records and unsupported legacy records stay intact.',
        'limits': [
            'Partial coverage: missing hero units cannot be created; absent/full stashes or bags, native locks and unknown items can prevent equipment changes. Hardcore has no stash.',
            'Unresolved/reserved perks, account entitlements, mutually exclusive ability choices and unsupported data are preserved. Charms are owned/upgraded but selected charm loadouts are preserved.',
            'Ordinary/Kalimdor records affect rewards and unlocks; their functional values cannot be hidden while retaining those effects. Reserved hero 6 and shop 10 history are preserved, so totals can exceed the template.',
            'The template is generated history, not proof of earned progress. No measured relationship connects hours/kills to XP or gear. Published-map loadout acceptance remains untested.',
            'Currency reserves and full-history floors are authored useful amounts, not discovered natural maxima. Existing larger balances are retained; integer storage maxima are not used as gameplay caps.',
        ],
        'partial': True,
    },
    'fallen': {
        'summary': 'Main-bank supported trophy flags, level 10,000, 11 saved hero XP records at level 100, rank-IV skill tiers, Marine tier 2, at least 65 ascensions and maximum Veteran bonus.',
        'differences': 'Both variants fund at least 1 million spendable score and the same progression. Full raises history to at least 20 million kills, wave 2,000, 10,000 missions, 480 million minerals, 10 million healing and 2,580 hours. The template uses 10 million kills, wave 1,000, 5,000 missions, 240 million minerals, 5 million healing and 1,290 hours. Both retain the maximum Veteran bonus.',
        'limits': [
            'MAIN BANK ONLY: use the separate funded-skills action with FWLSBank2 to install skill allocations. This preset only funds them; it does not edit a companion file.',
            'Special skills cannot all be maxed simultaneously: supported trophies supply 6,935 points; all caps cost 7,950. Extras purchases are not saved and must be bought each match.',
            '10,000,000 kills are required for the maximum Veteran damage/life bonus. A low-kill or low-level appearance cannot retain every maximum gameplay benefit. Positive ascension also replaces the zero-ascension Rookie state.',
            'Unsupported hero evolution chains, staff commands, restricted flags and account gates remain unchanged. This profile targets the audited legacy map version.',
            'The template is generated history, not proof of earned progress or live-map acceptance. Its collection/wave floors match trophy descriptions; hours and damage values are authored examples.',
            'The 1-million-score reserve is spendable by Marine evolution. It and the larger full-history floors are authored values, not natural gameplay maxima. Existing larger functional balances are retained.',
        ],
        'partial': True,
    },
}


def _reign_template(bank, state):
    """Normalize known display counters, leaving functional records untouched."""
    heroes = [h['id'] for h in bank.profile['heroes']
              if ('Hero', h['unit_key']) in bank.nodes]
    values = state.values
    values['Statistics', 'TotalKills'] = 250000
    values['Statistics', 'HighestWave'] = 150
    # An untouched reserved slot may contain authentic legacy progress. Never
    # change it just to force an attractive global total.
    if heroes:
        ticks, extra = divmod(464400 // 20, len(heroes))
        for index, hero in enumerate(heroes):
            values['GameTS', f'TP{hero}'] = (ticks + (index < extra)) * 20
            values['GameTS', f'DH{hero}'] = 3
            for shop in range(1, 10):
                values['GameTS', f'H{hero}S{shop}'] = 2
    values['GameTS', 'TP0'] = max(464400, sum(values['GameTS', f'TP{h}'] for h in range(1, 13)))
    values['GameTS', 'DH0'] = sum(values['GameTS', f'DH{h}'] for h in range(1, 13))
    for shop in range(1, 10):
        values['GameTS', f'H0S{shop}'] = sum(values['GameTS', f'H{h}S{shop}'] for h in range(1, 13))
    from zrc_editor.dependencies import effective_ordinary_record
    for record, best, fastest, global_record in (
        ('BS', 'BST', 'FST', effective_ordinary_record(state)),
        ('KBS', 'KBST', 'KFST', values['Diseases', 'KPlague']),
    ):
        for hero in [0, *heroes]:
            level = global_record if hero == 0 else values['GameTS', f'{record}{hero}']
            values['GameTS', f'{best}{hero}'] = 1800 if level else 0
            values['GameTS', f'{fastest}{hero}'] = 1200 if level else 0
        # A preserved older/reserved hero can have a faster real record.
        known = [values['GameTS', f'{fastest}{h}'] for h in range(1, 13)
                 if values['GameTS', f'{fastest}{h}'] > 0]
        if global_record and known:
            values['GameTS', f'{fastest}0'] = min(1200, min(known))
    return [
        'AUTHORED HISTORY TEMPLATE: 250,000 kills and wave 150; 129 hours split in 20-second ticks across existing saved heroes, three deaths and two clears of each shop 1–9 per saved hero. Global counters include preserved other hero records.',
        'Positive solo records receive 30-minute best-level times and 20-minute fastest times; global fastest also respects preserved faster records. Functional solo levels themselves are unchanged.',
        'No hero carrier means no invented per-hero history: the global 129-hour template is still applied, subject to retained hero totals. Reserved hero 6, shop 10 and unsupported historical fields are preserved.',
    ]


def _fallen_template(state):
    # Trophy description thresholds are in data/fallen/map_profile.json:
    # Mineral Collector V, Healing V, Mission Improbable V, Thousand Waves.
    state.values.update(kills=10000000, highest_wave=1000, missions=5000,
                        minerals=240000000, healing=5000000, deaths=1000,
                        play_time=1290 * 3600, damage_dealt='1000000000000',
                        damage_taken='1000000000')
    return [
        'AUTHORED HISTORY TEMPLATE: 10,000,000 kills, wave 1,000, 5,000 missions, 240,000,000 minerals and 5,000,000 healing retain the Veteran floor and match the supported collection/wave trophy thresholds.',
        '1,290 hours, 1,000 deaths, 1 trillion damage dealt and 1 billion damage taken are authored example counters, not reconstructed matches or measured earning rates. Spendable score and legacy total XP are preserved.',
    ]


def _full_history(profile, state):
    """Useful conspicuous floors rather than arbitrary representation maxima."""
    if profile == 'reign':
        floors = {('Statistics', 'TotalKills'): 1000000,
                  ('Statistics', 'HighestWave'): 500,
                  ('GameTS', 'TP0'): 1290 * 3600}
        for pair, floor in floors.items():
            state.values[pair] = max(floor, state.values[pair])
        return ['FULL HISTORY FLOORS: at least 1,000,000 kills, wave 500 and 1,290 game hours. These are authored display values, not natural caps or proof of completed matches; higher existing counters remain.']
    floors = dict(kills=20000000, highest_wave=2000, missions=10000,
                  minerals=480000000, healing=10000000, deaths=2000,
                  play_time=2580 * 3600, damage_dealt=2000000000000,
                  damage_taken=2000000000)
    for key, floor in floors.items():
        value = max(floor, int(state.values[key]))
        state.values[key] = str(value) if key.startswith('damage_') else value
    return ['FULL HISTORY FLOORS: at least 20 million kills, wave 2,000, 10,000 missions, 480 million minerals, 10 million healing, 2,000 deaths and 2,580 hours; 2 trillion damage dealt/2 billion taken. Collection and wave records exceed supported trophy thresholds. Values are authored, not gameplay maxima or earned-history evidence.']


def apply(s, plausible=False):
    """Return notes and atomically stage a supported preset in a session.

    All plans and final signed read-back must pass before mutating the session.
    The caller owns undo, preview and an explicit save/export operation.
    """
    if type(plausible) is not bool:
        raise ValueError('Choose a boolean history-template option.')
    profile = s['profile']
    if profile not in COVERAGE:
        raise ValueError('This preset only supports Reign and Fallen World.')
    bank = s['bank']
    if not bank.original_verified():
        raise ValueError('Original bank verification must pass before a preset can be applied.')
    work = s['work'].clone()
    levels, evos = dict(s.get('levels', {})), dict(s.get('evos', {}))
    notes = []
    if profile == 'reign':
        from zrc_editor import presets, loadouts, statistics
        plan = presets.build_plan(bank, work, levels=levels, hero_evolutions=evos)
        work, levels, evos = plan.state, plan.levels, plan.evolutions
        notes.extend(plan.notes)
        plan = loadouts.build_plan(bank, work, levels=levels, hero_evolutions=evos)
        work, levels, evos = plan.state, plan.levels, plan.hero_evolutions
        notes.extend(plan.notes)
        for pair, reserve in ((('GameDecoder', 'KeyVariant'), 10000000),
                              (('SC2Switcher', 'BlizzEnc'), 1000000)):
            work.values[pair] = max(reserve, work.values[pair])
        notes.append('Both variants provide reserves of at least 10,000,000 gems and 1,000,000 rubies. These spendable balances have no established natural cap; the chosen reserves are not maximum-int values.')
        if plausible:
            notes.extend(_reign_template(bank, work))
            plan = statistics.build_plan(bank, work, levels=levels, hero_evolutions=evos)
            work = plan.state
            # The generic plan says it did not fabricate history; that applies
            # only to its own reconciliation, not to our preceding template.
            notes.extend(n for n in plan.notes if n.startswith('REVIEW:'))
        else:
            notes.extend(_full_history(profile, work))
            plan = statistics.build_plan(bank, work, levels=levels, hero_evolutions=evos)
            work = plan.state
            notes.extend(n for n in plan.notes if n.startswith('REVIEW:'))
        raw, render_notes = bank.render(work, hero_levels=levels, hero_evolutions=evos)
    else:
        from fwls_editor.skill_preset import funded
        work, _, _ = funded(work, bank.profile)
        work.values['kills'] = max(10000000, work.values['kills'])
        work.values['score'] = max(1000000, work.values['score'])
        notes.extend([
            'Supported main-bank unlocks maximized; skill level 10,000, hero level 100, all rank-IV tiers and at least 65 ascensions fund the separate skill-allocation workflow.',
            'At least 10,000,000 kills retain maximum Veteran rank (+50% damage/life). This functional counter cannot be reduced below that floor while keeping the bonus.',
            'MAIN BANK ONLY: FWLSBank2 allocations are not installed. Use the separate funded-skills action; all Special caps exceed the available trophy budget, and Extras need in-match purchases.',
            'Both variants provide at least 1,000,000 score, which Marine evolution spends. This is a chosen reserve, not a verified natural cap; larger existing score is preserved.',
        ])
        if plausible:
            notes.extend(_fallen_template(work))
        else:
            notes.extend(_full_history(profile, work))
        raw, render_notes = bank.render(work)
    # Read back without touching the filesystem. Explicitly preserve filename
    # context (Softcore vs Hardcore) and author/player signature identities.
    check = type(bank)(raw, path=bank.path, player=bank.player, author=bank.author,
                       profile=bank.profile)
    if not check.original_verified() or check.state != work:
        raise ValueError('Preset signed read-back did not match the requested state.')
    notes.extend(render_notes)
    notes.extend(COVERAGE[profile]['limits'])
    notes.append('Changes are pending only. Preview and explicitly export or replace the bank to save them.')
    s['work'], s['levels'], s['evos'] = work, levels, evos
    return list(dict.fromkeys(notes))
