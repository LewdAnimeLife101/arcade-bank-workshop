"""Explicit current-file replacement shared by every profile.

Discovery stays read-only. Only the opened main file is replaced; the prior
bytes are kept outside the game's bank tree before an atomic commit.
"""
from pathlib import Path
from importlib import import_module
from datetime import datetime, timezone
import hashlib
import os
import tempfile
import uuid
from tkinter import messagebox

from .registry import get_profile, suggest
from zwl_editor.common import BankError

LIMIT=4*1024*1024


def require_between_matches(confirmed):
    """A per-save user assertion, not an observation of SC2's UI or memory."""
    if confirmed is not True:
        raise BankError("Confirm that SC2 is closed or you are at its main menu outside every match before replacing the bank.")


def backup_directory():
    base=Path(os.environ["LOCALAPPDATA"]) if os.environ.get("LOCALAPPDATA") else Path.home()/".local"/"share"
    return base/"Arcade Bank Editor"/"Backups"


def current_path(profile_id,bank):
    if bank is None or bank.path is None: raise BankError("Open a saved main bank first. Demo data cannot replace a file.")
    if bank.errors or bank.state is None: raise BankError("The original bank must pass validation before replacement.")
    profile=get_profile(profile_id)
    names={profile.bank_name.casefold()}
    module=import_module(profile.package+".core")
    names.update(n.casefold() for n in module.load_profile().get("bank_main_names",[]))
    path=Path(bank.path).absolute()
    if path.suffix.casefold()!=".sc2bank" or path.stem.casefold() not in names:
        raise BankError("Open this map's main bank from Find my banks. A rotating backup or renamed export is not the current main file.")
    if path.is_symlink() or path.resolve()!=path: raise BankError("The opened path now refers to a link or different location. Reopen the main bank.")
    return path


def read_bounded(path):
    if path.is_symlink(): raise BankError("The bank path became a symbolic link. Reopen the main file.")
    with path.open("rb") as stream: raw=stream.read(LIMIT+1)
    if len(raw)>LIMIT: raise BankError("Bank exceeds the 4 MB limit.")
    return raw


def decode(profile_id,raw,path,source,identity=None):
    profile=get_profile(profile_id)
    if [p.id for p in suggest(raw)]!=[profile_id]: raise BankError("The bank does not uniquely match the selected profile.")
    cls=import_module(profile.package+".core").Bank
    if profile_id=="unity":
        bank=cls(raw,path,source.profile)
        bank.identity=identity or source.identity or bank.identity
        if bank.root.find("Signature") is not None and bank.signature_status(bank.identity)!="Verified":
            raise BankError("The native signature must verify before replacing a signed bank.")
    elif profile_id in ("reign","fallen"): bank=cls(raw,path,source.profile,player=source.player,author=source.author)
    else: bank=cls(raw,path,source.profile,player=source.player)
    if bank.errors or bank.state is None: raise BankError("Bank validation failed: "+"; ".join(bank.errors))
    return bank


def validate_replacement(profile_id,source,payload,identity=None):
    path=current_path(profile_id,source)
    if hashlib.sha256(source.raw).hexdigest()!=source.digest: raise BankError("The opened snapshot changed. Reopen the main bank.")
    if read_bounded(path)!=source.raw: raise BankError("The original changed after opening. Reopen it before replacing; your pending edits remain in memory.")
    original=decode(profile_id,source.raw,path,source,identity)
    output=decode(profile_id,payload,path,source,identity)
    if profile_id=="unity" and original.root.find("Signature") is not None and output.root.find("Signature") is None:
        raise BankError("Replacement cannot remove the original bank's signature. Export unsigned test copies separately.")
    return path,output


def replace_current(profile_id,source,payload,*,identity=None,backup_root=None,between_matches_confirmed=False):
    """Require a per-save menu assertion; return (reloaded bank, backup).

    No process or menu detection is performed. No-op creates no backup.
    """
    require_between_matches(between_matches_confirmed)
    path,output=validate_replacement(profile_id,source,payload,identity)
    if payload==source.raw: return output,None
    root=Path(backup_root) if backup_root is not None else backup_directory()
    root=root.resolve()
    if root.is_relative_to(path.parent): raise BankError("Backups must be outside the game's bank folder.")
    token=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")+"-"+uuid.uuid4().hex
    folder=root/profile_id/token
    fd,name=tempfile.mkstemp(prefix=".arcade-save-",suffix=".tmp",dir=path.parent)
    staged=Path(name); backup=None
    try:
        with os.fdopen(fd,"wb") as stream:
            stream.write(payload); stream.flush(); os.fsync(stream.fileno())
        if read_bounded(staged)!=payload: raise BankError("Staged output verification failed; the current bank was not replaced.")
        decode(profile_id,read_bounded(staged),path,source,identity)
        folder.mkdir(parents=True,exist_ok=False)
        backup=folder/path.name
        with backup.open("xb") as stream:
            stream.write(source.raw); stream.flush(); os.fsync(stream.fileno())
        if read_bounded(backup)!=source.raw: raise BankError("Backup verification failed; the current bank was not replaced.")
        (folder/"Restore.txt").write_text(f"Profile: {profile_id}\nOriginal file: {path}\nSHA-256: {source.digest}\n\nLeave every match and stay at the SC2 main menu (or close SC2) before restoring this backup to the original path.\n",encoding="utf-8")
        if path.resolve()!=path or read_bounded(path)!=source.raw:
            raise BankError("The original changed during save. Replacement cancelled; pending edits and the independent backup remain available.")
        os.replace(staged,path)
        result=read_bounded(path)
        if result!=payload: raise BankError(f"Replacement read-back failed. The original backup is retained at {backup}")
        reloaded=decode(profile_id,result,path,source,identity)
        if reloaded.state!=output.state: raise BankError(f"Replacement validation failed. The original backup is retained at {backup}")
        return reloaded,backup
    finally: staged.unlink(missing_ok=True)


def update_button(editor):
    button=getattr(editor,"replace_button",None)
    if button is None: return
    allowed=not editor.demo_mode and editor.bank is not None and editor.bank.path is not None and not editor.bank.errors
    if allowed and hasattr(editor,"unsigned") and editor.unsigned.get(): allowed=False
    button.configure(state="normal" if allowed else "disabled")


def validate_fallen_pair(source, companion_raw, main_payload, companion_payload, *, check_files=True):
    """Bind companion writes to the opened, verified Fallen main and directory."""
    from fwls_editor.companion import parse, estimate
    from fwls_editor.presets import trophy_points
    from fwls_editor.skill_preset import render_companion
    path=current_path('fallen',source)
    sibling=path.with_name('FWLSBank2.SC2Bank')
    if source.digest!=hashlib.sha256(source.raw).hexdigest():raise BankError('Opened main snapshot changed.')
    decode('fallen',source.raw,path,source)
    output=decode('fallen',main_payload,path,source)
    before=parse(companion_raw);after=parse(companion_payload)
    changes=[n for n in set(before.loadouts)|set(after.loadouts) if before.loadouts.get(n)!=after.loadouts.get(n)]
    # Auto-only rewrites may reapply an identical generated slot.
    slots=changes or [n for n,l in after.loadouts.items() if l.name=='AllSkills']
    valid=[]
    for n in slots:
        if n not in after.loadouts:continue
        if after.auto not in (0,n):continue
        try:
            expected=render_companion(companion_raw,n,after.loadouts[n],auto=after.auto==n)
            if expected==companion_payload:valid.append(n)
        except ValueError:continue
    if not valid:raise BankError('Companion output must preserve other loadouts and settings.')
    for n in valid:
        estimate_result=estimate(after.loadouts[n],skill_tiers=output.state.skill_tiers,
            skill_level=output.state.values['skill_level'],ascension_level=output.state.values['ascension_level'],
            trophy_points=trophy_points(output.state,output.profile))
        if estimate_result.applied!=estimate_result.requested:raise BankError('Progression cannot fund the skill loadout. Review again.')
    if check_files:
        if path.resolve()!=path or sibling.resolve()!=sibling:raise BankError('Bank location changed. Reopen the main bank.')
        if read_bounded(path)!=source.raw or read_bounded(sibling)!=companion_raw:
            raise BankError('A bank changed after review. Reopen and review again; pending edits are retained.')
    return path,sibling,output,after


def replace_fallen_pair(source, companion_raw, main_payload, companion_payload, *, backup_root=None, between_matches_confirmed=False):
    """Back up both files before per-file atomic commits, with guarded rollback.

    A filesystem cannot atomically exchange two independent files. Interruptions
    can leave a partial pair; both originals remain in the same recovery folder.
    """
    require_between_matches(between_matches_confirmed)
    main,companion,output,_=validate_fallen_pair(source,companion_raw,main_payload,companion_payload)
    entries=((main,source.raw,main_payload),(companion,companion_raw,companion_payload))
    if all(old==new for _,old,new in entries):return output,companion_payload,None
    root=Path(backup_root or backup_directory()).resolve()
    bank_tree=next((p for p in main.parents if p.name.casefold()=='banks'),main.parent)
    if root.is_relative_to(bank_tree):raise BankError('Backups must be outside the game bank folders.')
    folder=root/'fallen'/(datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex)
    staged={};committed=[]
    def stage(path,raw):
        fd,name=tempfile.mkstemp(prefix='.arcade-save-',suffix='.tmp',dir=path.parent)
        temporary=Path(name)
        try:
            with os.fdopen(fd,'wb') as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
            if read_bounded(temporary)!=raw:raise BankError('Staged bank verification failed.')
            return temporary
        except Exception:temporary.unlink(missing_ok=True);raise
    try:
        for path,old,new in entries:staged[path]=stage(path,new)
        validate_fallen_pair(source,companion_raw,read_bounded(staged[main]),read_bounded(staged[companion]))
        folder.mkdir(parents=True,exist_ok=False)
        for path,old,new in entries:
            backup=folder/path.name
            with backup.open('xb') as stream:stream.write(old);stream.flush();os.fsync(stream.fileno())
            if read_bounded(backup)!=old:raise BankError('Independent backup verification failed.')
        (folder/'Restore.txt').write_text(f'Fallen World paired skill preset\nOriginal directory: {main.parent}\n'
            'Both original banks are in this folder. Leave every match before restoring both files.\n'
            'Commits are atomic per file, not across the pair. After an interruption restore both or reopen and review again.\n'+
            ''.join(f'{p.name}: {hashlib.sha256(old).hexdigest()}\n' for p,old,_ in entries),encoding='utf-8')
        for path,old,new in entries:
            # Recheck both files immediately before each individual commit.
            for p,o,n in entries:
                expected=n if p in committed else o
                if p.resolve()!=p or read_bounded(p)!=expected:raise BankError('A bank changed during save.')
            if old!=new:
                os.replace(staged[path],path);committed.append(path)
                if read_bounded(path)!=new:raise BankError('Replacement read-back failed.')
        _,_,reloaded,_=validate_fallen_pair(source,companion_raw,read_bounded(main),read_bounded(companion),check_files=False)
        return reloaded,companion_payload,folder
    except (OSError,ValueError) as exc:
        recovery=[]
        for path,old,new in reversed(entries):
            if path not in committed:continue
            rollback=None
            try:
                if path.resolve()!=path or read_bounded(path)!=new:
                    recovery.append(f'{path.name}: externally changed; not overwritten');continue
                if read_bounded(folder/path.name)!=old:raise BankError('Recovery backup verification failed.')
                rollback=stage(path,old)
                if read_bounded(path)!=new:raise BankError('File changed before rollback.')
                os.replace(rollback,path)
                if read_bounded(path)!=old:raise BankError('Rollback read-back failed.')
                recovery.append(f'{path.name}: original restored')
            except (OSError,ValueError) as err:recovery.append(f'{path.name}: restore manually ({err})')
            finally:
                if rollback is not None:rollback.unlink(missing_ok=True)
        raise BankError(f'Paired save stopped: {exc}\nRecovery folder (if created): {folder}\n'+ '\n'.join(recovery)) from exc
    finally:
        for temporary in staged.values():temporary.unlink(missing_ok=True)


def export_fallen_pair(source,companion_raw,main_payload,companion_payload,destination):
    """Create a new export directory; never overwrite or install game saves."""
    main,_,_,_=validate_fallen_pair(source,companion_raw,main_payload,companion_payload)
    folder=Path(destination).absolute()
    if folder.resolve()!=folder:raise BankError('Choose a folder without symbolic links.')
    bank_tree=next((p for p in main.parents if p.name.casefold()=='banks'),main.parent)
    if folder.is_relative_to(bank_tree):raise BankError('Choose an export directory outside the game bank folders.')
    folder.mkdir(parents=True,exist_ok=False)
    for name,raw in (('FWLSBank.SC2Bank',main_payload),('FWLSBank2.SC2Bank',companion_payload)):
        path=folder/name
        with path.open('xb') as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
        if read_bounded(path)!=raw:raise BankError('Export verification failed; do not install the partial export.')
    validate_fallen_pair(source,companion_raw,read_bounded(folder/'FWLSBank.SC2Bank'),read_bounded(folder/'FWLSBank2.SC2Bank'))
    return folder


def save_editor(editor,profile_id):
    """Every profile button uses the same explicit replacement flow."""
    try:
        if editor.demo_mode: raise BankError("Demo data cannot replace a current bank.")
        current_path(profile_id,editor.bank)
        identity=None
        if profile_id=="unity":
            from zwu_editor.core import Identity
            if editor.unsigned.get(): raise BankError("Turn off unsigned test-copy mode before replacing the current bank.")
            identity=Identity(editor.author.get().strip(),editor.player.get().strip())
        if profile_id=="mineralz": payload=editor.bank.render(editor.collect())[0]
        else: payload=editor.prepare()[0]
        path,output=validate_replacement(profile_id,editor.bank,payload,identity)
        if payload==editor.bank.raw:
            editor.status.set("No changes to save. The current bank is unchanged."); return False
        if not messagebox.askyesno("At the main menu — replace bank?",f"Confirm BOTH before saving:\n\n• SC2 is closed, OR you are at its main menu and have left every match.\n• You want to replace this opened main bank with your validated edits:\n\n{path}\n\nOriginal backup:\n{backup_directory()}\n\nSC2 may stay open. Stay out of matches until saving finishes. The editor cannot verify your menu state.",parent=editor): return False
        tab=editor.tabs.get()
        reloaded,backup=replace_current(profile_id,editor.bank,payload,identity=identity,between_matches_confirmed=True)
        editor.set_bank(reloaded,False); editor.tabs.set(tab)
        editor.status.set(f"Current bank replaced and revalidated. Original backup: {backup}")
        messagebox.showinfo("Current bank saved",f"Replaced:\n{path}\n\nOriginal backup:\n{backup}\n\nYour edits were saved to disk. Check them in a new map session. The editor cannot verify that the running game reloaded the file; live map acceptance remains untested.",parent=editor)
        return True
    except (ValueError,OSError) as exc:
        messagebox.showerror("Replacement blocked",str(exc),parent=editor)
        return False
