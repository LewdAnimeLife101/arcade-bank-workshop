"""Account identities from local save folders, never from file modification time."""
from pathlib import Path
import re

ALL_ACCOUNTS = "All accounts / manual copies"


def account_for_path(path):
    """Return (account folder, player handle), keeping map authors separate.

    Copies outside a normal Banks tree have no inferred account. Redirected
    Documents roots can contain the same account, so roots are not identity.
    """
    if path is None:
        return None
    path = Path(path).resolve()
    author = path.parent.parent if path.parent.name.casefold() == "backup" else path.parent
    if author.parent.name.casefold() != "banks":
        return None
    player = author.parent.parent
    if not re.fullmatch(r"[0-9]+-S2-[0-9]+-[0-9]+", player.name):
        return None
    return player.parent.name, player.name


def account_label(account):
    return ALL_ACCOUNTS if account is None else f"{account[1]} · Account folder {account[0]}"


def filter_accounts(candidates, account):
    return list(candidates) if account is None else [
        c for c in candidates if account_for_path(c.path) == account]


def account_choices(candidates, retained=()):
    accounts = {account_for_path(c.path) for c in candidates} | set(retained)
    accounts.discard(None)
    return {ALL_ACCOUNTS: None, **{account_label(a): a for a in sorted(accounts)}}
