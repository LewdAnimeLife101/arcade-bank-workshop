"""Central reviewed preset dispatch and public coverage descriptions."""
from importlib import import_module

MODULES={'unity':'classic','liberty':'classic','mineralz':'classic',
         'reign':'rpg','fallen':'rpg','mineralz_evolution_258':'modern','probes_zealot_2118':'modern'}

def module(profile):return import_module('arcade_editor.preset_'+MODULES[profile])

def coverage(profile):
    result=dict(module(profile).COVERAGE[profile])
    result.setdefault('limits',[])
    return result

def actions(profile):
    if profile=='reign':
        from zrc_editor.presets import CATEGORIES
        titles={'perks':'Max perks','heroes':'Max heroes & evolutions','mastery':'Unlock mastery & ascendancy',
                'charms':'Max charms','items':'Collect supported items','glyphs':'Collect supported glyphs','content':'Unlock game content'}
        return [{'action':'reign:'+key,'title':titles[key],'description':text} for key,text in CATEGORIES.items()]+[
            {'action':'loadouts','title':'Equip powerful loadouts','description':'Assign class-themed active items and equipped glyphs, preserving unknown items and native slot locks.'},
            {'action':'statistics','title':'Reconcile existing statistics','description':'Repair known total/hero relationships without replacing existing history with a template.'}]
    if profile=='fallen':return [{'action':'funded_skills','title':'Funded skill loadout','description':'Prepare regular skills, Ascendancy and affordable Special ranks using the existing companion bank. Exports both banks together.'}]
    if profile=='mineralz_evolution_258':return [
        {'action':'unlock:all','title':'Unlock menu choices','description':'Fund the verified skills, specialities, workers, colours, masteries and completion markers.'},
        {'action':'prestige_perks','title':'Unlock prestige perk choices','description':'Raise prestige to at least 12 to unlock all 14 match choices.'},
        {'action':'prestige_rewards','title':'Prestige 100 milestone','description':'Raise prestige to 100 while preserving separate achievement flags and other progression.'}]
    if profile=='liberty':return [{'action':'navigate:souls','title':'Edit individual soul jewels','description':'Choose a jewel under Equipment & glyphs to set its tier and maximize only its base stats.'}]
    return []

def apply(session,action):
    if action not in ('all_full','all_plausible'):raise ValueError('Unknown shared preset.')
    notes=module(session['profile']).apply(session,action=='all_plausible')
    return ['Preset: '+('Unlock all (with legit stats)' if action=='all_plausible' else 'Unlock all'),
            'Public-record values are an editing template, not verified play history. Required unlock records can remain high.']+list(notes)
