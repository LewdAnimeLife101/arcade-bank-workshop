"""Reviewed bulk drafts for Unity, Liberty and Mineralz Survival 2.

Only changes the session's edit state. The normal render/signature/protection
checks remain authoritative; no bank or other file is written here.
"""
from __future__ import annotations

from zwl_editor.fixed import SCALE, parse_fixed

COVERAGE = {
    'unity': {
        'summary': 'Maximum audited talents, active/maximum prestige, TP, evolutions and all ten win categories; balances unlock all ordinary heroes.',
        'differences': 'Full: wave 16,999 and 1,000 wins per category. Lower public records: wave 100 and one win per category. Both keep at least 1.3 million spendable kills in every class because hero access depends on those balances.',
        'limits': ['Donation/custom/account-only heroes are excluded.', 'Class kills are currency, not a separate lifetime-kill statistic. No supported play-time field exists.', 'Wave 16,999 is the accepted bank range, not a verified gameplay wave cap. These are edited records, not evidence of earned progress.'],
    },
    'liberty': {
        'summary': 'All 12 supported heroes, available ascensions, catalog-backed prestige and resulting level caps; six challenges; tier 15 jewel stats and all 14 unique-effect choices represented when slots permit.',
        'differences': 'Both actions keep the same functional values. Kill balance buys upgrades and best solo difficulty controls XP/rewards, so neither is lowered just to make progress look smaller.',
        'limits': ['Unmapped hero slots, opaque ranks, unavailable ascension bits, unknown jewels, existing unique effects and enhancement counts are preserved.', 'No independent lifetime-kill or play-time counter is supported. A lower-record appearance cannot be promised.', 'Account-dependent challenge-key collisions and unverified square-root-sensitive outputs remain blocked. Currency targets are useful reserves, not invented game maxima.'],
    },
    'mineralz': {
        'partial': True,
        'summary': 'Attempts every supported achievement, night record, Probe level, streak and bank-local cosmetic prerequisite; retains only combinations accepted by the verified protection model.',
        'differences': 'Both actions use the same functional plan. Full attempts large games/wins/test-night records; lower public records attempts modest counters while keeping nights, level, achievements and talent-point streak unchanged.',
        'limits': ['PARTIAL SUPPORT: all numeric maxima together can overflow the supported CP arithmetic. The result explicitly reports any target left below its cap; this is not an unconditional unlock-all.', 'Nights and Probe level award talent points, so lowering them would reduce functionality. Unsupported external legacy/account-event skins are not granted.', 'Reserved achievement positions and original 1.2/1.3 format are preserved; no play-time field is supported. Published-match acceptance remains untested.'],
    },
}


def _render(bank, target, pid):
    if pid == 'unity':
        result = bank.render(target)
        return result[1], result[-1]
    result = bank.render(target)
    return target, result[-1]


def _unity(bank, target, plausible):
    p = bank.profile
    target.tp = 65000
    for field in p['talents']:
        target.talents[field['bankkey']] = field['max']
    for field in p['evolutions']:
        target.evolutions[field['bankkey']] = field['max']
    # Heroes.galaxy1353-1359: Science Vessel, the highest ordinary unlock,
    # needs1.3m in all seven classes. These are spendable balances (HeroMenu44-55).
    for key in target.kills:
        target.kills[key] = max(target.kills[key], 1300000)
    for key in target.wins:
        target.wins[key] = 1 if plausible else max(target.wins[key], 1000)
    target.wave = 100 if plausible else 16999
    return target, ['All ordinary hero prerequisites retained; special account permissions are unchanged.',
                    'Public win/wave records were deliberately edited; they do not establish earned gameplay.']


def _liberty(bank, target, plausible):
    from zwl_editor.core import Soul
    notes = []
    for spec in bank.profile['heroes']:
        h = target.heroes[spec['id']]
        h.purchased = True
        bits = list(h.ascensions)
        for entry in spec['ascensions']:
            if entry.get('available'):
                bits[entry['id']-1] = '1'
        new_ascensions = ''.join(bits)
        if h.level > 20+10*new_ascensions.count('1') and new_ascensions != h.ascensions:
            notes.append(f"{spec['label']}: existing above-cap level/ascension combination preserved; no unknown progression rule was invented.")
        else:
            h.ascensions = new_ascensions
        h.prestige = max(h.prestige, spec['prestige_max'])
        h.level = max(h.level, 20 + 10*h.ascensions.count('1'))
        # XP is within-level progress. At the maximum level no added XP is
        # needed; preserve the user's existing remainder instead of inventing XP.
    for key in target.challenges:
        target.challenges[key] = True
    target.best_solo = max(target.best_solo, 30)
    target.kills = max(target.kills, 500000)
    target.dust = max(target.dust, 10000)
    cap = next(x['stats2_to5_cap'] for x in bank.souls_profile['tiers'] if x['code'] == 15)*SCALE
    effects = set()
    for soul in target.souls.values():
        if not 1 <= soul.type <= 15:
            continue
        # Unsupported out-of-range existing metadata is opaque, not normalized.
        try:
            from zwl_editor.core import validate
            probe = target.clone()
            changed = probe.souls[next(k for k,v in target.souls.items() if v is soul)]
            changed.type = 15
            changed.stats[:5] = [cap*10, cap, cap, cap, cap]
            validate(probe, bank.profile, bank.souls_profile, before=bank.state)
        except ValueError:
            notes.append('An existing jewel with unsupported metadata was preserved without maximizing it.')
            continue
        soul.type = 15
        soul.stats[:5] = [cap*10, cap, cap, cap, cap]
        effects.update(v//SCALE for v in (soul.stats[5],soul.stats[7]) if v % SCALE == 0)
    missing = [effect for effect in range(1,15) if effect not in effects]
    empty = [i for i,soul in target.souls.items() if soul.type == 0]
    for slot,effect in zip(empty,missing):
        # One of each effect, no arbitrary enhancement count or duplicate pair.
        target.souls[slot] = Soul(15,[cap*10,cap,cap,cap,cap,effect*SCALE,0,0])
    if len(empty) < len(missing):
        notes.append('Inventory has insufficient empty slots to represent every unique effect; existing jewels were not overwritten.')
    notes.append('Best solo 30, kills and dust are functional progression/currency; both presets keep them. Existing jewel effects and enhancement counts are unchanged.')
    return target, notes


def _survival(bank, target, plausible):
    from mineralz_editor.core import validate, talent_points
    from mineralz_editor.protection import calculate
    p = bank.profile
    notes = []

    def supported(candidate):
        try:
            validate(candidate,p,before=bank.state)
            calculate(candidate.values,candidate.achievements,bank.player)
            return True
        except ValueError:
            return False

    # Shared foundation gives both options identical functional progression.
    # Counter normalization is explicit, never hidden in the arithmetic codec.
    for games,wins in ((100,50),(20,10),(10,10)):
        candidate = target.clone()
        candidate.values.update(v8=games,v9=wins,v13=0,testgames=max(1,target.values['testgames']),testnights=0)
        if supported(candidate):
            target = candidate
            break
    base = p['achievements_codec']['base_string']
    desired = ''.join(str(int(x)+1) for x in base[:108])+target.achievements[108:]
    candidate = target.clone(); candidate.achievements = desired
    if supported(candidate):
        target = candidate
    else:
        for index in range(108):
            candidate = target.clone()
            bits = list(candidate.achievements); bits[index] = str(int(base[index])+1)
            candidate.achievements = ''.join(bits)
            if supported(candidate):target = candidate

    # Independent goals are bounded by source caps. Search descending within
    # those caps because wrapped fixed arithmetic is not globally monotonic.
    for key in ['v12',*(f'v{i}' for i in range(1,8)),'v10']:
        maximum = 10 if key == 'v12' else 10000 if key == 'v10' else 70
        for value in range(maximum,target.values[key],-1):
            candidate = target.clone(); candidate.values[key] = value
            if key == 'v10':candidate.values['v11'] = value*SCALE
            if supported(candidate):
                target = candidate
                break
        if target.values[key] < maximum:
            label = next(x['label'] for x in p['fields'] if x['key'] == key)
            notes.append(f'{label}: safe preset reached {target.values[key]} of requested {maximum}; larger combined values are outside verified protection arithmetic.')
    missed = sum(a==b for a,b in zip(target.achievements[:108],base[:108]))
    if missed:notes.append(f'{missed} achievement targets could not be added within the verified protection arithmetic domain.')
    if target.values['testgames'] < 1:
        notes.append('Test-game cosmetic prerequisites could not be raised within the verified protection arithmetic domain.')

    # These are public counters, not the night/level/streak sources of TP.
    # Keep1.2 migration deterministic: v13=0 restores its existing v12 record.
    baseline = target.clone()
    counts = [(20,10,0),(100,50,0)] if plausible else [(10000,5000,700),(1000,500,70),(100,50,0)]
    accepted = False
    for games,wins,testnights in counts:
        candidate = baseline.clone()
        candidate.values.update(v8=max(games,candidate.values['v12']),v9=max(wins,candidate.values['v12']),testnights=testnights)
        candidate.values['v13'] = 0 if candidate.values['version'] == parse_fixed('1.2') else candidate.values['v12']
        if supported(candidate):
            target = candidate; accepted = True
            break
    if not accepted:
        notes.append('Public games/wins/test-night targets were outside the verified protection domain; retained the validated shared counters.')
    notes.append(f'Preset retains {talent_points(target,p)} derived talent points. Nights/level/streak remain functional and are not reduced for appearance.')
    notes.append('External legacy/account-event skin ownership is not granted; your selected skin and reserved achievement data are preserved.')
    return target, notes


def apply(s, plausible: bool = False):
    """Apply a fully rendered draft atomically; caller owns preview/undo/save."""
    pid = s['profile']
    if pid not in COVERAGE:
        raise ValueError('This classic preset does not support the selected profile.')
    target,notes = {'unity':_unity,'liberty':_liberty,'mineralz':_survival}[pid](s['bank'],s['work'].clone(),plausible)
    effective,checked_notes = _render(s['bank'],target,pid)
    s['work'] = effective
    return notes + list(checked_notes)

