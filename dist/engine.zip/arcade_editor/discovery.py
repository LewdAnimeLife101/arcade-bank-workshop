"""Read-only discovery in standard SC2 account bank directories.

A candidate is a filename/structure/codec observation, not proof of the active
in-game account. Modification time controls display order only.
"""
from __future__ import annotations

from dataclasses import dataclass
from importlib import import_module
from pathlib import Path
import os
import re
from itertools import chain

from . import registry


@dataclass(frozen=True)
class BankCandidate:
    profile_id: str
    path: Path
    player: str
    author: str
    is_backup: bool
    modified_ns: int
    valid: bool
    errors: tuple[str, ...]


def _redirected_documents() -> Path | None:
    """Windows Personal shell-folder setting, without writing the registry."""
    try:
        import winreg
    except ImportError:
        return None
    for key_name in (r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders",
                     r"Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders"):
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_name) as key:
                value, _ = winreg.QueryValueEx(key, "Personal")
            if isinstance(value, str) and value:
                return Path(os.path.expandvars(value)).expanduser()
        except (OSError, ValueError):
            continue
    return None


def _default_roots() -> list[Path]:
    home = Path.home()
    documents = _redirected_documents()
    roots = [documents/"StarCraft II"] if documents is not None else []
    roots.append(home/"Documents"/"StarCraft II")
    for variable in ("OneDrive", "OneDriveCommercial", "OneDriveConsumer"):
        value = os.environ.get(variable)
        if value:
            roots.append(Path(os.path.expandvars(value))/"Documents"/"StarCraft II")
    try:
        roots.extend(p/"Documents"/"StarCraft II" for p in home.glob("OneDrive*") if p.is_dir())
    except OSError:
        pass
    return roots


def _filename(name: object) -> str | None:
    if not isinstance(name, str) or not name or any(c in name for c in "/\\:\x00"):
        return None
    return name if name.casefold().endswith(".sc2bank") else name+".SC2Bank"


def _catalog(profiles) -> dict[str, list[tuple[object, bool]]]:
    catalog = {}
    for profile in profiles:
        main = _filename(profile.bank_name)
        main_keys = {main.casefold()} if main else set()
        names = [main] if main else []
        try:
            module = import_module(profile.package+".core")
            data = module.load_profile()
            additional_mains = data.get("bank_main_names", [])
            if isinstance(additional_mains, (list, tuple)):
                for item in additional_mains:
                    filename = _filename(item)
                    if filename:
                        main_keys.add(filename.casefold())
                        names.append(filename)
            aliases = data.get("bank_names", [])
            if isinstance(aliases, (list, tuple)):
                names.extend(_filename(name) for name in aliases)
        except (ImportError, AttributeError, OSError, ValueError, TypeError):
            # The registry's main filename remains usable if optional alias
            # metadata is unavailable. Full codec validation still runs.
            pass
        for name in {n.casefold() for n in names if n is not None}:
            catalog.setdefault(name, []).append((profile, name not in main_keys))
    return catalog


def discover(profile_id=None, *, roots=None) -> list[BankCandidate]:
    """Find expected filenames, including invalid files, without changing them.

    ``roots`` are SC2 directories (containing Accounts), injectable for tests.
    Only Accounts/*/*/Banks/*/* is visited; no recursive whole-disk search.
    """
    profiles = registry.PROFILES if profile_id is None else (registry.get_profile(profile_id),)
    catalog = _catalog(profiles)
    native=[]
    for profile in profiles:
        try:metadata=import_module(profile.package+'.core').load_profile()
        except (ImportError,AttributeError,OSError,ValueError,TypeError):continue
        names=metadata.get('native_backup_names',[])
        if not isinstance(names,(list,tuple)):continue
        for name in names:
            filename=_filename(name)
            if filename:native.append((re.compile(re.escape(filename[:-8])+r'_backup_[0-9]+\.sc2bank',re.I),profile))
    def owners_for(path):
        if path.parent.name.casefold()=='backup':
            return [(profile,True) for pattern,profile in native if pattern.fullmatch(path.name)]
        return catalog.get(path.name.casefold())
    supplied = _default_roots() if roots is None else roots
    if isinstance(supplied, (str, os.PathLike)):
        supplied = [supplied]
    results = []
    seen = set()
    for root in supplied:
        try:
            accounts = (Path(root).expanduser()/"Accounts").resolve()
            files = chain(accounts.glob("*/*/Banks/*/*"),accounts.glob("*/*/Banks/*/backup/*") if native else ())
            for path in files:
                owners = owners_for(path)
                if not owners:
                    continue
                try:
                    resolved = path.resolve()
                    relative = resolved.relative_to(accounts)  # No escaping junctions/symlinks.
                    is_native=len(relative.parts)==6 and relative.parts[4].casefold()=='backup'
                    if (len(relative.parts) != 5 and not is_native) or relative.parts[2].casefold() != "banks":
                        continue
                    owners = owners_for(resolved)
                    if not owners:
                        continue
                    if not resolved.is_file():
                        continue
                except (OSError, ValueError):
                    continue
                identity = os.path.normcase(str(resolved))
                if identity in seen:
                    continue
                seen.add(identity)
                # Canonical account and map author are separate components;
                # aliases cannot relabel another account or a backup as main.
                player, author = relative.parts[1], relative.parts[3]
                try:
                    modified = resolved.stat().st_mtime_ns
                except OSError:
                    modified = 0
                if len(owners) != 1:
                    # Filename collisions are never resolved by account age or
                    # recency; a future registry must disambiguate explicitly.
                    profile, backup = sorted(owners, key=lambda item: item[0].id)[0]
                    results.append(BankCandidate(profile.id, resolved, player, author, backup,
                        modified, False, ("Filename belongs to multiple profiles; explicit selection is required.",)))
                    continue
                profile, backup = owners[0]
                try:
                    report = registry.inspect(resolved, profile.id, player=player,author=author)
                    errors = tuple(str(e) for e in report["errors"])
                    valid = bool(report["ok"]) and not errors
                except Exception as exc:
                    # One inaccessible, malformed or unsupported bank must not
                    # prevent displaying other candidates. No bank is repaired.
                    valid, errors = False, (str(exc) or type(exc).__name__,)
                results.append(BankCandidate(profile.id, resolved, player, author, backup,
                                             modified, valid, errors))
        except (OSError, ValueError):
            continue
    return sorted(results, key=lambda c: (c.is_backup, -c.modified_ns,
                                         str(c.path).casefold(), c.profile_id))


def preferred(candidates, profile_id) -> BankCandidate | None:
    """Return exactly one validated main; never choose a backup or newest tie."""
    registry.get_profile(profile_id)
    matches = [c for c in candidates if c.profile_id == profile_id and c.valid and
               not c.errors and not c.is_backup]
    return matches[0] if len(matches) == 1 else None
