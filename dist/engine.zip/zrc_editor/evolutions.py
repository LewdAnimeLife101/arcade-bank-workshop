"""Explicit saved-hero form edits for the audited Reign 0.291 catalog.

The Evolutions scalar and the native unit's Type are separate records. The map
restores Type, then uses the scalar for upgrades; changing only the scalar does
not evolve that unit. These helpers never synthesize a missing native unit.
"""
from functools import lru_cache
import json

from .common import BankError, integer, resource_path
from .levels import xp_for_level


@lru_cache(maxsize=1)
def catalog():
    return json.loads(resource_path('data/evolutions.json').read_text(encoding='utf-8'))


def hero_info(hero):
    if type(hero) is not int:
        raise BankError('Unknown hero evolution selection.')
    for info in catalog()['heroes']:
        if info['id'] == hero:
            return info
    raise BankError('Unknown hero evolution selection.')


def form_for_stage(hero, stage):
    info = hero_info(hero)
    stage = integer(stage, info['name']+' evolution stage', 1, 8)
    return info['forms'][stage-1]


def current_stage(bank, hero):
    info = hero_info(hero)
    node = bank.nodes.get(('Hero', info['unit_key']))
    leaf = node.find('Type') if node is not None else None
    if leaf is None or leaf.attrib.keys() != {'string'}:
        return None
    return next((f['stage'] for f in info['forms'] if f['unit_id'] == leaf.get('string')), None)


def label(hero, stage):
    if stage == 0:
        return '0 — Reset unlock record (keep saved form)'
    form = form_for_stage(hero, stage)
    return f"{stage} — {form['label']} (level {form['minimum_level']}+)"


def selected_stage(text):
    text = str(text).strip().split(' — ', 1)[0]
    return integer(text, 'Evolution stage', 0, 8)


def prepare_selection(bank, target, hero, stage):
    """Stage an explicit form selection and its minimum XP, with no file writes."""
    info = hero_info(hero)
    stage = integer(stage, info['name']+' evolution stage', 0, 8)
    target.values['Evolutions', info['evolution_key']] = stage
    if stage:
        xp_pair = 'Statistics', info['xp_key']
        target.values[xp_pair] = max(target.values[xp_pair], xp_for_level(form_for_stage(hero, stage)['minimum_level']))
        if ('Hero', info['unit_key']) in target.unit_items:
            from .item_loadouts import sync_active_loadout
            sync_active_loadout(target, hero, form_for_stage(hero, stage)['unit_id'])
    return target


def validate_selections(bank, target, selections):
    """Return validated hero metadata, rejecting mismatched or unknown forms."""
    result = {}
    for hero, stage in selections.items():
        info = hero_info(hero)
        if type(stage) is not int or not 0 <= stage <= 8:
            raise BankError(info['name']+': evolution stage must be 0 through 8.')
        if target.values['Evolutions', info['evolution_key']] != stage:
            raise BankError(info['name']+': selected evolution and unlock record do not agree.')
        if stage:
            form = form_for_stage(hero, stage)
            if target.values['Statistics', info['xp_key']] < xp_for_level(form['minimum_level']):
                raise BankError(f"{info['name']}: {form['label']} needs at least level {form['minimum_level']}; select the evolution again to synchronize minimum XP.")
            node = bank.nodes.get(('Hero', info['unit_key']))
            if node is not None and current_stage(bank, hero) is None:
                raise BankError(info['name']+': saved unit type is outside this hero\'s verified evolution chain; preserve it unchanged.')
            if node is not None:
                # Reuse the established XP codec before permitting a type edit.
                import copy
                bank._sync_unit_xp(copy.deepcopy(node), target.values['Statistics', info['xp_key']])
        result[hero] = info
    return result


def apply_selections(nodes, selections, infos):
    notes = []
    for hero, stage in selections.items():
        info = infos[hero]
        if stage == 0:
            notes.append(info['name']+': reset evolution unlock record only; saved unit form is unchanged.')
            continue
        node = nodes.get(('Hero', info['unit_key']))
        if node is None:
            notes.append(info['name']+': evolution unlock updated; no saved hero exists to change. Play and save this hero once, then select the evolution again.')
            continue
        form = form_for_stage(hero, stage)
        old_type = node.find('Type').get('string')
        node.find('Type').set('string', form['unit_id'])
        notes.append(f"{info['name']}: saved form {old_type} → {form['label']} ({form['unit_id']}); synchronized evolution unlock and XP. Equipment and other unit leaves retained. The map reloads the selected form's own skill/item loadout 1; review skills in game.")
    return notes


def verify_output(bank, selections):
    for hero, stage in selections.items():
        info = hero_info(hero)
        if stage and ('Hero', info['unit_key']) in bank.nodes and current_stage(bank, hero) != stage:
            raise BankError(info['name']+': rendered saved form did not match the selected evolution.')
