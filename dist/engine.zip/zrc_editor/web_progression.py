"""Source-backed public controls for Reign 0.291 progression.

Uses the same level, native-form and ascendancy APIs as the desktop editor.
All operations stage in-memory changes; Bank.render remains the final validator.
"""
import json
import re

from .common import BankError, integer
from . import levels as level_api, evolutions
from .guidance import enriched_profile, field_description, load_help, dependency_text, apply_mastery_progress
from . import charms


def _row(key, label, hero, group, category, value, maximum=None, minimum=0,
         description='', options=None, readonly=False, kind='int'):
    return dict(id=key, label=label, hero=hero, group=group, category=category,
                kind=kind, value=value, min=minimum, max=maximum,
                description=description, options=options, readonly=readonly)


def _heroes(bank):
    return {int(h['id']): {**h,'name':h['name'].replace('BloodElf','Blood Elf')} for h in bank.profile['heroes']}


def describe(bank, state, levels, evos):
    """Return named controls; preserve unknown native forms and legacy choices."""
    rows = []
    ascent = {int(h['id']): h for h in load_help('ascendancy')['heroes']}
    xp_specs = {s['hero']: s for s in bank.profile['fields'] if s.get('unit_key')}
    for hero, h in _heroes(bank).items():
        name = h['name']; group = name + ' · Progression'; spec = xp_specs[hero]
        value = level_api.level_for_xp(state.values[spec['section'], spec['key']])
        rows.append(_row(f'level:{hero}', 'Hero level', hero, group, 'Heroes', value, 105, 1,
            'Sets the exact XP threshold for this level, raises shared Hero Enhancement only as needed, and synchronizes supported saved-unit XP and migration markers on export. Missing saved heroes are not created.',
            [dict(value=i, label=level_api.label(i)) for i in range(1, 106)]))
        info = evolutions.hero_info(hero)
        original = evolutions.current_stage(bank, hero)
        present = ('Hero', info['unit_key']) in bank.nodes
        selected = evos.get(hero, original if original is not None else 0)
        record = state.values['Evolutions', info['evolution_key']]
        detail = ('No saved hero exists yet. This changes the unlock record only; play and save this hero once, then select its form again.'
                  if not present else 'The saved unit type is outside the verified chain and is preserved.'
                  if original is None else 'Changes the saved hero form and its unlock record together; raises XP to the form minimum. The game reloads this form’s own first skill/item loadout.')
        rows.append(_row(f'evolution:{hero}', 'Evolution form', hero, group, 'Heroes', selected, 8,
            description=f'Current unlock record: {record}. '+detail,
            options=[dict(value=i, label=evolutions.label(hero, i)) for i in range(9)],
            readonly=present and original is None))
        rows.append(_row(f'mastery:{hero}', 'Hero mastery', hero, group, 'Heroes',
            state.values['Perks', f'PRank{95+hero}'], 40,
            description='Prestige-like ranks. Normal purchase requires final evolution and level 100, resets XP and reloads skill loadout 6. Editing here preserves XP/loadouts and applies the verified mastery-progress and positive passive-point grant. Each rank further reduces XP gain by a factor of 0.9. The 25-point passive budget still applies.'))
        asc = ascent.get(hero)
        if not asc: continue
        ranks = state.values['Asc', f'AscEncryptionKey{hero}']
        pool = state.values['Asc', f'AscPassPts{hero}']
        ability_pool = state.values['Asc', f'AscAbilPts{hero}']
        group = name + ' · Ascendancy'
        nodes = {int(n['slot']): n for n in asc['nodes']}
        rows.append(_row(f'asc:{hero}:budget', 'Total passive points', hero, group, 'Ascendancy',
            sum(map(int, ranks[3:])) + pool, 25,
            description=f'Allocated plus unspent points (currently {pool} unspent). A rank costs one point. Raising this pool does not perform a purchase. The map may still award a one-time level-100 point; final validation reserves room when required.'))
        options = [dict(value=0, label='No ability / no unspent point'), dict(value=-1, label='Unspent ability point')]
        options.extend(dict(value=i, label=nodes[i]['label'], description=nodes[i]['description'])
                       for i in range(1, 4) if nodes[i].get('editable', True))
        ability = next((i for i in range(1, 4) if ranks[i-1] == '1'), -1 if ability_pool == 1 else 0)
        legacy = sum(map(int, ranks[:3])) + ability_pool > 1 or ability_pool not in (0, 1)
        if legacy:
            ability = -2; options.append(dict(value=-2, label='Preserve original ability and points'))
        rows.append(_row(f'asc:{hero}:ability', 'Ability specialization', hero, group, 'Ascendancy', ability, 3, -2,
            'Choose one named ability or one unspent point. Selecting an ability consumes the saved ability point.', options))
        rows.append(_row(f'asc:{hero}:mastery_progress', 'Mastery progress', hero, group, 'Ascendancy',
            state.values['Asc', f'MG{hero}'], 11, description='Derived when Hero mastery is edited. Passive rows require mastery progress 0, 2, 4, 6, 8 and 10.', readonly=True))
        for slot in range(4, 34):
            node = nodes[slot]; row = (slot-4)//5 + 1
            rows.append(_row(f'asc:{hero}:passive:{slot}', node['label'], hero, name + f' · Passive row {row}', 'Ascendancy',
                int(ranks[slot-1]), 3, description=node['description'] +
                f' Requires mastery progress {(row-1)*2}. Must connect through adjacent allocated nodes to Skill Points. '+dependency_text(node),
                readonly=node.get('editable') is False))
    catalog = charms.charm_catalog()
    for hero, h in _heroes(bank).items():
        for loadout in range(1, 6):
            slots = state.charm_loadouts[hero, loadout]
            for position, current in enumerate(slots, 1):
                options = [dict(value=0, label='Empty')]
                for number, item in catalog.items():
                    owned = state.values['OutdatedStats', f'C{number}']
                    options.append(dict(value=number, label=item['label'] + (f' · owned rank {owned}' if owned else ' · not owned'),
                                        description=item.get('description', '')))
                if current > 7:
                    options.append(dict(value=current, label=f'Preserve existing unknown charm {current}'))
                rows.append(_row(f'charm:{hero}:{loadout}:{position}', f'Charm slot {position}', hero,
                    h['name']+f' · Charm loadout {loadout}', 'Charms', current, max(7, current),
                    description=('Loadout 1 is restored when this hero spawns. ' if loadout == 1 else 'Saved selectable charm loadout. ')+
                    f'Requires an owned charm and Charm Slots rank {position}. The same charm cannot occupy two slots in one loadout. This equips a preference, not a stash item; it does not purchase charms or slot unlocks.',
                    options=options))
    return rows


def apply(bank, state, levels, evos, field_id, value):
    """Apply only dedicated progression controls; return user-visible notes."""
    parts = field_id.split(':')
    if len(parts) < 2 or not parts[1].isdigit() or int(parts[1]) not in _heroes(bank):
        raise BankError('Unsupported Reign progression control.')
    hero = int(parts[1]); info = evolutions.hero_info(hero)
    name = info['name']; notes = []
    if parts[0] == 'charm' and len(parts) == 4:
        loadout = integer(parts[2], 'Charm loadout', 1, 5)
        position = integer(parts[3], 'Charm slot', 1, 3)
        slots = list(state.charm_loadouts[hero, loadout])
        if value == slots[position-1]: return notes
        slots[position-1] = integer(value, 'Charm', 0, 7)
        candidate = charms.set_loadout(state, hero, loadout, slots, bank.profile)
        state.charm_loadouts = candidate.charm_loadouts
    elif parts[0] == 'level' and len(parts) == 2:
        value = integer(value, 'Hero level', 1, 105)
        stage = evos.get(hero)
        if stage and value < evolutions.form_for_stage(hero, stage)['minimum_level']:
            raise BankError('The selected evolution requires a higher hero level; lower the evolution first.')
        state.values['Statistics', info['xp_key']] = level_api.xp_for_level(value)
        state.values['Perks', 'PRank52'] = max(state.values['Perks', 'PRank52'], level_api.required_enhancement(value))
        levels[hero] = value
    elif parts[0] == 'evolution' and len(parts) == 2:
        value = integer(value, 'Evolution form', 0, 8)
        if ('Hero', info['unit_key']) in bank.nodes and evolutions.current_stage(bank, hero) is None:
            raise BankError('The original saved hero form is outside the verified chain.')
        evolutions.prepare_selection(bank, state, hero, value)
        evos[hero] = value
        # An earlier exact-level selection must remain consistent after the XP floor rises.
        if hero in levels and state.values['Statistics', info['xp_key']] != level_api.xp_for_level(levels[hero]):
            levels[hero] = level_api.level_for_xp(state.values['Statistics', info['xp_key']])
        if ('Hero', info['unit_key']) not in bank.nodes:
            notes.append(name+': unlock updated, but no saved hero exists to evolve. Play and save this hero once.')
    elif parts[0] == 'mastery' and len(parts) == 2:
        value = integer(value, 'Hero mastery', 0, 40)
        candidate = state.clone(); candidate.values['Perks', f'PRank{95+hero}'] = value
        if value: candidate = apply_mastery_progress(candidate, hero)
        state.values.update(candidate.values)
        notes.append(name+': mastery and supported progress updated; XP and loadouts retained.')
    elif parts[0] == 'asc' and len(parts) >= 3:
        pair = ('Asc', f'AscEncryptionKey{hero}'); pool_pair = ('Asc', f'AscPassPts{hero}')
        ranks = list(state.values[pair]); pool = state.values[pool_pair]
        if parts[2] == 'budget' and len(parts) == 3:
            value = integer(value, 'Total passive points', 0, 25)
            spent = sum(map(int, ranks[3:]))
            if value < spent: raise BankError('Refund passive ranks before lowering the total below allocated points.')
            state.values[pool_pair] = value-spent
        elif parts[2] == 'ability' and len(parts) == 3:
            value = integer(value, 'Ability specialization', -2, 3)
            if value == -2: return notes
            if value > 0:
                asc = next(h for h in load_help('ascendancy')['heroes'] if int(h['id']) == hero)
                node = next(n for n in asc['nodes'] if int(n['slot']) == value)
                if node.get('editable') is False: raise BankError('This ability is preserved read-only.')
            ranks[:3] = ['1' if value == i else '0' for i in range(1, 4)]
            state.values[pair] = ''.join(ranks)
            state.values['Asc', f'AscAbilPts{hero}'] = int(value == -1)
        elif parts[2] == 'passive' and len(parts) == 4:
            slot = integer(parts[3], 'Passive node', 4, 33)
            asc = next(h for h in load_help('ascendancy')['heroes'] if int(h['id']) == hero)
            node = next(n for n in asc['nodes'] if int(n['slot']) == slot)
            if node.get('editable') is False: raise BankError('This passive is preserved read-only.')
            value = integer(value, 'Passive rank', 0, 3); delta = value-int(ranks[slot-1])
            if delta > pool: raise BankError('Not enough unspent passive points; increase Total passive points first.')
            if value and state.values['Asc', f'MG{hero}'] < ((slot-4)//5)*2:
                raise BankError('This passive row requires more mastery progress.')
            ranks[slot-1] = str(value); state.values[pair] = ''.join(ranks); state.values[pool_pair] -= delta
            # Whole-tree connectivity is checked by Bank.render after the edit batch.
        else: raise BankError('Unsupported Reign ascendancy control.')
    else: raise BankError('Unsupported Reign progression control.')
    return notes


def readiness(bank, state, evos):
    """Source-backed per-hero saved-unit coverage for the editor overview."""
    from .hero_readiness import report
    return report(bank, state, evolutions=evos)


def organize(rows, profile):
    """Enrich ordinary fields and group them for category/hero button navigation."""
    specs = {(s['section'], s['key']): s for s in enriched_profile(profile)['fields']}
    heroes = {int(h['id']): h['name'] for h in profile['heroes']}
    for row in rows:
        path = row.get('path')
        if not path:
            try: path = json.loads(row['id'])
            except (ValueError, TypeError): continue
        if not isinstance(path, list) or len(path) != 2 or path[0] != 'values': continue
        pair = tuple(path[1]); spec = specs.get(pair)
        if not spec: continue
        section, key = pair; label = spec['label']; original = spec.get('group', '')
        row['description'] = field_description(spec); row['label'] = label
        hero = spec.get('hero')
        match = re.match(r'(?:Hero|H|RuneOfSynergyType)(\d+)', key)
        if hero is None and match: hero = int(match[1])
        if hero is None:
            hero = next((n for n, name in heroes.items() if label.startswith(name+' ') or label.startswith(name+' ·')), None)
        if hero in heroes: row['hero'] = hero
        elif hero is not None: row['category'] = 'Advanced'; row['group'] = 'Reserved hero records'; continue
        if 'alternate writer XP' in label:
            row['category'],row['group']='Advanced','Preserved XP aliases'
            continue
        if original == 'Resources': category, group = 'Resources', 'Currencies & magic find'
        elif original in ('Time and records', 'Shop records', 'Records'):
            category, group = 'Records', (heroes[hero]+' · Records' if hero in heroes else 'Global records')
        elif original == 'Charms': category, group = 'Charms', 'Owned charms'
        elif original == 'Settings': category, group = 'Preferences', 'Display & hero preferences'
        elif original == 'Perks':
            category, group = 'Perks', 'General perks'
            if label.startswith('Perk '): category, group = 'Advanced', 'Unmapped perk records'
            elif 'Damage Enhancement' in label: group = 'Damage perks'
            elif any(x in label for x in ('Item', 'Glyph', 'Charm', 'Find')): group = 'Equipment & loot perks'
        elif original == 'Hero perk records': category, group = 'Records', (heroes[hero]+' · Purchase history' if hero in heroes else 'Purchase history')
        elif section == 'Asc': category, group = 'Advanced', 'Preserved ascendancy encoding'
        elif original == 'Heroes': category, group = 'Heroes', 'Hero progression'
        else: continue
        if 'Reserved' in label or (section == 'Settings' and re.fullmatch(r'UISetting(?:1[1-5])', key)):
            category, group = 'Advanced', 'Reserved preferences & records'
        row['category'], row['group'] = category, group
    return rows
