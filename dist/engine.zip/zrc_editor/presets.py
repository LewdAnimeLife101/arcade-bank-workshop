"""Bounded Reign unlock preset. Plans are validated in memory, never saved."""
from dataclasses import dataclass,field

from .common import BankError
from .dependencies import passive_total,effective_ordinary_record
from .levels import xp_for_level
from . import glyphs,items


CATEGORIES = {
    'perks': 'Supported perks at their individual caps',
    'heroes': 'All 11 heroes: level 105, evolution 8 and saved forms where present',
    'mastery': 'Mastery rank 40, all passive rows and available ascendancy points',
    'charms': 'All seven charms at catalog effect rank 101; three charm slots',
    'items': 'Own every supported equipment type (121); use free Softcore stash slots',
    'glyphs': 'All 84 glyph powers per hero; tier 30 and capped stats',
    'content': 'Known content unlock thresholds and magic-find writer ceiling',
}


@dataclass
class Plan:
    before: object
    state: object
    old_levels: dict
    levels: dict
    categories: frozenset
    bank_digest: str
    notes: list[str]
    changed_fields: int
    rendered_bytes: int
    old_evolutions: dict = field(default_factory=dict)
    evolutions: dict = field(default_factory=dict)

    def summary(self):
        return '\n'.join([
            'UNLOCK ALL — VALIDATED PENDING-EDIT PLAN',
            f'{self.changed_fields:,} changed progression fields · {self.rendered_bytes:,} output bytes',
            '',*self.notes,'',
            'Apply reviewed preset changes pending edits only. Use Export copy or Replace current bank to save.',
            'Ordinary saves still require validation, source freshness and independent backups.',
            'Published-map acceptance of this combined preset has not been tested.',
        ])


def _glyph_collection(state,profile,notes):
    state.values['Perks','PRank21']=30
    limits={s:glyphs.max_value(profile,s,30) for s in range(1,28)}
    added=updated=equipped=skipped=missing=0
    groups=glyphs.power_catalog()['qualities']
    for hero in (h['id'] for h in profile['heroes']):
        known={1:set(),2:set(),3:set()};empty=[]
        for slot in range(95):
            if not any(state.values[p].strip() for p in glyphs.keys(hero,slot)):
                if slot<=90:empty.append(slot)
                continue
            try:g=glyphs.record(state,hero,slot)
            except BankError:skipped+=1;continue
            known[g.quality].update(g.powers)
            tier=max(30,g.tier)
            caps={s:(limits[s] if tier==30 else glyphs.max_value(profile,s,tier)) for s in g.types if 1<=s<=27}
            # Preserve unusual legacy rolls and unmapped types, rather than
            # reducing a stronger glyph or assigning a reserved effect.
            if any(s not in caps or v>caps[s] for s,v in zip(g.types,g.values)):
                skipped+=1;continue
            new=glyphs.Glyph(g.types,tuple(caps[s] for s in g.types),g.quality,g.powers,tier)
            fields=glyphs.fields(new)
            if fields!=tuple(state.values[p] for p in glyphs.keys(hero,slot)):
                state.values.update(zip(glyphs.keys(hero,slot),fields));updated+=1
        for group in groups:
            quality=group['id']
            for power in group['powers']:
                if power['id'] in known[quality]:continue
                if not empty:missing+=1;continue
                slot=empty.pop(0)
                # Two alternating 15-line layouts cover all 27 implemented
                # stats across the first two Legendary glyphs. Repeats across
                # equipped glyphs are supported; each individual amount is capped.
                start=0 if power['id']%2 else 12
                stats=tuple(1+(start+i)%27 for i in range(15))
                new=glyphs.Glyph(stats,tuple(limits[s] for s in stats),quality,(power['id'],),30)
                state.values.update(zip(glyphs.keys(hero,slot),glyphs.fields(new)))
                known[quality].add(power['id']);added+=1
        # Fill empty equipped positions only. Existing choices are retained;
        # a displaced storage glyph is never overwritten.
        for slot,(quality,_) in glyphs.EQUIPPED.items():
            if any(state.values[p].strip() for p in glyphs.keys(hero,slot)):continue
            for source in range(91):
                try:g=glyphs.record(state,hero,source)
                except BankError:continue
                if g is None or g.quality!=quality:continue
                a,b=glyphs.keys(hero,source),glyphs.keys(hero,slot)
                for left,right in zip(a,b):state.values[left],state.values[right]=state.values[right],state.values[left]
                equipped+=1;break
    notes.append(f'Glyphs: {added} added, {updated} existing records maxed, {equipped} empty equipment slots filled. Every hero gets the available missing powers; existing equipped choices remain.')
    notes.append('New glyphs use one named power and 15 stat lines at tier 30. This is the supported storage capacity, above natural drop line counts; it is not a claim that tier 30 is the highest possible drop tier.')
    if skipped:notes.append(f'Preserved {skipped} legacy glyph records with unsupported data or stronger-than-preset rolls.')
    if missing:notes.append(f'SKIPPED: {missing} missing hero/power combinations could not fit in available glyph storage. Existing glyphs were retained.')


def build_plan(bank,before,*,levels=None,categories=None,hero_evolutions=None):
    if not bank.original_verified():raise BankError('Open a supported bank with passing original checks before using Unlock all.')
    selected=frozenset(CATEGORIES if categories is None else categories)
    if not selected or selected-set(CATEGORIES):raise BankError('Choose at least one supported unlock category.')
    state=before.clone();old_levels=dict(levels or {});new_levels=dict(old_levels);notes=[]
    old_evolutions=dict(hero_evolutions or {});evolutions=dict(old_evolutions)
    profile=bank.profile;heroes={h['id'] for h in profile['heroes']}
    if 'perks' in selected:
        count=0
        for spec in profile['fields']:
            key=spec['key']
            if spec['section']!='Perks' or not key.startswith('PRank') or not spec.get('editable'):continue
            number=int(key[5:])
            if number==15 or number>=96:continue
            state.values['Perks',key]=spec['max'];count+=1
        notes.append(f'Perks: {count} supported global ranks set to their individual source caps. Reserved perks, unresolved perk 15 and historical reset counters are retained.')
    if 'heroes' in selected:
        state.values['Perks','PRank52']=25
        for spec in profile['fields']:
            if spec.get('unit_key'):
                state.values[spec['section'],spec['key']]=xp_for_level(105);new_levels[spec['hero']]=105
            elif spec['section']=='Evolutions' and spec.get('editable'):state.values[spec['section'],spec['key']]=8
        evolutions.update({hero:8 for hero in heroes})
        from .evolutions import prepare_selection
        for hero in heroes:prepare_selection(bank,state,hero,8)
        notes.append('Heroes: all 11 set to level 105 / 55,640 XP and evolution stage 8. Existing saved hero forms, XP and XP migration markers are synchronized. Missing heroes get the unlock only and must be played and saved once before their form can be changed. Skill choices and equipment are retained.')
    if 'mastery' in selected:
        reserved=0
        for hero in heroes:
            state.values['Perks',f'PRank{95+hero}']=40
            state.values['Perks',f'H{hero}PRank24']=10
            mg=('Asc',f'MG{hero}');state.values[mg]=11
            original_total=passive_total(bank.state,hero)
            grant=max(0,11-bank.state.values[mg])
            marker=('NextUpdateEncryptionKey',f'KeyString{hero}') in bank.nodes
            room=25 if marker or grant>0 and original_total+grant<=25 else 24
            # Existing full budgets are retained on a no-level-change plan.
            if original_total==25 and 'heroes' not in selected:room=25
            ranks=state.values['Asc',f'AscEncryptionKey{hero}'];spent=sum(map(int,ranks[3:]))
            if spent>room:raise BankError(f'Hero {hero}: existing allocation uses {spent} points but only {room} are available with the pending level-100 award. Return one point in Ascendancy before applying this preset.')
            state.values['Asc',f'AscPassPts{hero}']=room-spent
            if not any(int(x) for x in ranks[:3]):state.values['Asc',f'AscAbilPts{hero}']=1
            if room==24:reserved+=1
        notes.append('Mastery: rank 40 and progress 11 for every hero; passive-point purchase counters 10; up to 25 total passive points. Allocations and ability choices remain, with unused points available. This does not replay a prestige purchase or reset XP.')
        notes.append('Mastery rank changes reduce future XP gain according to the map. All passive rows open, but the shared 25-point budget still prevents maxing every passive at once.')
        if reserved:notes.append(f'{reserved} heroes retain one point of room (24 total) because their level-100 award is pending; a later award can bring the total to 25.')
    if 'charms' in selected:
        for charm in range(1,8):state.values['OutdatedStats',f'C{charm}']=max(101,state.values['OutdatedStats',f'C{charm}'])
        state.values['Perks','PRank57']=3
        notes.append('Charms: all seven owned at rank 101 or their higher existing rank; all three slots unlocked. Rank 101 reaches the catalog upgrade ceiling, not a verified stored-rank maximum. Existing loadouts stay selected; some charms have tradeoffs, so none are auto-equipped.')
    if 'items' in selected:
        if bank.bank_name!='HackersWillBeBanned':notes.append('SKIPPED equipment grants: the map disables the stash in Hardcore.')
        elif items.STASH_PAIR not in state.unit_items:notes.append('SKIPPED equipment grants: a supported existing Softcore stash unit is required. Save a Softcore hero in game first.')
        else:
            current=list(state.unit_items[items.STASH_PAIR]);owned={i.unit_id for entries in state.unit_items.values() for i in entries};added=missing=0
            for item in items.catalog()['items']:
                if item['unit_id'] in owned:continue
                position=next(((tab,slot) for tab in range(4) if (slot:=items.first_free(current,tab)) is not None),None)
                if position is None:missing+=1;continue
                current.append(items.Item(item['unit_id'],*position));owned.add(item['unit_id']);added+=1
            state.unit_items[items.STASH_PAIR]=items.validate_items(state.unit_items[items.STASH_PAIR],current)
            notes.append(f'Equipment: {added} missing types added to free stash slots; types already owned in saved hero inventories count as owned. Existing items stay in place. Equip items in game to activate bonuses.')
            if missing:notes.append(f'SKIPPED: {missing} equipment types could not fit in the stash; existing items were retained.')
    if 'glyphs' in selected:_glyph_collection(state,profile,notes)
    if 'content' in selected:
        # These are verified unlock thresholds/writer bounds, not invented
        # integer-storage maxima for historical record families.
        state.values['Diseases','Plague']=100
        if effective_ordinary_record(state)!=100:
            state.values['Diseases','Plague']=before.values['Diseases','Plague']
            notes.append('SKIPPED ordinary solo record: a preserved legacy record would override 100. The preset does not rewrite that protected legacy field.')
        state.values['Diseases','KPlague']=max(101,state.values['Diseases','KPlague'])
        state.values['GameTS','HSEC']=max(6,state.values['GameTS','HSEC'])
        state.values['GameTS','MF']=100_000_000
        notes.append(f"Content: ordinary solo record {state.values['Diseases','Plague']} (target 100); Kalimdor record at least 101 for its documented startup unlock; shop-tier hint at least 6; magic find at the 100,000,000 normal writer ceiling. These edits affect future multipliers, not prior rewards or clear times.")
    notes.append('Preserved: currencies, kills, playtime, clear-time history, reset counters, cosmetics/account entitlements, reserved records and opaque skill/item loadouts. No proven gameplay maximum exists for many of these, and all abilities cannot be selected simultaneously.')
    raw,render_notes=bank.render(state,hero_levels=new_levels,hero_evolutions=evolutions)
    if evolutions:notes.extend(render_notes)
    from .hero_readiness import report
    notes.insert(0,report(bank,state,evolutions=evolutions))
    changed=sum(v!=before.values[p] for p,v in state.values.items())
    return Plan(before.clone(),state,old_levels,new_levels,selected,bank.digest,notes,changed,len(raw),old_evolutions,evolutions)
