"""Hero level thresholds checked against the installed game's native XP API."""
from bisect import bisect_right
from functools import lru_cache
import json
from .common import resource_path,BankError,integer
from zwl_editor.fixed import SCALE


@lru_cache(maxsize=1)
def catalog():
    return json.loads(resource_path('data/hero_levels.json').read_text(encoding='utf-8'))


def xp_for_level(level):
    level=integer(level,'Hero level',1,catalog()['maximum_level'])
    return catalog()['minimum_xp'][level-1]*SCALE


def level_for_xp(raw,cap=105):
    return min(cap,max(1,bisect_right(catalog()['minimum_xp'],raw/SCALE)))


def required_enhancement(level):
    xp_for_level(level)
    return max(0,int(level)-catalog()['base_level_cap'])


def label(level):
    return f"Level {level} · {catalog()['minimum_xp'][level-1]:,} XP"


def selected_level(text):
    # Editable dropdown accepts a level number as well as its displayed label.
    text=str(text).strip()
    if text.startswith('Level '): text=text[6:].split(' · ',1)[0]
    return integer(text,'Hero level',1,catalog()['maximum_level'])


def validate_selections(bank,target,selections):
    specs={s['hero']:s for s in bank.profile['fields'] if s.get('unit_key')}
    for hero,level in selections.items():
        if type(hero) is not int or hero not in specs: raise BankError('Unknown hero level selection.')
        spec=specs[hero]
        if target.values[(spec['section'],spec['key'])]!=xp_for_level(level):
            raise BankError(spec['label']+': selected level and XP do not agree.')
        if target.values[('Perks','PRank52')]<required_enhancement(level):
            raise BankError(spec['label']+': raise Hero Enhancement to support the selected level.')
    return specs
