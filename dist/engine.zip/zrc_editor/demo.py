"""Synthetic signed sample; no copied account or game state."""
import xml.etree.ElementTree as ET

from .core import Bank, signature_for

DEMO_PLAYER = "1-S2-1-1234567"
DEMO_AUTHOR = "1-S2-1-7654321"


def demo_bytes(*, player=DEMO_PLAYER, author=DEMO_AUTHOR, bank_name="HackersWillBeBanned", include_units=False):
    root = ET.Element("Bank", version="1")
    for section, key, kind, value in [
        ("Statistics", "HighestWave", "int", "8"),
        ("Statistics", "TotalKills", "int", "120"),
        ("Statistics", "FootmanXP", "fixed", "12.5"),
        ("Evolutions", "FootmanEvo", "int", "1"),
        ("GameDecoder", "KeyVariant", "int", "100"),
        ("SC2Switcher", "BlizzEnc", "int", "5"),
    ]:
        sec = next((s for s in root if s.get("name") == section), None)
        if sec is None:
            sec = ET.SubElement(root, "Section", name=section)
        ET.SubElement(ET.SubElement(sec, "Key", name=key), "Value", **{kind: value})
    if include_units:
        # Fictional, deliberately small inventories for interactive UI examples.
        from .evolutions import catalog, form_for_stage
        heroes = ET.SubElement(root, "Section", name="Hero")
        for hero in catalog()['heroes']:
            unit = ET.SubElement(heroes, "Key", name=hero['unit_key'])
            ET.SubElement(unit, "Type", string=form_for_stage(hero['id'], 1)['unit_id'])
            ET.SubElement(unit, "ItemCount", int="0")
            ET.SubElement(unit, "XPName0", string="AHer")
            ET.SubElement(unit, "XP", fixed="12.5" if hero["id"] == 1 else "0")
            ET.SubElement(unit, "XPValue0", fixed="12.5" if hero["id"] == 1 else "0")
        stash = ET.SubElement(ET.SubElement(root, "Section", name="Stashes"), "Key", name="StashBox1")
        ET.SubElement(stash, "Type", string="ShapeTreasureChestClosed")
        ET.SubElement(stash, "ItemCount", int="0")
    ET.SubElement(root, "Signature", value=signature_for(root, player, author, bank_name))
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)+b"\n"


def demo_bank():
    return Bank(demo_bytes(), player=DEMO_PLAYER, author=DEMO_AUTHOR)
