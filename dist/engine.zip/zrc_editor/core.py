"""Source-derived current0.291 primitive fields with native XML signature checks.

Flat serialized unit leaves are preserved and included in the signature. This
canonicalization exactly reproduced the observed original mixed-type bank;
nested/unknown primitive shapes and non-ASCII content fail closed.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import copy
import hashlib
import re
import xml.etree.ElementTree as ET

from .common import BankError, HANDLE, INT_MIN, INT_MAX, integer, load_profile
from zwl_editor.fixed import SCALE, parse_fixed, format_fixed, int_fixed
from mineralz_editor.protection import _multiply, _power


@dataclass(eq=True)
class State:
    values: dict[tuple[str, str], int | bool | str] = field(default_factory=dict)
    unit_items: dict = field(default_factory=dict)
    charm_loadouts: dict = field(default_factory=dict)
    item_loadouts: dict = field(default_factory=dict)

    def clone(self):
        return copy.deepcopy(self)


def _value(text, kind):
    if kind == "int":
        return integer(text, "Bank integer", INT_MIN, INT_MAX)
    if kind == "fixed":
        return parse_fixed(text)
    if kind == "flag":
        if text not in ("0", "1"):
            raise BankError("Invalid flag value.")
        return text == "1"
    if kind == "string" and isinstance(text, str):
        return text
    raise BankError("Unsupported primitive bank value.")


def _inspect_root(root):
    if root.tag != "Bank" or root.attrib != {"version": "1"}:
        raise BankError("Expected a version1 Bank document.")
    if (root.text or "").strip():
        raise BankError("Unexpected root text.")
    sections, nodes = {}, {}
    signatures = []
    for child in root:
        if not isinstance(child.tag, str):
            continue
        if (child.tail or "").strip():
            raise BankError("Unexpected text outside bank sections.")
        if child.tag == "Signature":
            if child.attrib.keys() != {"value"} or len(child) or (child.text or "").strip():
                raise BankError("Malformed signature element.")
            if not re.fullmatch("[0-9a-fA-F]{40}", child.get("value", "")):
                raise BankError("Malformed native signature.")
            signatures.append(child)
            continue
        if child.tag != "Section" or child.attrib.keys() != {"name"}:
            raise BankError("Unsupported bank root or section structure.")
        section = child.get("name")
        if not section or section in sections or (child.text or "").strip():
            raise BankError("Missing/duplicate section or unexpected text.")
        sections[section] = child
        for key in child:
            if not isinstance(key.tag, str):
                continue
            if key.tag != "Key" or key.attrib.keys() != {"name"} or not key.get("name"):
                raise BankError("Unsupported key structure.")
            if (key.tail or "").strip():
                raise BankError("Unexpected text outside bank keys.")
            pair = section, key.get("name")
            if pair in nodes or (key.text or "").strip():
                raise BankError("Duplicate key or unexpected key text.")
            nodes[pair] = key
            tags = set()
            leaves = [leaf for leaf in key if isinstance(leaf.tag, str)]
            if not leaves:
                raise BankError("An empty key is unsupported.")
            for leaf in leaves:
                if leaf.tag in tags or len(leaf.attrib) != 1 or len(leaf) or any((t or "").strip() for t in (leaf.text, leaf.tail)):
                    raise BankError("Nested, duplicate or malformed bank leaves are unsupported.")
                tags.add(leaf.tag)
                kind, text = next(iter(leaf.attrib.items()))
                _value(text, kind)
    if len(signatures) > 1:
        raise BankError("Duplicate native signatures.")
    return sections, nodes, signatures[0] if signatures else None


def signature_for(root, player, author, bank_name):
    """Canonical flat-leaf native XML signature, preserving lexical values."""
    if not HANDLE.fullmatch(player or "") or not HANDLE.fullmatch(author or ""):
        raise BankError("Original player and map-author handles are required for native signing.")
    if not bank_name or any(c in bank_name for c in "/\\\x00"):
        raise BankError("Invalid bank name for native signing.")
    sections, nodes, _ = _inspect_root(root)
    parts = [author, player, bank_name]
    for section in sorted(sections):
        parts.append(section)
        for pair in sorted(pair for pair in nodes if pair[0] == section):
            parts.append(pair[1])
            for leaf in sorted((n for n in nodes[pair] if isinstance(n.tag, str)), key=lambda n: n.tag):
                kind, text = next(iter(leaf.attrib.items()))
                parts.extend((leaf.tag, kind, text))
    payload = "".join(parts)
    if not payload.isascii():
        raise BankError("Non-ASCII native signature content is outside the verified codec scope.")
    return hashlib.sha1(payload.encode("ascii")).hexdigest().upper()


def validate(state, profile, *, before=None):
    definitions = {(f["section"], f["key"]): f for f in profile["fields"]}
    if set(state.values) != set(definitions):
        raise BankError("Incomplete or unexpected editor state fields.")
    for pair, spec in definitions.items():
        value = state.values[pair]
        if before is not None and pair[0]=='Glyphs3' and pair[1].startswith('Hero6GSlot') and value!=before.values[pair]:
            raise BankError('Reserved hero 6 glyph records are preserved read-only.')
        if before is not None and pair[0] != "Glyphs3" and not spec.get("editable", True) and value != before.values[pair]:
            if pair[0]=="Asc" and pair[1].startswith("MG"):
                hero=int(pair[1][2:]); rank=state.values[("Perks",f"PRank{95+hero}")]
                if not (hero in {h["id"] for h in profile["heroes"]} and rank>0 and value==rank//4+1 and 0<=value<=11):
                    raise BankError("Mastery progress is read-only except for a matching mastery update. Use Apply mastery progress in Ascendancy.")
            else: raise BankError(spec["label"]+" is preserved read-only.")
        kind = spec["type"]
        if kind in ("int", "fixed"):
            if type(value) is not int or not spec["min"] <= value <= spec["max"]:
                raise BankError(spec["label"]+": value is outside its supported bounds.")
        elif kind == "flag":
            if type(value) is not bool:
                raise BankError(spec["label"]+": expected a boolean.")
        elif kind == "string":
            if not isinstance(value, str) or not value.isascii():
                raise BankError(spec["label"]+": unsupported string content.")
        else:
            raise BankError("Unknown profile field type.")
    for hero in range(1, 13):
        ranks = state.values[("Asc", "AscEncryptionKey"+str(hero))]
        if not re.fullmatch(r"[01]{3}[0-3]{30}", ranks) or sum(map(int, ranks[:3])) > 1:
            raise BankError(f"Hero {hero}: expected33 ascendancy digits with one binary ability choice and passive ranks0..3.")
        if sum(map(int, ranks[3:]))+state.values[("Asc", "AscPassPts"+str(hero))] > 25:
            raise BankError(f"Hero {hero}: spent plus unspent passive points exceed the source loader cap25.")
        if before is not None:
            old_ranks=before.values[("Asc",f"AscEncryptionKey{hero}")]
            if ranks[3:]!=old_ranks[3:]:
                from .guidance import validate_passive_tree
                validate_passive_tree(list(map(int,ranks)),state.values[("Asc",f"MG{hero}")])
            changed_ability=(ranks[:3],state.values[("Asc",f"AscAbilPts{hero}")])!=(old_ranks[:3],before.values[("Asc",f"AscAbilPts{hero}")])
            if changed_ability and sum(map(int,ranks[:3]))+state.values[("Asc",f"AscAbilPts{hero}")]>1:
                raise BankError("An ability selection consumes its ability point. Keep one choice or one unspent point.")
            mastery_rank=state.values[("Perks",f"PRank{95+hero}")]
            if mastery_rank!=before.values[("Perks",f"PRank{95+hero}")] and mastery_rank>0 and state.values[("Asc",f"MG{hero}")]!=mastery_rank//4+1:
                raise BankError(f"Hero {hero}: the mastery rank changed. Use Apply mastery progress in Ascendancy before exporting.")
    _validate_glyphs(state, profile)
    if before is not None:
        from .glyphs import validate_changes
        validate_changes(before, state, profile)
        from .dependencies import validate_dependencies
        validate_dependencies(before, state, profile)
        from .items import carrier_for_pair,validate_items
        if set(state.unit_items)!=set(before.unit_items):
            raise BankError('Only supported existing saved inventories can be edited.')
        for pair,items in state.unit_items.items():
            if items!=before.unit_items[pair]:
                canonical=validate_items(before.unit_items[pair],items,carrier=carrier_for_pair(pair),perk_rank18=state.values[('Perks','PRank18')])
                if type(items) is not tuple or items!=canonical:raise BankError('Inventory edits must use canonical item ordering.')
    from .charms import validate_loadouts
    validate_loadouts(before,state,profile)
    from .item_loadouts import validate as validate_item_loadouts
    validate_item_loadouts(before.item_loadouts if before is not None else None,state.item_loadouts)


def _words(text):
    tokens = text.split()
    if len(tokens) > 15 or any(not re.fullmatch(r"[+]?[0-9]+(?:\.[0-9]*)?", t) for t in tokens):
        raise BankError("Glyph words must contain at most15 nonnegative fixed decimal values.")
    return [parse_fixed(t) for t in tokens]


def glyph_limits(profile):
    ranges = [0]+[parse_fixed(text) for text in profile["glyph_stat_ranges"]]
    tier40 = _power(parse_fixed("1.085"), int_fixed(40))
    return [_multiply(_multiply(value, parse_fixed("1.77")), tier40) for value in ranges]


def _validate_glyphs(state, profile, *, before=None):
    caps=glyph_limits(profile)
    for hero in range(1, 13):
        for slot in range(95):
            prefix = f"Hero{hero}GSlot{slot}GStat"
            types = _words(state.values[("Glyphs3", prefix+"Type")])
            values = _words(state.values[("Glyphs3", prefix+"Value")])
            if len(types) != len(values):
                raise BankError(f"Hero {hero} glyph{slot}: stat types and values must have matching word counts.")
            old_types=_words(before.values[("Glyphs3",prefix+"Type")]) if before is not None else types
            old_values=_words(before.values[("Glyphs3",prefix+"Value")]) if before is not None else values
            for line,(type_raw, value) in enumerate(zip(types, values)):
                index = type_raw//SCALE
                if type_raw % SCALE or not 1 <= index < len(caps):
                    raise BankError(f"Hero {hero} glyph{slot}: unsupported stat type.")
                if value > caps[index]:
                    raise BankError(f"Hero {hero} glyph{slot}: stat exceeds the source loader threshold.")
                if before is not None and (line >= len(old_types) or (type_raw,value)!=(old_types[line],old_values[line])):
                    if index>27: raise BankError("Reserved glyph stat types are preserved read-only.")
                    if value<parse_fixed("0.1"):
                        raise BankError("Changed glyph values must be at least 0.1. Smaller values can disappear from the game's one-decimal save list.")


class Bank:
    def __init__(self, raw, path=None, profile=None, *, player="", author=""):
        self.raw = raw
        self.path = Path(path).resolve() if path is not None else None
        self.profile = profile or load_profile()
        self.bank_name = self.path.stem if self.path is not None else self.profile["bank_name"]
        inferred_player = inferred_author = ""
        if self.path is not None and self.path.parent.parent.name.casefold() == "banks":
            inferred_player, inferred_author = self.path.parent.parent.parent.name, self.path.parent.name
        self.player, self.author = player or inferred_player, author or inferred_author
        self.digest = hashlib.sha256(raw).hexdigest()
        self.state = None
        self.errors, self.warnings, self.checks = [], [], {}
        self.signature_verified = False
        self.present = set()
        self._signature_status = "Unverified"
        try:
            if len(raw) > 4*1024*1024:
                raise BankError("Bank exceeds the4MB limit.")
            text = raw.decode("utf-8-sig")
            if "<!DOCTYPE" in text.upper() or "<!ENTITY" in text.upper():
                raise BankError("DTD/entities are unsupported.")
            self.root = ET.fromstring(text, parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True, insert_pis=True)))
            self.sections, self.nodes, signature = _inspect_root(self.root)
            if not {"Statistics", "Evolutions", "GameDecoder"}.issubset(self.sections):
                raise BankError("Structure does not match the current Reign bank schema.")
            self.checks["structure"] = True
            values = {}
            for spec in self.profile["fields"]:
                pair = spec["section"], spec["key"]
                key = self.nodes.get(pair)
                if key is None:
                    values[pair] = spec["default"]
                    continue
                leaves = [c for c in key if isinstance(c.tag, str)]
                if len(leaves) != 1 or leaves[0].tag != "Value" or set(leaves[0].attrib) != {spec["type"]}:
                    raise BankError("Expected "+spec["type"]+" at "+"/".join(pair))
                values[pair] = _value(leaves[0].get(spec["type"]), spec["type"])
                self.present.add(pair)
            from .items import carrier_for_pair,read_items
            inventories={}
            for pair,node in self.nodes.items():
                if carrier_for_pair(pair):
                    try:inventories[pair]=read_items(node)
                    except BankError:self.warnings.append('/'.join(pair)+': unrecognized inventory layout is preserved read-only.')
            from .charms import read_loadouts
            from .item_loadouts import read as read_item_loadouts
            self.state = State(values,unit_items=inventories,charm_loadouts=read_loadouts(self.nodes,self.profile),item_loadouts=read_item_loadouts(self.nodes))
            validate(self.state, self.profile)
            self.checks["source_bounds"] = True
            if self.bank_name not in self.profile["bank_main_names"]:
                raise BankError("Keep the exact original Softcore/Hardcore mode bank filename.")
            if signature is None:
                self._signature_status = "Missing"
                raise BankError("The original native signature is required for changed export.")
            calculated = signature_for(self.root, self.player, self.author, self.bank_name)
            self.signature_verified = calculated == signature.get("value").upper()
            self.checks["signature"] = self.signature_verified
            self._signature_status = "Verified" if self.signature_verified else "Mismatch"
            if not self.signature_verified:
                raise BankError("Original native signature does not match the player, author and exact bank name.")
            self.warnings.append("Schema audited for publication0.291; this bank has no embedded proof of writer publication.")
            self.warnings.append("Unedited unit, inventory and loadout content is preserved. Explicit evolution selections synchronize supported saved hero forms; a missing saved hero must be played and saved once first.")
            if any(("HeroPatch#", "H"+str(h["id"])) not in self.nodes for h in self.profile["heroes"]):
                self.warnings.append("Some hero XP migration markers are absent. An explicit level selection marks that hero's XP as current-version; other heroes retain their original migration state.")
        except (BankError, ValueError, UnicodeError, ET.ParseError) as exc:
            self.errors.append(str(exc))

    @classmethod
    def read(cls, path, profile=None, *, player="", author=""):
        path = Path(path).resolve()
        if path.stat().st_size > 4*1024*1024:
            raise BankError("Bank exceeds the4MB limit.")
        with path.open("rb") as stream:
            raw = stream.read(4*1024*1024+1)
        return cls(raw, path, profile, player=player, author=author)

    def signature_status(self):
        return self._signature_status

    def original_verified(self):
        """Recheck the original root against the current signing context."""
        if self.errors or not self.signature_verified:
            return False
        signature = self.root.find("Signature")
        return signature is not None and signature_for(self.root, self.player, self.author, self.bank_name) == signature.get("value", "").upper()

    def render(self, target, *, hero_levels=None, hero_evolutions=None):
        if self.state is None or not self.original_verified():
            raise BankError("Read-only: "+"; ".join(self.errors or ["Original signature is unverified."]))
        validate(target, self.profile, before=self.state)
        from .dependencies import validate_dependencies
        validate_dependencies(self.state,target,self.profile,bank=self)
        from .items import STASH_PAIR,apply_items,carrier_for_pair
        if self.bank_name=='BlizzardBuiltIn' and target.unit_items.get(STASH_PAIR)!=self.state.unit_items.get(STASH_PAIR):
            raise BankError('The map disables the stash in Hardcore. Stash changes are available only for Softcore banks.')
        from .levels import validate_selections
        selections=dict(hero_levels or {})
        level_specs=validate_selections(self,target,selections)
        from .evolutions import validate_selections as validate_evolutions, apply_selections as apply_evolutions, verify_output as verify_evolutions
        evolution_selections=dict(hero_evolutions or {})
        evolution_specs=validate_evolutions(self,target,evolution_selections)
        forced=set()
        for hero in selections:
            spec=level_specs[hero];pair=(spec['section'],spec['key'])
            unit=self.nodes.get(('Hero',spec['unit_key']))
            value=target.values[pair]
            # Explicit selections also repair an out-of-sync unit or complete the
            # XP-only migration, even if the scalar already equals the target.
            if ('HeroPatch#',f'H{hero}') not in self.nodes or unit is not None and any(
                leaf is None or leaf.attrib.keys()!={'fixed'} or parse_fixed(leaf.get('fixed'))!=value
                for leaf in (unit.find('XP'),unit.find('XPValue0'))): forced.add(pair)
        # A same-stage choice intentionally repairs an out-of-sync saved Type.
        # Its existing XP is current-version and must survive the map's migration.
        evolution_xp_heroes={hero for hero,stage in evolution_selections.items() if stage and ('Hero',evolution_specs[hero]['unit_key']) in self.nodes}
        for hero in evolution_xp_heroes:
            forced.add(('Statistics',evolution_specs[hero]['xp_key']))
        if target == self.state and not forced and not evolution_selections:
            return self.raw, []
        root = copy.deepcopy(self.root)
        sections, nodes, signature = _inspect_root(root)
        notes = []
        for spec in self.profile["fields"]:
            pair = spec["section"], spec["key"]
            value = target.values[pair]
            if value == self.state.values[pair] and pair not in forced:
                continue
            if pair[0] != "Glyphs3" and spec.get("requires_existing") and pair not in self.present:
                raise BankError(spec["label"]+": only existing glyph fields can be edited; no opaque glyph is synthesized.")
            if pair[0] not in sections:
                sections[pair[0]] = ET.SubElement(root, "Section", name=pair[0])
            node = nodes.get(pair)
            if node is None:
                node = ET.SubElement(sections[pair[0]], "Key", name=pair[1])
                nodes[pair] = node
                ET.SubElement(node, "Value")
            leaf = next(c for c in node if isinstance(c.tag, str))
            kind = spec["type"]
            leaf.attrib.clear()
            leaf.set(kind, format_fixed(value) if kind == "fixed" else str(int(value)) if kind == "flag" else str(value))
            if kind == "fixed" and spec.get("unit_key"):
                try:self._sync_unit_xp(nodes.get(("Hero", spec["unit_key"])), value)
                except BankError as exc:raise BankError(spec['label']+': '+str(exc)) from exc
                if ("Hero", spec["unit_key"]) in nodes:
                    notes.append(spec["label"]+": synchronized supported saved-unit AHer XP leaves.")
        notes.extend(apply_evolutions(nodes,evolution_selections,evolution_specs))
        from .item_loadouts import apply as apply_item_loadouts
        notes.extend(apply_item_loadouts(root,sections,nodes,self.state.item_loadouts,target.item_loadouts))
        for pair,items in target.unit_items.items():
            if items==self.state.unit_items[pair]:continue
            apply_items(nodes[pair],items,carrier=carrier_for_pair(pair),perk_rank18=target.values[('Perks','PRank18')])
            notes.append('/'.join(pair)+f': updated inventory to {len(items)} items; unit type, XP and other unit leaves preserved.')
        for (hero,loadout),charms in target.charm_loadouts.items():
            if charms==self.state.charm_loadouts[hero,loadout]:continue
            section='OutdatedStats';key=f'H{hero}L{loadout}C';pair=(section,key)
            if section not in sections:sections[section]=ET.SubElement(root,'Section',name=section)
            node=nodes.get(pair)
            if node is None:node=ET.SubElement(sections[section],'Key',name=key);ET.SubElement(node,'Value')
            node.find('Value').attrib={'string':' '.join(map(str,charms))}
            notes.append(f'Hero {hero}: updated charm loadout {loadout}; owned ranks and other loadouts preserved.')
        for hero in set(selections)|evolution_xp_heroes:
            pair=('HeroPatch#',f'H{hero}')
            if pair not in nodes:
                if 'HeroPatch#' not in sections: sections['HeroPatch#']=ET.SubElement(root,'Section',name='HeroPatch#')
                node=ET.SubElement(sections['HeroPatch#'],'Key',name=pair[1])
                ET.SubElement(node,'Value',int='1')
                hero_name=next(h['name'] for h in self.profile['heroes'] if h['id']==hero)
                action=f"selected level {selections[hero]}" if hero in selections else 'selected evolution XP'
                notes.append(f"{hero_name}: marked {action} as current-version XP so the map does not apply its one-time ×0.1 conversion.")
        # gf_AddPassivePoint marks a positive mastery grant separately from
        # the XP migration marker. Preserve the source's level-100 bookkeeping.
        from .dependencies import passive_total
        for hero_info in self.profile['heroes']:
            hero=hero_info['id']; mg=('Asc',f'MG{hero}')
            delta=target.values[mg]-self.state.values[mg]
            rank=target.values[('Perks',f'PRank{95+hero}')]
            marker=('NextUpdateEncryptionKey',f'KeyString{hero}')
            if delta>0 and rank>0 and target.values[mg]==rank//4+1 and passive_total(target,hero)>=passive_total(self.state,hero)+delta and marker not in nodes:
                if marker[0] not in sections:sections[marker[0]]=ET.SubElement(root,'Section',name=marker[0])
                node=ET.SubElement(sections[marker[0]],'Key',name=marker[1]);ET.SubElement(node,'Value',string='')
                notes.append(f"{hero_info['name']}: recorded the positive mastery passive-point grant so the level-100 award is not duplicated.")
        signature.set("value", signature_for(root, self.player, self.author, self.bank_name))
        raw = ET.tostring(root, encoding="utf-8", xml_declaration=True)+b"\n"
        reread = Bank(raw, self.path, self.profile, player=self.player, author=self.author)
        if reread.errors or reread.state != target:
            raise BankError("Rendered bank failed read-back validation: "+"; ".join(reread.errors))
        verify_evolutions(reread,evolution_selections)
        return raw, notes+["Native signature regenerated; original mode filename and unknown fields preserved. XP migration markers change only for explicit hero-level or saved-form evolution selections."]

    @staticmethod
    def _sync_unit_xp(unit_key, value):
        if unit_key is None:
            return
        leaves = {n.tag: n for n in unit_key if isinstance(n.tag, str)}
        if "XPName0" not in leaves or leaves["XPName0"].attrib != {"string": "AHer"} or not {"XP", "XPValue0"}.issubset(leaves):
            raise BankError("This saved unit's XP layout is outside the verified AHer codec; its fallback XP cannot be safely changed.")
        for tag in ("XP", "XPValue0"):
            if set(leaves[tag].attrib) != {"fixed"}:
                raise BankError("Unsupported saved-unit XP type.")
            leaves[tag].set("fixed", format_fixed(value))
