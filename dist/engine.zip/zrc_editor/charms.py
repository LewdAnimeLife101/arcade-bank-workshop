"""Named charm-loadout codec for Reign 0.291.

Ownership is OutdatedStats/Cn; equipment preferences are HnLmC word lists.
Normal loadout1 is selected when spawning a hero. Loadout6 is internal.
"""
import re

from .common import BankError
from .guidance import load_help


def charm_catalog():
    return {int(path.rsplit("C", 1)[1]): item
            for path, item in load_help("charm")["fields"].items()
            if path in {f"OutdatedStats/C{i}" for i in range(1, 8)}}


def read_loadouts(nodes, profile):
    result = {}
    for hero in (h["id"] for h in profile["heroes"]):
        for loadout in range(1, 7):
            pair = ("OutdatedStats", f"H{hero}L{loadout}C")
            key = nodes.get(pair)
            if key is None:
                result[hero, loadout] = (0, 0, 0)
                continue
            leaves = [n for n in key if isinstance(n.tag, str)]
            if len(leaves) != 1 or leaves[0].tag != "Value" or set(leaves[0].attrib) != {"string"}:
                raise BankError(f"Hero {hero} charm loadout {loadout}: unsupported saved value type.")
            words = leaves[0].get("string").split()
            if len(words) < 3 or any(not re.fullmatch(r"[0-9]+", w) or int(w) > 60 for w in words[:3]):
                raise BankError(f"Hero {hero} charm loadout {loadout}: unsupported charm word list; expected three IDs0..60.")
            result[hero, loadout] = tuple(map(int, words[:3]))
    return result


def _mapping(state, profile):
    expected = {(h["id"], loadout) for h in profile["heroes"] for loadout in range(1, 7)}
    result = getattr(state, "charm_loadouts", {})
    if set(result) != expected:
        raise BankError("Incomplete or unexpected charm-loadout state.")
    for pair, slots in result.items():
        if not isinstance(slots, tuple) or len(slots) != 3 or any(type(i) is not int or not 0 <= i <= 60 for i in slots):
            raise BankError(f"Hero {pair[0]} loadout {pair[1]}: expected three integer charm IDs.")
    return result


def validate_loadouts(before, target, profile):
    new = _mapping(target, profile)
    old = _mapping(before, profile) if before is not None else new
    for pair, slots in new.items():
        if slots == old[pair]:
            continue
        hero, loadout = pair
        if loadout == 6:
            raise BankError("Charm loadout6 is an internal reset loadout and is preserved read-only.")
        active = [number for number in slots if number]
        if any(number > 7 for number in active):
            raise BankError("Only the seven named charm types can be newly equipped; reserved IDs remain read-only.")
        if len(set(active)) != len(active):
            raise BankError("A charm can appear only once in each loadout.")
        for position, number in enumerate(slots, 1):
            if not number:
                continue
            if target.values[("OutdatedStats", f"C{number}")] <= 0:
                raise BankError(f"Hero {hero} loadout {loadout}: charm {number} is not owned. Set its rank to at least1 in Progress > Charms first.")
            if position > target.values[("Perks", "PRank57")]:
                raise BankError(f"Charm position {position} requires Charm Slots rank {position}. Use the explicit unlock option or increase that perk first.")
    if before is not None:
        cap = target.values[("Perks", "PRank57")]
        if cap < before.values[("Perks", "PRank57")]:
            for (hero, loadout), slots in new.items():
                if loadout <= 5 and any(slots[cap:]):
                    raise BankError(f"Hero {hero} loadout {loadout} still uses a charm position above the new Charm Slots rank {cap}. Clear those positions first, or retain the unlock rank.")
        for number in range(1, 8):
            key = ("OutdatedStats", f"C{number}")
            if before.values[key] > 0 and target.values[key] == 0 and any(number in slots for slots in new.values()):
                internal = any(loadout == 6 and number in slots for (hero, loadout), slots in new.items())
                note = " The internal reset loadout6 also references it and is preserved read-only; retain the owned rank." if internal else " Remove those references before setting its owned rank to0; the map would otherwise unequip it."
                raise BankError(f"Charm {number} is still referenced by a saved loadout." + note)


def set_loadout(state, hero, loadout, slots, profile, *, unlock_slots=False):
    if type(hero) is not int or hero not in {h["id"] for h in profile["heroes"]}:
        raise BankError("Choose an available hero.")
    if type(loadout) is not int or not 1 <= loadout <= 5:
        raise BankError("Choose a normal loadout from1 to5.")
    if not isinstance(slots, (tuple, list)) or len(slots) != 3 or any(type(i) is not int or not 0 <= i <= 7 for i in slots):
        raise BankError("Choose three named charm entries or Empty.")
    result = state.clone()
    result.charm_loadouts[hero, loadout] = tuple(slots)
    needed = max((i for i, number in enumerate(slots, 1) if number), default=0)
    if unlock_slots is True:
        result.values[("Perks", "PRank57")] = max(result.values[("Perks", "PRank57")], needed)
    validate_loadouts(state, result, profile)
    return result
