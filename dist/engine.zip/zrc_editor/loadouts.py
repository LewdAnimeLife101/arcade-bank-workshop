"""Source-grounded powerful Reign loadouts; not a universal optimal-build claim.

Only pending state is changed. Existing displaced equipment/glyphs are preserved;
an unavailable carrier or full storage is reported instead of losing content.
"""
from dataclasses import dataclass, field

from .common import BankError
from . import glyphs, items

# Class pools from UserData.xml, deliberately selected rather than treating every
# class ability as compatible. Warlock has no class pool in the audited map.
# Four Legendary, two Ancient and up to two Unique powers, in equipped-slot order.
POWERS = {
    1: ((29,34,7,3),(4,2),(6,1)),
    2: ((8,9,10,20),(5,26),(3,1)),
    3: ((4,11,19,23),(3,23),(4,1)),
    4: ((24,27,3,43),(13,18),(10,1)),
    5: ((31,32,3,43),(14,17),(8,1)),
    7: ((3,43,12,21),(2,1),(1,)),
    8: ((33,37,3,43),(20,2),(11,1)),
    9: ((25,26,3,43),(12,21),(7,1)),
    10: ((16,17,22,40),(9,11),(9,1)),
    11: ((1,14,30,36),(6,27),(5,1)),
    12: ((2,15,35,41),(7,8),(2,1)),
}
# Extra class effects complement the glyph powers rather than wasting a slot on
# the same nonstacking special power. Generic items supply mixed offense/defense.
EXTRAS = {1: (),2: ('FallenStar',),3: ('ThunderStone',),4: (),5: (),7: (),
          8: (),9: ('BladeofArrogance',),10: ('KhadgarsCodex',),11: (),12: ()}
BASE_ITEMS = ('sprn','arsh','sbok','woms','frhg','oli2','OrbofArcane','Exca','ckng')
BALANCED_STATS = (1,2,3,4,5,14,16,17,18,19,20,21,23,25,26)
REPEATED_DAMAGE_STATS = (5,)*10 + (16,17,20,21,26)


@dataclass
class Plan:
    before: object
    state: object
    old_levels: dict
    levels: dict
    bank_digest: str
    notes: list
    changed_fields: int
    rendered_bytes: int
    hero_evolutions: dict = field(default_factory=dict)

    def summary(self):
        return '\n'.join(['POWERFUL LOADOUTS — REVIEW PENDING CHANGES',
            f'{self.changed_fields:,} changed fields/inventories · {self.rendered_bytes:,} output bytes',
            '', *self.notes, '',
            'Apply changes only updates this editor. Export copy or Replace current bank saves them.',
            'These are class-themed builds, not proven best-in-slot for every skill setup.',
            'Published-map acceptance and combined combat performance remain untested.'])


def _equip_items(bank,state, hero, notes,evolution_selections,angelic):
    pair=('Hero',hero['unit_key']); name=hero['name']
    if pair not in state.unit_items:
        notes.append(f'{name}: equipment skipped; save this hero in game first (no supported saved inventory).')
        return
    old=state.unit_items[pair]
    opaque_extra={i.slot for i in old if i.container==0 and 6<=i.slot<12
                  and i.unit_id not in items.by_id()}
    occupied_unknown=sum(i.container==0 and 6<=i.slot<12 and i.unit_id not in items.by_id()
                         and i.unit_id!='LockedItemSlot1' for i in old)
    extra_slots=[slot for slot in range(6,12) if slot not in opaque_extra][:max(0,3-occupied_unknown)]
    ordinary_slots=list(range(6))+extra_slots
    desired=list(zip(ordinary_slots,(EXTRAS[hero['id']]+BASE_ITEMS)[:len(ordinary_slots)]))
    desired.append((items.ANGELIC_SLOT,angelic))
    working=list(old); added=moved=blocked=0
    for slot,uid in desired:
        current=next((i for i in working if (i.container,i.slot)==(0,slot)),None)
        if current and current.unit_id==uid:
            continue
        if current and current.unit_id not in items.by_id():
            blocked+=1;continue  # native locks/unknown item never removed
        source=next((i for i in working if i.unit_id==uid and i.container==1),None)
        occupied={i.slot for i in working if i.container==1}
        bag_slot=source.slot if source else next((n for n in range(59) if n not in occupied),None)
        if current and bag_slot is None:
            blocked+=1;continue
        if source:working.remove(source)
        if current:
            working.remove(current);working.append(items.Item(current.unit_id,1,bag_slot));moved+=1
        working.append(items.Item(uid,0,slot));added+=1
    state.unit_items[pair]=items.validate_items(old,working,carrier='hero',perk_rank18=3)
    # Every hero spawn loads form-specific equipment loadout 1. Without this,
    # preserved old equipment in the bag could immediately displace our items.
    from .evolutions import form_for_stage,hero_info
    node=bank.nodes.get(pair)
    unit_type=node.find('Type').get('string') if node is not None and node.find('Type') is not None else None
    selected=evolution_selections.get(hero['id'])
    if selected:unit_type=form_for_stage(hero['id'],selected)['unit_id']
    if unit_type not in {f['unit_id'] for f in hero_info(hero['id'])['forms']}:
        state.unit_items[pair]=old
        notes.append(f'{name}: equipment assignment skipped; saved form is outside the mapped evolution chain.')
        return
    from .item_loadouts import sync_active_loadout
    sync_active_loadout(state,hero['id'],unit_type)
    active=[items.by_id()[i.unit_id]['name'] for i in state.unit_items[pair]
            if i.container==0 and i.unit_id in items.by_id()]
    notes.append(f'{name}: {added} equipment slots assigned; {moved} displaced items retained in the hero bag. Active: '+', '.join(active)+'.')
    if blocked:notes.append(f'{name}: {blocked} active slots kept unchanged because of native locks, unknown items or a full bag. Save this hero after unlocking Active Item Slots in game, then retry.')


def _equip_glyphs(state, profile, hero, notes, repeated):
    hid=hero['id']; tiers=30
    legends,ancients,uniques=POWERS[hid]
    selections={91:(1,legends[:2]),92:(1,legends[2:]),93:(2,ancients),94:(3,uniques)}
    stats=REPEATED_DAMAGE_STATS if repeated else BALANCED_STATS
    amounts=tuple(glyphs.max_value(profile,s,tiers) for s in stats)
    assigned=preserved=blocked=0
    for slot,(quality,powers) in selections.items():
        target=glyphs.fields(glyphs.Glyph(stats,amounts,quality,powers,tiers))
        current=tuple(state.values[p] for p in glyphs.keys(hid,slot))
        if current==target:continue
        source=next((s for s in range(91) if tuple(state.values[p] for p in glyphs.keys(hid,s))==target),None)
        empty=next((s for s in range(91) if not any(state.values[p].strip() for p in glyphs.keys(hid,s))),None)
        # A matching glyph can swap its storage place with the old equipment.
        destination=source if source is not None else empty
        if any(s.strip() for s in current):
            if destination is None:
                blocked+=1;continue
            state.values.update(zip(glyphs.keys(hid,destination),current));preserved+=1
        elif source is not None:
            state.values.update(zip(glyphs.keys(hid,source),('','','','')))
        state.values.update(zip(glyphs.keys(hid,slot),target));assigned+=1
    notes.append(f"{hero['name']}: {assigned} glyph slots assigned; {preserved} old glyphs preserved in storage.")
    if blocked:notes.append(f"{hero['name']}: {blocked} equipped glyphs retained because storage is full.")


def build_plan(bank,before,*,levels=None,hero_evolutions=None,repeated_damage=False,duplicate_stats=None,
               equipment=True,glyph_equipment=True,angelic='XyrrathA'):
    if not bank.original_verified():
        raise BankError('Open a bank with passing original checks before preparing loadouts.')
    if not equipment and not glyph_equipment:
        raise BankError('Select equipment or equipped glyphs.')
    if angelic not in items.ANGELIC_ITEMS:
        raise BankError('Choose Xyrrath or Clarion for the single Angelic equipment slot.')
    state=before.clone(); notes=[]; old_levels=dict(levels or {})
    if duplicate_stats is not None:repeated_damage=bool(duplicate_stats)
    if equipment:
        state.values['Perks','PRank18']=3
        notes.append('Active Item Slots set to rank 3 (9 ordinary slots plus one separate Angelic slot). Existing native lock items are preserved.')
    if glyph_equipment:
        state.values['Perks','PRank21']=30
        notes.append('Glyph Mastery set to 30; four equipped slots, tier 30, up to two different powers and 15 maximum-roll stat lines per glyph.')
        notes.append('Repeated damage mode: each glyph has ten Damage % lines plus time scale, cooldown speed, life %, life regeneration % and energy regeneration. The source sums repeated lines; every line stays within its tier cap. This favors general damage over diverse attributes.' if repeated_damage else 'Balanced glyph stats cover attributes, damage, movement, cooldowns, survival and energy regeneration.')
    for hero in bank.profile['heroes']:
        if equipment:_equip_items(bank,state,hero,notes,hero_evolutions or {},angelic)
        if glyph_equipment:_equip_glyphs(state,bank.profile,hero,notes,repeated_damage)
    if equipment:
        notes.append('Only one Angelic item fits the separate Angelic slot. This preset selects '+items.by_id()[angelic]['name']+' there; existing displaced equipment is retained in the hero bag. Angelic items cannot occupy ordinary active slots. Their main effects have stack limit 1.')
    notes.append('Class powers require the matching skills/forms. This preset does not select skills or remove their inherent tradeoffs; review glyph power descriptions. Warlock has no class-specific pool in this map, so it receives generic powers.')
    kwargs={'hero_levels':old_levels}
    if hero_evolutions:kwargs['hero_evolutions']=dict(hero_evolutions)
    raw,_=bank.render(state,**kwargs)
    changed=sum(v!=before.values[p] for p,v in state.values.items())+sum(v!=before.unit_items[p] for p,v in state.unit_items.items())+sum(v!=before.item_loadouts.get(k) for k,v in state.item_loadouts.items())
    return Plan(before.clone(),state,old_levels,dict(old_levels),bank.digest,notes,changed,len(raw),dict(hero_evolutions or {}))
