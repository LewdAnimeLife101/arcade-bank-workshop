"""Structured Reign 0.291 glyph records and explicit, reversible state edits.

The game stores four primitive strings per hero/slot. Inventory slots are 0..90;
91..94 are the equipped slots. No function in this module writes a file.
"""
from dataclasses import dataclass
from decimal import Decimal, ROUND_FLOOR
from functools import lru_cache
import json
import re

from .common import BankError, resource_path
from zwl_editor.fixed import SCALE, parse_fixed, format_fixed, int_fixed
from mineralz_editor.protection import _multiply, _power

PARTS = ("Type", "Value", "QP", "T")
QUALITIES = {1: "Legendary", 2: "Ancient", 3: "Unique"}
EQUIPPED = {91: (1, 1), 92: (1, 10), 93: (2, 20), 94: (3, 30)}
POWER_COUNTS = {1: 44, 2: 28, 3: 12}


@dataclass(frozen=True)
class Glyph:
    types: tuple[int, ...]
    values: tuple[int, ...]
    quality: int
    powers: tuple[int, ...]
    tier: int


def keys(hero, slot):
    if type(hero) is not int or hero not in (1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12):
        raise BankError("Choose one of the eleven supported heroes.")
    if type(slot) is not int or not 0 <= slot <= 94:
        raise BankError("Glyph slot must be 0 through 94.")
    return tuple(("Glyphs3", f"Hero{hero}GSlot{slot}GStat{part}") for part in PARTS)


def slot_label(slot):
    if slot in EQUIPPED:
        quality, rank = EQUIPPED[slot]
        number = " 1" if slot == 91 else " 2" if slot == 92 else ""
        return f"Equipped {QUALITIES[quality]}{number} · Glyph Mastery {rank}"
    return f"Storage {slot + 1}"


def required_rank(slot):
    return EQUIPPED.get(slot, (0, 1))[1]


def _words(text, maximum):
    tokens = text.split()
    if len(tokens) > maximum or any(not re.fullmatch(r"[+]?[0-9]+(?:\.[0-9]*)?", s) for s in tokens):
        raise BankError("Glyph data must contain nonnegative decimal words.")
    return tuple(parse_fixed(s) for s in tokens)


def _ints(values, label):
    if any(v % SCALE for v in values):
        raise BankError(label + " must contain whole numbers.")
    return tuple(v // SCALE for v in values)


def decode_power(encoded, quality):
    if type(quality) is not int or quality not in POWER_COUNTS:
        raise BankError("Glyph quality must be Legendary, Ancient or Unique.")
    if type(encoded) is not int or encoded < 0:
        raise BankError("Glyph power must be a nonnegative whole number.")
    powers = (encoded,) if encoded < 100 else divmod(encoded, 100)
    if not 1 <= len(powers) <= 2 or any(not 2 <= n <= POWER_COUNTS[quality] + 1 for n in powers):
        raise BankError("Glyph power is outside the mapped item catalog.")
    # Stored values are item-array indices + 1; the equip function subtracts 1.
    result = tuple(n - 1 for n in powers)
    if len(set(result)) != len(result):
        raise BankError("The two glyph powers must be different.")
    return result


def encode_power(powers, quality):
    powers = tuple(powers)
    if type(quality) is not int or quality not in POWER_COUNTS or not 1 <= len(powers) <= 2 or any(
        type(p) is not int or not 1 <= p <= POWER_COUNTS[quality] for p in powers
    ) or len(set(powers)) != len(powers):
        raise BankError("Choose one or two different powers from this quality's catalog.")
    stored = tuple(p + 1 for p in powers)
    return stored[0] if len(stored) == 1 else stored[0] * 100 + stored[1]


def record(state, hero, slot):
    text = tuple(state.values[pair] for pair in keys(hero, slot))
    if not any(part.strip() for part in text):
        return None
    types, values, qp, tier = (_words(t, n) for t, n in zip(text, (15, 15, 2, 1)))
    if len(types) != len(values) or len(qp) != 2 or len(tier) != 1:
        raise BankError("A glyph requires paired stat lists, two quality/power words and one tier word.")
    quality, power = _ints(qp, "Glyph quality/power")
    return Glyph(_ints(types, "Glyph stat IDs"), values, quality, decode_power(power, quality),
                 _ints(tier, "Glyph tier")[0])


def fields(glyph):
    if glyph is None:
        return ("", "", "", "")
    return (" ".join(map(str, glyph.types)), " ".join(format_fixed(v) for v in glyph.values),
            f"{glyph.quality} {encode_power(glyph.powers, glyph.quality)}", str(glyph.tier))


def max_value(profile, stat, tier):
    """Conservative one-decimal upper value in the source's high-roll envelope."""
    if type(stat) is not int or not 1 <= stat <= 27 or type(tier) is not int or not 0 <= tier <= 524287:
        raise BankError("Choose a mapped glyph stat and a supported tier.")
    base = parse_fixed(profile["glyph_stat_ranges"][stat - 1])
    ceiling = _multiply(_multiply(base, parse_fixed("1.77")),
                        _power(parse_fixed("1.085"), int_fixed(min(tier - 1, 40))))
    decimal = (Decimal(ceiling) / SCALE).quantize(Decimal("0.1"), rounding=ROUND_FLOOR)
    raw = parse_fixed(str(decimal))
    # Rounding a decimal tenth to fixed can put it a fraction above the ceiling.
    return raw if raw <= ceiling else parse_fixed(str(decimal - Decimal("0.1")))


def _check(glyph, profile, *, newly_created=False, previous=None):
    if glyph is None:
        return
    encode_power(glyph.powers, glyph.quality)
    new_tier = newly_created or previous is None or glyph.tier != previous.tier
    if type(glyph.tier) is not int or not (1 <= glyph.tier <= 30 if new_tier else 0 <= glyph.tier <= 524287):
        raise BankError("New glyph tiers are limited to the verified crafting menu, 1–30.")
    if len(glyph.types) != len(glyph.values) or len(glyph.types) > 15:
        raise BankError("A glyph supports at most 15 paired stat lines.")
    for index, (stat, amount) in enumerate(zip(glyph.types, glyph.values)):
        if type(stat) is not int or not 1 <= stat <= 27:
            raise BankError("Only the 27 implemented glyph stats can be newly assigned.")
        unchanged = previous is not None and glyph.tier == previous.tier and index < len(previous.types) and (
            stat, amount) == (previous.types[index], previous.values[index])
        if type(amount) is not int or amount < 0:
            raise BankError("Glyph stat values must be nonnegative fixed numbers.")
        if not unchanged and not parse_fixed("0.1") <= amount <= max_value(profile, stat, glyph.tier):
            raise BankError(f"Glyph stat {stat}: enter at least 0.1 and no more than {format_fixed(max_value(profile, stat, glyph.tier))} for tier {glyph.tier}.")


def _put(state, hero, slot, glyph):
    state.values.update(zip(keys(hero, slot), fields(glyph)))


def create_glyph(state, profile, hero, slot, *, quality, tier, powers, stats, unlock=False):
    """Create in an empty storage slot; explicit unlock raises Glyph Mastery to 1."""
    keys(hero, slot)
    if slot > 90:
        raise BankError("Create a glyph in storage, then equip it explicitly.")
    if record(state, hero, slot) is not None:
        raise BankError("The chosen glyph storage slot is occupied.")
    rows = tuple(stats)
    glyph = Glyph(tuple(s for s, _ in rows), tuple(v for _, v in rows), quality, tuple(powers), tier)
    _check(glyph, profile, newly_created=True)
    result = state.clone()
    rank = result.values[("Perks", "PRank21")]
    if rank < 1 and not unlock:
        raise BankError("Creating glyphs requires Glyph Mastery rank 1. Enable the explicit mastery adjustment.")
    if unlock:
        result.values[("Perks", "PRank21")] = max(rank, 1)
    _put(result, hero, slot, glyph)
    return result


def update_glyph(state, profile, hero, slot, *, quality, tier, powers, stats):
    previous = record(state, hero, slot)
    if previous is None:
        raise BankError("Choose an existing glyph to update.")
    rows = tuple(stats)
    glyph = Glyph(tuple(s for s, _ in rows), tuple(v for _, v in rows), quality, tuple(powers), tier)
    _check(glyph, profile, previous=previous)
    result = state.clone()
    _put(result, hero, slot, glyph)
    validate_changes(state, result, profile)
    return result


def equip_glyph(state, profile, hero, storage_slot, equipped_slot, *, unlock=False):
    """Swap all four strings, preserving the old equipped glyph in storage."""
    keys(hero, storage_slot)
    if storage_slot > 90 or equipped_slot not in EQUIPPED:
        raise BankError("Choose a storage glyph and one of the four equipped slots.")
    source = record(state, hero, storage_slot)
    if source is None:
        raise BankError("The selected storage slot is empty.")
    quality, rank = EQUIPPED[equipped_slot]
    if source.quality != quality:
        raise BankError(f"This slot only accepts {QUALITIES[quality]} glyphs.")
    result = state.clone()
    current_rank = result.values[("Perks", "PRank21")]
    if current_rank < rank and not unlock:
        raise BankError(f"This equipped slot requires Glyph Mastery rank {rank}.")
    if unlock:
        result.values[("Perks", "PRank21")] = max(rank, current_rank)
    # Preserve lexical metadata on moves, matching the game's 33-value swap.
    a, b = keys(hero, storage_slot), keys(hero, equipped_slot)
    for left, right in zip(a, b):
        result.values[left], result.values[right] = state.values[right], state.values[left]
    validate_changes(state, result, profile)
    return result


def unequip_glyph(state, profile, hero, equipped_slot, storage_slot):
    if equipped_slot not in EQUIPPED or storage_slot > 90:
        raise BankError("Choose an equipped glyph and an empty storage slot.")
    if record(state, hero, storage_slot) is not None:
        raise BankError("Unequipping requires an empty storage slot.")
    result = state.clone()
    for left, right in zip(keys(hero, storage_slot), keys(hero, equipped_slot)):
        result.values[left], result.values[right] = state.values[right], state.values[left]
    validate_changes(state, result, profile)
    return result


def validate_changes(before, target, profile):
    """Validate changed whole records and prevent lowering an occupied slot's gate.

    Legacy untouched tuples remain opaque. Moving a tuple preserves every string
    and its original small/over-tier roll; only newly assigned stats gain bounds.
    """
    heroes = [h["id"] for h in profile["heroes"]]
    rank_changed = target.values[("Perks", "PRank21")] != before.values[("Perks", "PRank21")]
    old_records = {}
    for hero in heroes:
        old_records[hero] = [tuple(before.values[p] for p in keys(hero, s)) for s in range(95)]
    for hero in heroes:
        for slot in range(95):
            pair_keys = keys(hero, slot)
            old = tuple(before.values[p] for p in pair_keys)
            new = tuple(target.values[p] for p in pair_keys)
            changed = old != new
            if not changed and not (rank_changed and slot in EQUIPPED and any(v.strip() for v in new)):
                continue
            glyph = record(target, hero, slot)
            if changed:
                moved = new in old_records[hero]
                previous = record(before, hero, slot) if any(v.strip() for v in old) else None
                if moved:
                    # Known complete tuples can move without changing their rolls.
                    _check(glyph, profile, previous=glyph)
                else:
                    _check(glyph, profile, newly_created=previous is None, previous=previous)
            if glyph is not None and slot in EQUIPPED:
                quality, rank = EQUIPPED[slot]
                if glyph.quality != quality:
                    raise BankError(f"Equipped slot {slot} only accepts {QUALITIES[quality]} glyphs.")
                if target.values[("Perks", "PRank21")] < rank:
                    raise BankError(f"Equipped glyph slot {slot} requires Glyph Mastery rank {rank}; unequip it before lowering the perk.")


@lru_cache(maxsize=1)
def power_catalog():
    return json.loads(resource_path("data/glyph_powers.json").read_text(encoding="utf-8"))
