"""Conservative, reviewable historical-counter consistency for Reign 0.291.

This is arithmetic reconciliation, not evidence that progress was earned.
MapScript.galaxy: 33314-33323/33342 (playtime), 30173-30177 (deaths),
6160-6219 (shop clears), 19657-19702/22058-22103 (solo records).
"""
from dataclasses import dataclass

from .common import BankError
from .dependencies import effective_ordinary_record


@dataclass(frozen=True)
class Change:
    pair: tuple[str, str]
    label: str
    before: int
    after: int
    reason: str


@dataclass
class Plan:
    before: object
    state: object
    old_levels: dict
    levels: dict
    old_evolutions: dict
    hero_evolutions: dict
    bank_digest: str
    changes: tuple[Change, ...]
    notes: list[str]
    rendered_bytes: int

    @property
    def changed_fields(self):
        return len(self.changes)

    def summary(self):
        lines = [
            'STATISTICS CONSISTENCY — REVIEW PENDING CHANGES',
            f'{len(self.changes)} aggregate counters adjusted; {self.rendered_bytes:,} output bytes.',
            'This reconciles stored counters. It cannot establish that edited progress was earned.',
            '',
        ]
        for change in self.changes:
            lines.append(f'{change.label}: {change.before:,} → {change.after:,}. {change.reason}')
        if not self.changes:
            lines.append('No aggregate-counter changes are needed.')
        return '\n'.join(lines + ['', *self.notes, '',
            'Apply changes pending edits only. Export copy or Replace current bank is a separate action.',
            'Published-map acceptance has not been tested.'])


def build_plan(bank, before, *, levels=None, hero_evolutions=None):
    """Raise deficient global counters without fabricating per-hero history.

    Global totals may exceed retained hero totals (legacy data, missing records,
    or global playtime while dead). Preserve that excess; never apportion it to
    heroes. Include reserved hero 6 in sums but never edit its records. Shop 10
    has no matched increment branch in this snapshot and is preserved.
    """
    if not bank.original_verified():
        raise BankError('Open a supported bank with passing original checks before reconciling statistics.')
    state = before.clone()
    definitions = {(f['section'], f['key']): f for f in bank.profile['fields']}
    changes = []
    notes = []

    def aggregate(global_key, hero_keys, description):
        pair = ('GameTS', global_key)
        total = sum(state.values['GameTS', key] for key in hero_keys)
        if total > definitions[pair]['max']:
            raise BankError(f"{definitions[pair]['label']}: summed hero counters exceed supported integer storage. Reduce the entered hero counters before reconciling.")
        old = state.values[pair]
        if old < total:
            state.values[pair] = total
            changes.append(Change(pair, definitions[pair]['label'], old, total, description))

    hero_ids = range(1, 13)
    aggregate('TP0', [f'TP{h}' for h in hero_ids],
              'Global game seconds must cover the sum of retained hero game seconds.')
    aggregate('DH0', [f'DH{h}' for h in hero_ids],
              'Global deaths must cover the sum of retained hero deaths.')
    for shop in range(1, 10):
        aggregate(f'H0S{shop}', [f'H{h}S{shop}' for h in hero_ids],
                  f'Global shop {shop} clears must cover retained hero clear counters.')

    notes.append('Global totals that already exceed hero totals are retained. Hero histories, kills, waves, currencies, XP, unlocks and completion times are unchanged. Shop 10 is preserved because no matching writer branch was found.')
    notes.append('Playtime is game seconds. The current writer adds 20 each tick; hero time advances only while that hero is alive. Existing non-multiples of 20 are preserved because earlier versions or edited history cannot be reconstructed.')
    notes.append('129 hours is 464,400 seconds. There is no verified formula relating playtime or total kills to XP, mastery, equipment or other progression; this preset does not manufacture that history.')

    # These relationships are useful warnings, but changing them would choose
    # which historical run to trust or affect progression/reward multipliers.
    # Leave those decisions to the user rather than inventing completed runs.
    for prefix, best_time, fastest, global_record, name in (
        ('BS', 'BST', 'FST', effective_ordinary_record(state), 'ordinary'),
        ('KBS', 'KBST', 'KFST', state.values['Diseases', 'KPlague'], 'Kalimdor'),
    ):
        highest = max(state.values['GameTS', f'{prefix}{h}'] for h in hero_ids)
        if highest > global_record:
            notes.append(f'REVIEW: a hero has {name} solo record {highest}, above the loaded global record {global_record}. Records were retained; reconciling them can alter gameplay rewards and needs an explicit choice.')
        for hero in range(13):
            record = global_record if hero == 0 else state.values['GameTS', f'{prefix}{hero}']
            bt = state.values['GameTS', f'{best_time}{hero}']
            ft = state.values['GameTS', f'{fastest}{hero}']
            if bt and ft and ft > bt:
                notes.append(f'REVIEW: {name} row {hero} fastest time ({ft:,}s) exceeds its best-level time ({bt:,}s). Both recorded times were retained.')
            if record == 0 and (bt or ft):
                notes.append(f'REVIEW: {name} row {hero} has a recorded completion time but no level record. Retained because the original run cannot be inferred.')
        known = [state.values['GameTS', f'{fastest}{h}'] for h in hero_ids
                 if state.values['GameTS', f'{fastest}{h}'] > 0]
        global_fastest = state.values['GameTS', f'{fastest}0']
        if known and (global_fastest == 0 or global_fastest > min(known)):
            notes.append(f'REVIEW: the global {name} fastest time is absent or slower than a retained hero time. Both were retained; the preset does not choose which historical run is authentic.')
    old_levels = dict(levels or {})
    old_evolutions = dict(hero_evolutions or {})
    options = {'hero_levels': old_levels}
    if hero_evolutions is not None:
        options['hero_evolutions'] = old_evolutions
    raw, _ = bank.render(state, **options)
    return Plan(before.clone(), state, old_levels, dict(old_levels),
                old_evolutions, dict(old_evolutions), bank.digest,
                tuple(changes), notes, len(raw))
