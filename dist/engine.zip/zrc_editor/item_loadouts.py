"""Reign's form-specific first equipment loadout, independently of skill ranks."""
import re
import xml.etree.ElementTree as ET
from .common import BankError
from .evolutions import catalog
from .items import by_id, ANGELIC_ITEMS, ANGELIC_SLOT


def supported(key):
    match=re.fullmatch(r'(.+)Loadout1Item#([1-9]|1[0-7])',key)
    return bool(match and match[1] in {f['unit_id'] for h in catalog()['heroes'] for f in h['forms']})


def read(nodes):
    return {key:node.find('Value').get('string') for (sec,key),node in nodes.items()
            if sec=='HeroItemLoadouts' and supported(key) and len(node)==1
            and node[0].tag=='Value' and set(node[0].attrib)=={'string'}}


def sync_active_loadout(target,hero,unit_type):
    """Keep this hero's supported active gear selected after a form load."""
    from .evolutions import hero_info
    info=hero_info(hero)
    if unit_type not in {f['unit_id'] for f in info['forms']}:
        raise BankError('Equipment loadout form does not belong to this hero.')
    pair='Hero',info['unit_key']
    if pair not in target.unit_items:return
    active={i.slot:i.unit_id for i in target.unit_items[pair] if i.container==0}
    for slot in range(17):
        # Native save-loadout writer uses None for empty slots (23186). This
        # also suppresses a stale bag-item swap into an opaque/locked position
        # without moving or deleting the actual unknown item.
        uid=active.get(slot)
        target.item_loadouts[f'{unit_type}Loadout1Item#{slot+1}']=uid if uid in by_id() else 'None'


def validate(before,target):
    if not isinstance(target,dict) or any(not isinstance(k,str) or not supported(k) or not isinstance(v,str) for k,v in target.items()):
        raise BankError('Unsupported first equipment loadout record.')
    if before is None:return
    if not set(before)<=set(target):
        raise BankError('Existing equipment loadout records must be preserved.')
    for key,value in target.items():
        if value==before.get(key):continue
        if value not in by_id() and value not in ('None','LockedItemSlot1'):
            raise BankError('New equipment loadout choices must be supported items.')
        slot=int(key.rsplit('#',1)[1])-1
        if 12 <= slot < ANGELIC_SLOT and value != 'None':
            raise BankError('Unused inventory grid positions must remain empty in equipment loadouts.')
        if value in by_id() and ((value in ANGELIC_ITEMS) != (slot == ANGELIC_SLOT)):
            raise BankError('Equipment loadout items must match the ordinary or Angelic slot class.')


def apply(root,sections,nodes,before,target):
    count=0
    for key,value in target.items():
        if before.get(key)==value:continue
        pair='HeroItemLoadouts',key
        node=nodes.get(pair)
        if node is not None and (len(node)!=1 or node[0].tag!='Value' or set(node[0].attrib)!={'string'}):
            raise BankError('An existing equipment loadout has unsupported metadata; preserve it unchanged.')
        if pair[0] not in sections:sections[pair[0]]=ET.SubElement(root,'Section',name=pair[0])
        if node is None:
            node=ET.SubElement(sections[pair[0]],'Key',name=key);ET.SubElement(node,'Value');nodes[pair]=node
        node[0].attrib={'string':value};count+=1
    return [f'Synchronized {count} form-specific first equipment loadout choices; skill loadouts retained.'] if count else []
