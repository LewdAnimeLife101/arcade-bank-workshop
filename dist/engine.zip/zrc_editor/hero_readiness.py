"""Expose missing saved heroes and partial equipment plans before applying."""
from .evolutions import catalog, current_stage
from .items import by_id


def report(bank,state=None,*,evolutions=None):
    if bank is None or bank.state is None:
        return 'Open a supported bank to inspect saved heroes.'
    state=bank.state if state is None else state
    evolutions=evolutions or {}
    rows=[];saved=0;readable=0
    for hero in catalog()['heroes']:
        name=hero['name'];hid=hero['id'];pair=('Hero',hero['unit_key'])
        if pair not in bank.nodes:
            rows.append(f'{name}: NOT SAVED — evolution unlock and glyphs can be edited, but form/equipment require playing and saving this hero once.')
            continue
        saved+=1
        stage=current_stage(bank,hid)
        form=f"saved form {stage} ({hero['forms'][stage-1]['label']})" if stage is not None else 'unmapped saved form'
        if evolutions.get(hid):
            selected=evolutions[hid]
            form+=f" → selected form {selected} ({hero['forms'][selected-1]['label']})"
        if pair not in state.unit_items:
            rows.append(f'{name}: {form}; UNSUPPORTED inventory layout — equipment is skipped, not equipped.')
            continue
        readable+=1
        inventory=state.unit_items[pair]
        active=sum(i.container==0 and i.unit_id in by_id() for i in inventory)
        bag=sum(i.container==1 and i.unit_id in by_id() for i in inventory)
        locks=sum(i.container==0 and i.unit_id.startswith('LockedItemSlot') for i in inventory)
        rows.append(f'{name}: {form}; {active} active equipment, {bag} bag equipment, {locks} saved locks.')
    return '\n'.join([f'HERO COVERAGE: {saved}/11 saved heroes; {readable}/11 readable inventories.',
        'Missing heroes are not created by these presets. Coverage below 11 means form/equipment changes are partial.',
        *rows])
