"""Reign 0.291 flat unit inventories, checked with a separate native test map.

Coordinates are the zero-based values stored in SC2 banks. Native Galaxy inventory
functions use one-based coordinates. Native ItemCount may include null entries:
ItemN leaves can be sparse. Only item leaves are changed by this module.
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
import json
import re
import xml.etree.ElementTree as ET

from .common import BankError, resource_path

STASH_PAIR = ("Stashes", "StashBox1")
STASH_CAPACITIES = (64, 64, 59, 64)
HERO_CAPACITIES = (17, 59, 4)
# 6SlotBag uses grid coordinates: ordinary slots0..11, empty row3 (12..15),
# Angelic at row4 column0 => bank slot16 / native slot17. Native v3 probe
# establishes the index; declared Slots element count is not the slot address.
ANGELIC_ITEMS = frozenset(('XyrrathA', 'Clarion'))
ANGELIC_SLOT = 16
_ID = re.compile(r"[A-Za-z0-9_@.-]+\Z")
_LEAF = re.compile(r"Item(0|[1-9][0-9]*)\Z")
_HERO_KEYS = frozenset(("FootmanA", "RiflemanA", "GruntA", "PriestA",
    "RaiderA", "SorceressA", "ShadeA", "HunterA", "BloodElfA", "DruidA", "WarlockA"))


@dataclass(frozen=True, order=True)
class Item:
    unit_id: str
    container: int
    slot: int


@lru_cache(maxsize=1)
def catalog():
    return json.loads(resource_path("data/items.json").read_text(encoding="utf-8"))


@lru_cache(maxsize=1)
def by_id():
    return {entry["unit_id"]: entry for entry in catalog()["items"]}


def carrier_for_pair(pair):
    if pair == STASH_PAIR:
        return "stash"
    if pair[0] == "Hero" and pair[1] in _HERO_KEYS:
        return "hero"
    return None


def _ordered(items):
    return tuple(sorted(items, key=lambda i: (i.container, i.slot, i.unit_id)))


def read_items(key):
    """Read a supported existing native unit; raise for unknown item metadata.

    Missing ItemCount means an empty inventory. Sparse ItemN indexes are native
    output, not missing items. Trailing ItemN leaves from older, larger native
    saves are outside ItemCount and ignored. No-op writes preserve those leaves.
    Unknown non-item unit leaves remain opaque.
    """
    type_leaf = key.find("Type")
    if type_leaf is None or set(type_leaf.attrib) != {"string"}:
        raise BankError("Inventory has no supported saved unit type.")
    if key.get("name") == STASH_PAIR[1] and type_leaf.get("string") != "ShapeTreasureChestClosed":
        raise BankError("Stash unit type is outside the verified inventory format.")
    item_leaves = [leaf for leaf in key if isinstance(leaf.tag, str) and leaf.tag.startswith("Item")]
    counts = [leaf for leaf in item_leaves if leaf.tag == "ItemCount"]
    if not item_leaves:
        return ()
    if len(counts) != 1 or set(counts[0].attrib) != {"int"}:
        raise BankError("Inventory has unsupported item count metadata.")
    text = counts[0].get("int", "")
    if not re.fullmatch(r"0|[1-9][0-9]*", text) or int(text) > 10000:
        raise BankError("Inventory item count is outside the supported range.")
    count = int(text)
    found, indexes = [], set()
    for leaf in item_leaves:
        if leaf.tag == "ItemCount":
            continue
        match = _LEAF.fullmatch(leaf.tag)
        if not match or set(leaf.attrib) != {"string"}:
            raise BankError("Inventory has unknown item metadata; preserve it unchanged.")
        index = int(match[1])
        if index in indexes:
            raise BankError("Inventory item index does not match its native count.")
        indexes.add(index)
        if index >= count:
            continue
        words = leaf.get("string", "").split(",")
        if len(words) != 3 or not _ID.fullmatch(words[0]) or any(not re.fullmatch(r"0|[1-9][0-9]*", w) for w in words[1:]):
            raise BankError("Inventory has an unsupported item record.")
        found.append(Item(words[0], int(words[1]), int(words[2])))
    return _ordered(found)


def validate_items(before, after, *, carrier="stash", perk_rank18=0):
    """Validate logical items without replaying purchases or changing hero units.

    Existing unlisted items are preserved exactly; new items must be in the
    source-confirmed equipment drop pools. Hero glyph and lock placeholders are
    protected. The public UI currently edits only the softcore stash.
    """
    if carrier not in ("stash", "hero"):
        raise BankError("Unsupported inventory carrier.")
    capacities = STASH_CAPACITIES if carrier == "stash" else HERO_CAPACITIES
    before, after = tuple(before), tuple(after)
    occupied = set()
    for item in after:
        if not isinstance(item, Item) or not isinstance(item.unit_id, str) or not _ID.fullmatch(item.unit_id):
            raise BankError("Unsupported inventory item identity.")
        if type(item.container) is not int or type(item.slot) is not int or not 0 <= item.container < len(capacities) or not 0 <= item.slot < capacities[item.container]:
            raise BankError("Inventory item is outside this tab's slot limit.")
        position = (item.container, item.slot)
        if position in occupied:
            raise BankError("Two inventory items occupy the same tab and slot.")
        occupied.add(position)
        if item not in before and item.unit_id not in by_id():
            raise BankError("New inventory items must come from the supported equipment list.")
    for item in before:
        if item.unit_id not in by_id() and item not in after:
            raise BankError("Unmapped items and native placeholders must stay unchanged.")
    if carrier == "hero":
        if any(item.container == 2 and item not in before for item in after):
            raise BankError("Hero glyph carrier slots are controlled by the glyph system.")
        if type(perk_rank18) is not int or not 0 <= perk_rank18 <= 3:
            raise BankError("Active Item Slots rank must be between 0 and 3.")
        for item in after:
            if item.container != 0 or item in before:
                continue
            if 12 <= item.slot < ANGELIC_SLOT:
                raise BankError('This active inventory position is an unused grid slot.')
            if (item.unit_id in ANGELIC_ITEMS) != (item.slot == ANGELIC_SLOT):
                raise BankError('Angelic equipment requires its separate Angelic slot; ordinary equipment cannot use that slot.')
        # Native lock items can occupy any of positions6..11. Rank controls how
        # many ordinary items fit in that six-position region, not a prefix of
        # slot indexes. For example locks6..8 leave usable positions9..11.
        extra = [item for item in after if item.container == 0 and 6 <= item.slot < 12
                 and item.unit_id != 'LockedItemSlot1']
        if len(extra) > perk_rank18 and any(item not in before for item in extra):
            raise BankError("Unlock enough Active Item Slots before adding equipment there.")
    return _ordered(after)


def apply_items(key, items, *, carrier="stash", perk_rank18=0):
    """Change only ItemCount/ItemN on an existing unit, preserving all other leaves."""
    before = read_items(key)
    items = validate_items(before, items, carrier=carrier, perk_rank18=perk_rank18)
    if items == before:
        return
    for leaf in list(key):
        if isinstance(leaf.tag, str) and (leaf.tag == "ItemCount" or _LEAF.fullmatch(leaf.tag)):
            key.remove(leaf)
    if items:
        ET.SubElement(key, "ItemCount", int=str(len(items)))
        for index, item in enumerate(items):
            ET.SubElement(key, f"Item{index}", string=f"{item.unit_id},{item.container},{item.slot}")


def first_free(items, container):
    if type(container) is not int or not 0 <= container < len(STASH_CAPACITIES):
        raise BankError("Choose one of the four stash tabs.")
    occupied = {item.slot for item in items if item.container == container}
    return next((slot for slot in range(STASH_CAPACITIES[container]) if slot not in occupied), None)


def item_label(item_or_id):
    unit_id = item_or_id.unit_id if isinstance(item_or_id, Item) else item_or_id
    entry = by_id().get(unit_id)
    return f"{entry['name']} · {entry['quality']} [{unit_id}]" if entry else f"Preserved item [{unit_id}]"
