"""Reign of Chaos0.291 bank codec; no game control or live-save mutation."""
