"""Named browser glyph controls over the verified 0.291 codec.

All actions update pending state only. Unknown records remain opaque and no
function reads or writes a player's bank file.
"""
from functools import lru_cache
import json

from . import glyphs
from .common import BankError, fixed_input, resource_path
from zwl_editor.fixed import format_fixed


@lru_cache(maxsize=1)
def _help():
    return json.loads(resource_path("data/glyph_help.json").read_text(encoding="utf-8"))


def _integer(request, key):
    value = request.get(key)
    if type(value) is not int:
        raise BankError(f"Glyph {key} must be a whole number.")
    return value


def _supported(state, profile, hero, slot):
    value = glyphs.record(state, hero, slot)
    if value is not None:
        glyphs._check(value, profile, previous=value)
        if slot in glyphs.EQUIPPED and value.quality != glyphs.EQUIPPED[slot][0]:
            raise BankError("The saved glyph quality does not match this equipped slot; preserved read-only.")
    return value


def describe(bank, state):
    """JSON-safe catalogs, actual rarity, per-hero storage and equipped slots."""
    profile = bank.profile
    qualities = glyphs.power_catalog()["qualities"]
    powers = {(q["id"], p["id"]): p for q in qualities for p in q["powers"]}
    stat_help = {s["id"]: s for s in _help()["stats"] if 1 <= s["id"] <= 27}
    stats = []
    for stat in stat_help.values():
        stats.append({"id": stat["id"], "label": stat["label"],
                      "description": stat["description"], "unit": stat["unit"], "min": "0.1",
                      "maxByTier": {str(t): format_fixed(glyphs.max_value(profile, stat["id"], t)) for t in range(1, 31)}})
    heroes = []
    mastery = state.values[("Perks", "PRank21")]
    for hero in profile["heroes"]:
        slots = []
        for slot in range(95):
            entry = {"slot": slot, "label": glyphs.slot_label(slot),
                     "location": "equipped" if slot in glyphs.EQUIPPED else "storage",
                     "requiredMastery": glyphs.required_rank(slot), "editable": True,
                     "locked": mastery < glyphs.required_rank(slot),
                     "acceptsQuality": glyphs.EQUIPPED[slot][0] if slot in glyphs.EQUIPPED else None}
            try:
                value = _supported(state, profile, hero["id"], slot)
                entry["empty"] = value is None
                if value is not None:
                    entry.update({"quality": value.quality, "qualityLabel": glyphs.QUALITIES[value.quality],
                                  "tier": value.tier, "powers": [powers[value.quality, p] for p in value.powers],
                                  "name": " + ".join(powers[value.quality, p]["name"] for p in value.powers),
                                  "stats": [{"id": s, "label": stat_help[s]["label"],
                                             "description": stat_help[s]["description"], "unit": stat_help[s]["unit"],
                                             "value": format_fixed(v), "min": "0.1",
                                             "max": format_fixed(glyphs.max_value(profile, s, value.tier))}
                                            for s, v in zip(value.types, value.values)],
                                  "legacyTier": not 1 <= value.tier <= 30})
            except (BankError, KeyError, ValueError) as exc:
                entry.update({"empty": False, "editable": False, "name": "Unrecognized saved glyph",
                              "error": str(exc), "description": "Kept unchanged. This record cannot be safely edited with the verified catalog."})
            slots.append(entry)
        heroes.append({"id": hero["id"], "label": hero.get("name", str(hero["id"])).replace("BloodElf","Blood Elf"), "slots": slots})
    return {"mastery": mastery, "qualities": qualities, "stats": stats, "heroes": heroes,
            "tierMin": 1, "tierMax": 30, "maxStatLines": 15, "maxPowers": 2,
            "storageHelp": "Added glyphs go to the selected hero's glyph storage, not the equipment stash. Storage alone grants no bonus.",
            "equipHelp": "Equip a stored glyph into a matching rarity slot to activate it for that hero. An existing equipped glyph swaps into the selected storage slot. Glyph Crafting Power requirements are 1, 10, 20 and 30.",
            "saveHelp": "These are pending bank edits. Export or replace the correct mode's bank, then load that hero in a new match. No live-game inventory is changed here.",
            "powerHelp": "Names identify the item-derived powers carried by a glyph; its saved rarity is separate. One or two different powers may be selected from the same rarity. Some effects depend on the hero's abilities or current stats.",
            "limitsHelp": "New tiers use the verified crafting range 1–30. Each new stat line uses its tier's roll ceiling. Up to 15 stored lines is the codec capacity, not a claim that ordinary drops roll 15 lines. Untouched legacy rolls are preserved."}


def apply(bank, state, request):
    """Apply a single explicit operation atomically to pending state; return notes.

    Requests: action, hero, slot; toSlot for equip/unequip/move; quality, tier,
    powers=[int], stats=[{id:int,value:decimal-string}] for create/edit.
    unlockMastery must be explicit boolean true to raise a dependency.
    """
    if not isinstance(request, dict):
        raise BankError("Choose a glyph action.")
    action = request.get("action")
    if action not in {"create", "edit", "equip", "unequip", "move", "remove"}:
        raise BankError("Unknown glyph action.")
    hero, slot = _integer(request, "hero"), _integer(request, "slot")
    glyphs.keys(hero, slot)
    unlock = request.get("unlockMastery", False)
    if type(unlock) is not bool:
        raise BankError("Glyph Crafting Power adjustment must be an explicit checkbox choice.")
    before = state.clone()
    current = _supported(before, bank.profile, hero, slot)
    if action != "create" and current is None:
        raise BankError("Choose a nonempty glyph slot.")
    if action in {"create", "edit"}:
        quality, tier = _integer(request, "quality"), _integer(request, "tier")
        powers, rows = request.get("powers"), request.get("stats")
        if not isinstance(powers, list) or not isinstance(rows, list) or len(rows) > 15:
            raise BankError("Choose powers and at most 15 named stat lines.")
        stats = []
        for row in rows:
            if not isinstance(row, dict) or type(row.get("id")) is not int or isinstance(row.get("value"), bool):
                raise BankError("Each glyph stat needs a named type and numeric value.")
            stats.append((row["id"], fixed_input(row.get("value", ""), "Glyph stat value")))
        args = dict(quality=quality, tier=tier, powers=powers, stats=stats)
        if action == "create":
            result = glyphs.create_glyph(before, bank.profile, hero, slot, **args, unlock=unlock)
        else:
            result = glyphs.update_glyph(before, bank.profile, hero, slot, **args)
    elif action in {"equip", "unequip", "move"}:
        destination = _integer(request, "toSlot")
        glyphs.keys(hero, destination)
        _supported(before, bank.profile, hero, destination)
        if action == "equip":
            result = glyphs.equip_glyph(before, bank.profile, hero, slot, destination, unlock=unlock)
        elif action == "unequip":
            result = glyphs.unequip_glyph(before, bank.profile, hero, slot, destination)
        else:
            if slot > 90 or destination > 90 or slot == destination:
                raise BankError("Move requires two different storage slots for the same hero.")
            if glyphs.record(before, hero, destination) is not None:
                raise BankError("The destination storage slot must be empty.")
            result = before.clone()
            for a, b in zip(glyphs.keys(hero, slot), glyphs.keys(hero, destination)):
                result.values[a], result.values[b] = before.values[b], before.values[a]
    else:
        result = before.clone()
        for key in glyphs.keys(hero, slot):
            result.values[key] = ""
    glyphs.validate_changes(before, result, bank.profile)
    notes = [f"Glyph {action} prepared for {next(h['name'] for h in bank.profile['heroes'] if h['id'] == hero)}. Save the bank to apply it in a future match."]
    old_rank, new_rank = before.values[("Perks", "PRank21")], result.values[("Perks", "PRank21")]
    if old_rank != new_rank:
        notes.append(f"Glyph Crafting Power explicitly raised from {old_rank} to {new_rank}.")
    state.values = result.values
    return notes
