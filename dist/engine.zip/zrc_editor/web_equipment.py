"""Named equipment views and explicit pending inventory edits for Reign 0.291.

Only existing supported native units are changed. All coordinates are bank
coordinates (zero based); the UI labels them for people. No file writes occur.
"""
from .common import BankError
from . import items
from .evolutions import catalog as evolution_catalog, form_for_stage
from .item_loadouts import sync_active_loadout


DELIVERY = (
    "Shared stash: items appear in the Softcore stash chest after the edited bank is loaded in a new match. Withdraw them in game.",
    "Hero storage bag: items belong to that saved hero and appear in its storage inventory, not the shared stash.",
    "Active equipment: items are equipped on the saved hero. Its first equipment loadout is synchronized so it does not immediately swap older bag items back in.",
    "A hero or stash must already have a supported saved unit. Play and save it once if it is unavailable. Editing here only changes the pending bank; save explicitly before a new match.",
)


def _heroes():
    return {('Hero', h['unit_key']): h for h in evolution_catalog()['heroes']}


def _known_form(bank, pair, hero):
    node = bank.nodes.get(pair)
    leaf = node.find('Type') if node is not None else None
    return leaf is not None and leaf.get('string') in {form['unit_id'] for form in hero['forms']}


def _pair(value):
    if not isinstance(value, str) or len(value.split('/')) != 2:
        raise BankError('Choose a supported equipment destination.')
    pair = tuple(value.split('/'))
    if items.carrier_for_pair(pair) is None:
        raise BankError('Choose a supported equipment destination.')
    return pair


def _position(container, slot, carrier):
    capacities = items.STASH_CAPACITIES if carrier == 'stash' else items.HERO_CAPACITIES
    if type(container) is not int or type(slot) is not int or not 0 <= container < len(capacities) or not 0 <= slot < capacities[container]:
        raise BankError('Choose an existing inventory tab and slot.')
    if carrier == 'hero' and (container == 2 or (container == 0 and 12 <= slot < 16)):
        raise BankError('This position belongs to glyphs or an unused inventory row.')
    return container, slot


def _item_view(item):
    entry = items.by_id().get(item.unit_id)
    return {'id': item.unit_id, 'name': entry['name'] if entry else ('Locked slot' if item.unit_id == 'LockedItemSlot1' else 'Preserved unknown item'),
            'rarity': entry['quality'] if entry else None, 'known': bool(entry),
            'description': entry.get('description', '') if entry else 'This original item is preserved; its format or behavior is not verified.',
            'container': item.container, 'slot': item.slot}


def describe(bank, state):
    """Return source-backed card metadata, explicit destinations and slot state."""
    cards = []
    for entry in items.catalog()['items']:
        description = entry.get('description', '')
        cards.append({'id': entry['unit_id'], 'name': entry['name'], 'rarity': entry['quality'],
                      'description': description or 'No verified source description is available.',
                      'stats': [line for line in description.splitlines() if line.strip()],
                      'statsSource': 'Source item tooltip text; dynamic game values are not evaluated.',
                      'dynamicStats': '[dynamic game value]' in description,
                      'slotClass': 'angelic' if entry['unit_id'] in items.ANGELIC_ITEMS else 'ordinary',
                      'sourceRefs': entry.get('source_refs', [])})
    heroes = _heroes()
    carriers = []
    for pair in [items.STASH_PAIR, *heroes]:
        is_stash = pair == items.STASH_PAIR
        supported = pair in state.unit_items
        enabled = supported and not (is_stash and bank.bank_name == 'BlizzardBuiltIn')
        hero = heroes.get(pair)
        reason = '' if enabled else ('The shared stash is disabled in Hardcore.' if is_stash and bank.bank_name == 'BlizzardBuiltIn' else 'No supported saved inventory. Play and save this hero or stash in game first.')
        if enabled and hero and not _known_form(bank, pair, hero):
            enabled = False
            reason = 'The saved hero form is outside the verified evolution catalogue; its inventory is preserved.'
        capacities = items.STASH_CAPACITIES if is_stash else items.HERO_CAPACITIES
        current = {(i.container, i.slot): i for i in state.unit_items.get(pair, ())}
        tabs = []
        for container, capacity in enumerate(capacities):
            if not is_stash and container == 2:
                continue
            label = f'Stash tab {container + 1}' if is_stash else ('Active equipment' if container == 0 else 'Hero storage bag')
            slots = []
            for slot in range(capacity):
                if not is_stash and container == 0 and 12 <= slot < 16:
                    continue
                item = current.get((container, slot))
                opaque = item is not None and item.unit_id not in items.by_id()
                slot_reason = 'Original unknown items and native locks are preserved.' if opaque else reason
                slots.append({'slot': slot, 'label': 'Angelic slot' if not is_stash and container == 0 and slot == 16 else f'Slot {slot + 1}',
                              'slotClass': 'angelic' if not is_stash and container == 0 and slot == 16 else 'ordinary' if not is_stash and container == 0 else 'storage',
                              'editable': enabled and not opaque, 'reason': slot_reason,
                              'requiresActiveSlotPerk': not is_stash and container == 0 and 6 <= slot < 12,
                              'item': _item_view(item) if item else None})
            tabs.append({'index': container, 'label': label, 'capacity': capacity, 'slots': slots})
        carriers.append({'id': '/'.join(pair), 'label': 'Shared stash' if is_stash else hero['name'].replace('BloodElf','Blood Elf'),
                         'heroId': hero['id'] if hero else None, 'editable': enabled, 'reason': reason,
                         'containers': tabs})
    return {'catalog': cards, 'carriers': carriers, 'delivery': list(DELIVERY),
            'activeSlotPerkRank': state.values[('Perks', 'PRank18')],
            'activeSlotRule': 'Six ordinary items plus up to three additional items from Active Item Slots; native locked slots remain locked. Angelic gear uses its separate slot.',
            'verification': 'Native serialization and slot restoration tested in an isolated local map. Acceptance of edited banks on the published map is untested.',
            'duplicates': 'Duplicate copies are allowed in storage. Their effects are not guaranteed to stack; the Angelic items explicitly limit their main effects to one stack.'}


def apply(bank, state, request, *, hero_evolutions=None):
    """Atomically stage one add/remove/move. Never overwrite an occupied slot.

    Request: {action, carrier, container, slot, itemId (add only)}.
    A move also supplies toCarrier, toContainer and toSlot. Hero evolution
    selections are the caller's explicit pending form selections, not Evo flags.
    """
    if not isinstance(request, dict) or request.get('action') not in ('add', 'remove', 'move'):
        raise BankError('Choose Add, Remove or Move equipment.')
    if not bank.original_verified():
        raise BankError('The original bank must pass validation before editing equipment.')
    candidate = state.clone()
    pair = _pair(request.get('carrier'))
    action = request['action']
    rank = candidate.values[('Perks', 'PRank18')]
    changed = set()

    def inventory(destination, container, slot):
        carrier = items.carrier_for_pair(destination)
        if destination not in candidate.unit_items:
            raise BankError('This destination has no supported saved inventory. Play and save it in game first.')
        if carrier == 'stash' and bank.bank_name == 'BlizzardBuiltIn':
            raise BankError('The shared stash is disabled in Hardcore.')
        hero = _heroes().get(destination)
        if hero and not _known_form(bank, destination, hero):
            raise BankError('The saved hero form is outside the verified evolution catalogue; preserve its inventory.')
        _position(container, slot, carrier)
        values = list(candidate.unit_items[destination])
        return values, next((i for i in values if (i.container, i.slot) == (container, slot)), None)

    container, slot = request.get('container'), request.get('slot')
    values, existing = inventory(pair, container, slot)
    if action == 'add':
        uid = request.get('itemId')
        if not isinstance(uid, str) or uid not in items.by_id():
            raise BankError('Choose an item from the verified equipment catalogue.')
        if existing:
            raise BankError('This slot is occupied. Move or remove its item first.')
        values.append(items.Item(uid, container, slot))
    else:
        if existing is None:
            raise BankError('This slot contains no item.')
        if existing.unit_id not in items.by_id():
            raise BankError('Original unknown items and native locks must remain unchanged.')
        values.remove(existing)
    candidate.unit_items[pair] = tuple(values)
    changed.add(pair)
    if action == 'move':
        destination = _pair(request.get('toCarrier'))
        to_container, to_slot = request.get('toContainer'), request.get('toSlot')
        target, occupied = inventory(destination, to_container, to_slot)
        if occupied:
            raise BankError('The destination is occupied. Choose an empty slot.')
        target.append(items.Item(existing.unit_id, to_container, to_slot))
        candidate.unit_items[destination] = tuple(target)
        changed.add(destination)
    heroes = _heroes()
    notes = []
    for destination in changed:
        candidate.unit_items[destination] = items.validate_items(state.unit_items[destination], candidate.unit_items[destination], carrier=items.carrier_for_pair(destination), perk_rank18=rank)
        old_active = tuple(i for i in state.unit_items[destination] if i.container == 0)
        new_active = tuple(i for i in candidate.unit_items[destination] if i.container == 0)
        if destination in heroes and old_active != new_active:
            hero = heroes[destination]
            stage = (hero_evolutions or {}).get(hero['id'])
            node = bank.nodes.get(destination)
            leaf = node.find('Type') if node is not None else None
            unit_type = form_for_stage(hero['id'], stage)['unit_id'] if stage else leaf.get('string') if leaf is not None else None
            sync_active_loadout(candidate, hero['id'], unit_type)
            notes.append(hero['name'] + ': synchronized the saved form’s first active equipment loadout.')
    state.unit_items = candidate.unit_items
    state.item_loadouts = candidate.item_loadouts
    return [f'Equipment {action} staged. Export or replace the bank explicitly to save it.', *notes]
