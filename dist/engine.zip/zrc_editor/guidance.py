"""Source-backed field help and explicit dependency summaries for the UI."""
import copy
import json
from .common import resource_path, BankError
from zwl_editor.fixed import format_fixed


def load_help(name):
    return json.loads(resource_path(f"data/{name}_help.json").read_text(encoding="utf-8-sig"))


def field_metadata(profile):
    result = {}
    for name in ("field", "perk", "charm"):
        result.update(load_help(name).get("fields", {}))
    return result


def enriched_profile(profile):
    result = copy.deepcopy(profile)
    help_fields = field_metadata(profile)
    for spec in result["fields"]:
        help_item = help_fields.get(spec["section"]+"/"+spec["key"], {})
        spec.update({k: v for k, v in help_item.items() if k not in ("min", "max", "type", "editable", "key", "section", "default")})
        if spec["section"]=="Glyphs3":
            part=next(part for part in ("Type","Value","QP","T") if spec["key"].endswith(part))
            spec["description"]={"Type":"Ordered stat types for this existing glyph; edit them by name in Glyphs.","Value":"Ordered stat amounts paired with the glyph's types; edit each amount in Glyphs.","QP":"The glyph's quality and encoded item powers. Preserved because changing this string can alter several effects together.","T":"The glyph's saved tier, which affects its normal roll range. Preserved."}[part]
        elif spec["section"]=="Asc":
            spec["description"]="Edit this hero's ability choice and named passive ranks in Ascendancy. The editor maintains the shared point budget. Mastery progress gates deeper rows."
        elif spec["group"]=="Charms" and not spec.get("description"):
            spec["label"]="Reserved charm slot "+spec["key"][1:]
            spec["description"]="Reserved charm storage. No named usable charm effect was identified for this slot in the audited version; its original value is preserved."
        if spec.get("secondary_effect"):
            spec["description"] += " "+spec["secondary_effect"]
        if spec.get("cap_semantics",{}).get("description"):
            spec["description"] += " "+spec["cap_semantics"]["description"]
    return result


def dependency_text(item):
    values = item.get("dependencies", [])
    return " ".join(v if isinstance(v, str) else v.get("description", "") for v in values)


def limit_text(spec):
    if spec["type"] == "flag": return "Choices: enabled or disabled."
    if spec.get("min") is None or spec.get("max") is None:
        return ""  # Structured string controls explain their own choices.
    fmt = format_fixed if spec["type"] == "fixed" else lambda n: f"{n:,}"
    text = f"Allowed edit range: {fmt(spec['min'])} to {fmt(spec['max'])}."
    if spec["max"] == 2**31-1:
        text += " This is the storage limit; a safe gameplay maximum has not been established."
    elif spec.get("limit_kind"):
        meaning={"source_loader_cap":"The map checks this cap when loading.","normal_writer_clamp":"The normal save/reward path clamps this value.","normal_progression_range":"This is the supported normal progression range.","normal_purchase_cap":"This is the normal purchase rank cap.","source_cycle_enum":"Choose one of the named preferences.","representation_limit":"This is a storage bound, not a verified gameplay maximum.","fixed_representation_limit":"This is a fixed-point storage bound, not a verified level cap."}.get(spec["limit_kind"],"")
        if meaning: text += " "+meaning
    return text


def field_description(spec):
    return "\n".join(part for part in (spec.get("description", ""), limit_text(spec), dependency_text(spec)) if part)


def changed_fields(before, target, profile):
    return [s for s in profile["fields"] if target.values[(s["section"], s["key"])] != before.values[(s["section"], s["key"])]]


def dependency_review(before, target, profile):
    notes = []
    for spec in changed_fields(before, target, profile):
        text = dependency_text(spec)
        if text: notes.append(spec["label"]+": "+text)
        if spec["max"] == 2**31-1 and spec["type"] in ("int", "fixed"):
            notes.append(spec["label"]+": fitting in storage does not establish safe future gameplay arithmetic.")
    return list(dict.fromkeys(notes))


def passive_neighbors(slot):
    if not 4 <= slot <= 33: return []
    row, col = divmod(slot-4, 5)
    return [4+r*5+c for r, c in ((row-1,col),(row+1,col),(row,col-1),(row,col+1)) if 0<=r<6 and 0<=c<5]


def validate_passive_tree(ranks, mastery):
    active = {i+1 for i, rank in enumerate(ranks) if i>=3 and rank}
    if not active: return
    if 6 not in active: raise BankError("Start the passive allocation at Skill Points, the centre node in the first row.")
    visited={6}; pending=[6]
    while pending:
        slot=pending.pop()
        for other in passive_neighbors(slot):
            if other in active and other not in visited:
                visited.add(other); pending.append(other)
    if visited != active: raise BankError("Every allocated passive must connect to Skill Points through adjacent allocated nodes.")
    for slot in active:
        needed=((slot-4)//5)*2
        if mastery<needed: raise BankError(f"Passive row {(slot-4)//5+1} requires mastery progress {needed}; this hero currently has {mastery}.")


def apply_mastery_progress(state, hero):
    """Explicit update of the source's mastery bookkeeping and positive grant."""
    result=state.clone()
    rank=result.values[("Perks",f"PRank{95+hero}")]
    if rank <= 0: raise BankError("Set a positive mastery rank for this hero before applying its mastery progress.")
    old=result.values[("Asc",f"MG{hero}")]; new=rank//4+1
    delta=max(0,new-old)
    ranks=result.values[("Asc",f"AscEncryptionKey{hero}")]
    pool=result.values[("Asc",f"AscPassPts{hero}")]
    if sum(map(int,ranks[3:]))+pool+delta>25:
        raise BankError("The mastery update would exceed the 25-point passive budget. Lower the total passive points first.")
    result.values[("Asc",f"MG{hero}")]=new
    result.values[("Asc",f"AscPassPts{hero}")]=pool+delta
    return result
