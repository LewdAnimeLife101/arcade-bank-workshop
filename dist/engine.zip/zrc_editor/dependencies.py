"""Cross-field Reign 0.291 checks; purchase requirements remain advisory.

This module never writes files or replays a purchase. Source ranges refer to
the audited map's MapScript.galaxy, not to observed live Arcade acceptance.
"""
from dataclasses import dataclass

from .common import BankError
from .guidance import validate_passive_tree


@dataclass(frozen=True)
class DependencyIssue:
    code: str
    severity: str
    message: str
    fields: tuple[tuple[str, str], ...]
    source_lines: tuple[int, int]


QUALITY_CHAINS = ((0, 1, 2, 3, 4, 5, 6), (9, 10, 11))


def effective_ordinary_record(state):
    """The loader compares before clamping the legacy value (33463-33472)."""
    current = state.values[("Diseases", "Plague")]
    legacy = state.values[("Diseases", "Downsyndrome")]
    return min(legacy, 40) if legacy > current else current


def passive_total(state, hero):
    ranks = state.values[("Asc", f"AscEncryptionKey{hero}")]
    return sum(map(int, ranks[3:])) + state.values[("Asc", f"AscPassPts{hero}")]


def inspect_dependencies(before, target, profile, *, bank=None):
    """Report changed relationships without rejecting unchanged legacy state.

    ``bank`` adds observations requiring presence information; neither its
    XML nor either State is mutated. Core primitive/shape validation must run
    first. Only severity ``error`` is an export guard.
    """
    issues = []
    changed = {pair for pair, value in target.values.items()
               if before.values.get(pair) != value}

    def add(code, severity, message, fields, lines):
        issues.append(DependencyIssue(code, severity, message, tuple(fields), lines))

    labels = {(s["section"], s["key"]): s["label"] for s in profile["fields"]}
    for chain in QUALITY_CHAINS:
        for lower, upper in zip(chain, chain[1:]):
            previous, current = ("Perks", f"PRank{lower}"), ("Perks", f"PRank{upper}")
            if changed.intersection((previous, current)) and target.values[current] and not target.values[previous]:
                add("quality_prerequisite", "warning",
                    f"{labels[current]} normally requires {labels[previous]}. The loader does not replay the shop prerequisite; use Apply quality prerequisites to retain the normal unlock chain.",
                    (previous, current), (32685, 32741))

    ordinary = ("Diseases", "Plague")
    if ordinary in changed:
        loaded = effective_ordinary_record(target)
        if loaded != target.values[ordinary]:
            add("legacy_record_override", "error",
                f"Best ordinary solo dungeon would load as {loaded}, because the preserved legacy solo record overrides the entered value. Choose a record that is not overridden.",
                (ordinary, ("Diseases", "Downsyndrome")), (33463, 33472))
        add("ordinary_record_effects", "info",
            "The ordinary solo record also changes XP and currency/magic-find reward multipliers. It does not award prior clear rewards or create matching per-hero records and completion times.",
            (ordinary,), (6137, 6145))
    if ("Diseases", "KPlague") in changed:
        add("kalimdor_unlocks", "info",
            "A Kalimdor solo record above 100 enables additional zone and building-XP startup upgrades. Ordinary and Kalimdor records have different limits.",
            (("Diseases", "KPlague"),), (33699, 33719))

    mfperk, mf = ("Perks", "PRank14"), ("GameTS", "MF")
    if mfperk in changed:
        stored = bank is not None and mf in bank.present
        message = ("The existing saved magic-find total overrides the starting-perk fallback; changing this perk alone does not raise the saved total."
                   if stored else "When GameTS/MF is absent, starting magic find is derived from this perk and the effective ordinary solo record. Saving an explicit total makes that total take precedence.")
        add("magic_find_precedence", "info", message, (mfperk, mf, ordinary), (33571, 33577))

    for hero_info in profile["heroes"]:
        hero, name = hero_info["id"], hero_info["name"]
        mastery, mg = ("Perks", f"PRank{95+hero}"), ("Asc", f"MG{hero}")
        ranks, pool = ("Asc", f"AscEncryptionKey{hero}"), ("Asc", f"AscPassPts{hero}")
        if bank is not None and ('NextUpdateEncryptionKey',f'KeyString{hero}') not in bank.nodes:
            delta=target.values[mg]-before.values[mg]
            companion=delta>0 and target.values[mastery]>0 and target.values[mg]==target.values[mastery]//4+1 and passive_total(target,hero)>=passive_total(before,hero)+delta
            xp_spec=next(s for s in profile['fields'] if s.get('unit_key') and s.get('hero')==hero)
            xp_pair=(xp_spec['section'],xp_spec['key'])
            if not companion and passive_total(target,hero)==25 and (passive_total(before,hero)<25 or xp_pair in changed):
                add('pending_level100_point','error',
                    f"{name}: the map's one-time level-100 passive point is still pending. Leave at least one point of room (24 allocated plus unspent maximum) until that award is recorded, or apply a source-supported positive mastery grant. Otherwise the later award can exceed the 25-point loader limit.",
                    (ranks,pool,xp_pair), (30059,30064))
        if mg in changed:
            try:
                validate_passive_tree(list(map(int, target.values[ranks])), target.values[mg])
            except BankError as exc:
                add("mastery_row_gate", "error", f"{name}: {exc}", (mg, ranks), (11204, 11236))
        if mastery in changed:
            add("mastery_is_not_purchase", "info",
                f"{name}: mastery is the map's prestige-like progression (maximum rank 40). A normal purchase requires final evolution and level 100, resets XP to level 1, reduces subsequent XP gain by a further factor of 0.9, and reloads skill loadout 6. Editing the rank preserves XP and skill loadouts; Apply mastery progress updates only its ascendancy bookkeeping and positive point grant.",
                (mastery, mg, pool), (11943, 12035))
            if target.values[mastery] < before.values[mastery]:
                add("mastery_lowering", "warning",
                    f"{name}: lowering mastery can close passive rows. Passive ranks and the existing point balance are not automatically removed.",
                    (mastery, mg, ranks, pool), (11204, 11236))
        purchase = ("Perks", f"H{hero}PRank24")
        delta = target.values[purchase] - before.values[purchase]
        if delta > 0:
            expected = passive_total(before, hero) + delta
            if passive_total(target, hero) < expected:
                add("passive_purchase_points", "warning",
                    f"{name}: the passive-point purchase counter rose by {delta}, but spent plus unspent points did not rise by that amount. Use Apply purchased passive points if you want the accompanying point grant. The counter alone is not a purchase transaction.",
                    (purchase, ranks, pool), (11782, 11786))
        for number, action in ((22, "reset the three ability choices and return one ability point"),
                               (23, "refund allocated passive ranks into the unspent point pool")):
            pair = ("Perks", f"H{hero}PRank{number}")
            if pair in changed:
                add("reset_counter", "info",
                    f"{name}: this is a historical purchase/reset counter. Changing it does not {action}. Use the named Ascendancy controls to edit the allocation itself.",
                    (pair, ranks, pool), (11743, 11779))

    if ("Perks", "PRank52") in changed:
        cap = 80 + target.values[("Perks", "PRank52")]
        add("shared_level_cap", "info",
            f"Hero Enhancement sets the shared maximum hero level to {cap}. Changing it affects every hero; the level picker raises it only as needed for a selected level.",
            (("Perks", "PRank52"),), (11824, 11833))
    for number in (12, 48):
        if ("Perks", f"PRank{number}") in changed:
            add("skill_points", "info",
                "Skill Enhancement and Skill Enhancement II contribute their ranks together to base learnable skill points. Existing saved skills and skill loadouts are preserved; editing a rank does not respec the hero.",
                (("Perks", "PRank12"), ("Perks", "PRank48")), (11646, 11652))
    if ("Perks", "PRank57") in changed:
        rank = target.values[("Perks", "PRank57")]
        required = 50 + 25 * rank
        text = f"Charm Slots rank {rank} unlocks {rank} equipped charm slots; charm ownership and the active charm loadout are separate."
        if rank:
            text += f" Normal purchase of this rank asks for ordinary solo record {required}."
        if rank == 3:
            text += " This conflicts with the startup check rejecting ordinary solo records above 100; do not raise that record to 125 to satisfy the shop text."
        add("charm_slot_requirements", "warning" if rank == 3 else "info", text,
            (("Perks", "PRank57"), ordinary), (32833, 32835))
    for number, message, lines in (
        (18, "Active Item Slots controls unlocked hero equipment slots. It does not grant items or rearrange the saved inventory.", (11675, 11676)),
        (25, "Event Probability contributes to an average across all active players. This is a shared session calculation, not a per-hero saved counter.", (11789, 11803)),
        (26, "Ultravision applies the saved rank as a player upgrade. It does not grant ascendancy points or reset a hero.", (11807, 11808)),
    ):
        if ("Perks", f"PRank{number}") in changed:
            add("perk_effect", "info", message, (("Perks", f"PRank{number}"),), lines)
    return issues


def dependency_review(before, target, profile, *, bank=None):
    return [issue.message for issue in inspect_dependencies(before, target, profile, bank=bank)]


def validate_dependencies(before, target, profile, *, bank=None):
    errors = [issue.message for issue in inspect_dependencies(before, target, profile, bank=bank)
              if issue.severity == "error"]
    if errors:
        raise BankError("\n".join(errors))


def apply_quality_prerequisites(state):
    """Explicitly raise lower quality unlocks; never lower or spend currency."""
    result = state.clone()
    for chain in QUALITY_CHAINS:
        for index in range(len(chain) - 1, 0, -1):
            if result.values[("Perks", f"PRank{chain[index]}")]:
                result.values[("Perks", f"PRank{chain[index-1]}")] = 1
    return result


def apply_passive_point_purchases(before, target, hero, profile):
    """Explicit positive grant, idempotent against the opened bank baseline.

    Existing allocation and point additions count toward the requested grant.
    No reset, fee deduction or historical purchase replay is inferred.
    """
    if type(hero) is not int or hero not in {h["id"] for h in profile["heroes"]}:
        raise BankError("Choose an available hero.")
    pair = ("Perks", f"H{hero}PRank24")
    delta = target.values[pair] - before.values[pair]
    if delta <= 0:
        raise BankError("Increase this hero's passive-point purchase counter first.")
    needed = max(0, passive_total(before, hero) + delta - passive_total(target, hero))
    if passive_total(target, hero) + needed > 25:
        raise BankError("The companion passive-point grant would exceed the 25-point spent-plus-unspent limit.")
    result = target.clone()
    result.values[("Asc", f"AscPassPts{hero}")] += needed
    return result
