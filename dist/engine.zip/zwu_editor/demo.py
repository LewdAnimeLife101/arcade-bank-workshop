"""Synthetic fixture without personal data or a game-valid identity."""
import xml.etree.ElementTree as ET
from .core import Bank, load_profile


def demo_bytes() -> bytes:
    profile = load_profile()
    root = ET.Element("Bank", version="1")
    sections = {}

    def put(section, key, val):
        if section not in sections:
            sections[section] = ET.SubElement(root, "Section", name=section)
        node = ET.SubElement(sections[section], "Key", name=key)
        ET.SubElement(node, "Value", int=str(val))

    b = 12000
    put("PlayerIDNumber", "PlayerID", b*5)
    put("PlayerIDNumber", "InfoNumber", b*(9983-b))
    put("PlayerIDNumber", "GameRegion", -4718)
    put("number", "wave", 84)
    for spec in profile["talents"]:
        level = 2 if spec["bankkey"] in ("Plays", "Prestige") else min(spec["max"], 5)
        factor = 489-b if spec["factor"] == "prestige" else 983-b
        put(spec["section"], spec["bankkey"], (level+spec["encoded_offset"])*spec["scale"]*factor)
    for group in ("kills", "wins", "evolutions"):
        for spec in profile[group]:
            put(spec["section"], spec["bankkey"], 25000 if group == "kills" else 1)
    ET.indent(root)
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def demo_bank() -> Bank:
    return Bank(demo_bytes())
