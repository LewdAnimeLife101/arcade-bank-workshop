"""Offline Zombie World Unity bank editor."""

__version__ = "0.1.0"
