"""Bank model, source-derived 0.928 arithmetic, and conservative file I/O.

No game interaction, network requests, or account-specific data are required.
The source audit and profile shipped beside the program define its scope.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import copy
import hashlib
import json
import os
import re
import sys
import tempfile
import uuid
import xml.etree.ElementTree as ET
from datetime import datetime, timezone

INT_MIN, INT_MAX = -(2**31), 2**31 - 1
HANDLE = re.compile(r"[1-9][0-9]*-S2-[1-9][0-9]*-[1-9][0-9]*\Z")


class BankError(ValueError):
    """A user-actionable bank or validation error."""


def resource_path(relative: str) -> Path:
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent.parent))
    parts = Path(relative).parts
    if parts and parts[0] in ("data", "docs"):
        return base / parts[0] / "unity" / Path(*parts[1:])
    return base / relative


def load_profile() -> dict:
    return json.loads(resource_path("data/map_profile.json").read_text(encoding="utf-8-sig"))


def integer(value: object, label: str, low: int = 0, high: int = INT_MAX) -> int:
    if isinstance(value, bool) or not re.fullmatch(r"-?[0-9]+", str(value)):
        raise BankError(f"{label}: enter a whole number.")
    try:
        result = int(str(value))
    except ValueError as exc:
        raise BankError(f"{label}: the number is too long.") from exc
    if not low <= result <= high:
        raise BankError(f"{label}: must be between {low:,} and {high:,}.")
    return result


def trunc_div(a: int, b: int) -> int:
    if b == 0:
        raise BankError("The bank's encoding has a zero divisor.")
    return (abs(a) // abs(b)) * (-1 if (a < 0) != (b < 0) else 1)


def checked(value: int) -> int:
    return integer(value, "Encoded integer", INT_MIN, INT_MAX)


@dataclass(eq=True)
class State:
    tp: int = 0
    wave: int = 0
    talents: dict[str, int] = field(default_factory=dict)
    kills: dict[str, int] = field(default_factory=dict)
    wins: dict[str, int] = field(default_factory=dict)
    evolutions: dict[str, int] = field(default_factory=dict)

    def clone(self) -> State:
        return copy.deepcopy(self)


@dataclass(frozen=True)
class Identity:
    author: str
    player: str

    def validate(self) -> None:
        if not HANDLE.fullmatch(self.author) or not HANDLE.fullmatch(self.player):
            raise BankError("Signing needs author and player handles in the form 1-S2-1-1234567.")


def infer_identity(path: Path) -> Identity | None:
    # .../<player>/Banks/<author>/<bank>.SC2Bank
    if path.parent.parent.name.lower() != "banks":
        return None
    identity = Identity(path.parent.name, path.parent.parent.parent.name)
    try:
        identity.validate()
    except BankError:
        return None
    return identity


def signature_for(root: ET.Element, identity: Identity, bank_name: str) -> str:
    """Simple primitive-value SC2 signature; scoped to the audited bank format.

    Structural SHA-1 concatenation documented by the MIT winny-/sc2bank project.
    Reject unsupported structures instead of guessing how to sign them.
    """
    identity.validate()
    if not bank_name or any(c in bank_name for c in "/\\\x00"):
        raise BankError("Invalid bank name for signing.")
    parts = [identity.author, identity.player, bank_name]
    for child in root:
        if isinstance(child.tag, str) and child.tag not in ("Section", "Signature"):
            raise BankError("Unknown root elements: this signature structure is unsupported.")
    sections = sorted(root.findall("Section"), key=lambda e: e.attrib["name"])
    for section in sections:
        if set(section.attrib) != {"name"} or any(isinstance(c.tag, str) and c.tag != "Key" for c in section):
            raise BankError("Unsupported section structure for signing.")
        parts.append(section.attrib["name"])
        for key in sorted(section.findall("Key"), key=lambda e: e.attrib["name"]):
            elements = [e for e in key if isinstance(e.tag, str)]
            if set(key.attrib) != {"name"} or len(elements) != 1 or elements[0].tag != "Value":
                raise BankError("Unsupported key structure for signing.")
            value = elements[0]
            if len(value.attrib) != 1 or len(value) or (value.text or "").strip():
                raise BankError("Unsupported bank value for signing.")
            kind, content = next(iter(value.attrib.items()))
            if kind not in {"int", "flag"}:
                raise BankError(f"Unsupported signature value type: {kind}.")
            parts.extend((key.attrib["name"], "Value", kind, content))
    payload = "".join(parts)
    # UTF-8/ASCII reference implementations disagree for non-ASCII values.
    if not payload.isascii():
        raise BankError("Non-ASCII bank content cannot be signed by this verified profile.")
    return hashlib.sha1(payload.encode("ascii")).hexdigest().upper()


class Bank:
    def __init__(self, raw: bytes, path: Path | None = None, profile: dict | None = None):
        if len(raw) > 4 * 1024 * 1024:
            raise BankError("Bank exceeds the 4 MB safety limit.")
        # UTF-8 only: reject alternate encodings so declaration checks cannot be bypassed.
        try:
            text = raw.decode("utf-8-sig")
        except UnicodeDecodeError as exc:
            raise BankError("Only UTF-8 SC2 banks are supported.") from exc
        if "<!DOCTYPE" in text.upper() or "<!ENTITY" in text.upper():
            raise BankError("DTD and entity declarations are not supported.")
        try:
            self.root = ET.fromstring(text, parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True, insert_pis=True)))
        except ET.ParseError as exc:
            raise BankError(f"Invalid bank XML: {exc}.") from exc
        if self.root.tag != "Bank":
            raise BankError("This file is not an SC2 Bank XML document.")
        self.raw, self.path = raw, path
        self.digest = hashlib.sha256(raw).hexdigest()
        self.profile = profile or load_profile()
        self.values: dict[tuple[str, str], ET.Element] = {}
        seen_sections: set[str] = set()
        for section in self.root.findall("Section"):
            name = section.get("name")
            if name is None or name in seen_sections:
                raise BankError("Missing or duplicate section name; editing would be ambiguous.")
            seen_sections.add(name)
            seen_keys: set[str] = set()
            for key in section.findall("Key"):
                k = key.get("name")
                if k is None or k in seen_keys:
                    raise BankError(f"Missing or duplicate key in section {name}.")
                seen_keys.add(k)
                self.values[(name, k)] = key
        if len(self.root.findall("Signature")) > 1:
            raise BankError("Duplicate signatures are ambiguous.")
        self.identity = infer_identity(path) if path else None
        self.warnings: list[str] = []
        self.errors: list[str] = []
        self.state: State | None = None
        try:
            self.state = self.decode()
            validate_state(self.state, self.profile)
        except BankError as exc:
            self.errors.append(str(exc))

    @classmethod
    def read(cls, path: str | Path, profile: dict | None = None) -> Bank:
        p = Path(path).resolve()
        if p.stat().st_size > 4 * 1024 * 1024:
            raise BankError("Bank exceeds the 4 MB safety limit.")
        return cls(p.read_bytes(), p, profile)

    def get_int(self, section: str, key: str, *, required: bool = False) -> int:
        node = self.values.get((section, key))
        if node is None:
            if required:
                raise BankError(f"Missing {section}/{key}, required by the 0.928 editor profile. The originating version is unknown; editing is disabled.")
            return 0
        vals = [e for e in node if isinstance(e.tag, str)]
        if len(vals) != 1 or vals[0].tag != "Value" or set(vals[0].attrib) != {"int"} or len(vals[0]) or (vals[0].text or "").strip() or (vals[0].tail or "").strip() or (node.text or "").strip():
            raise BankError(f"{section}/{key}: expected one integer Value.")
        return integer(vals[0].get("int"), f"{section}/{key}", INT_MIN, INT_MAX)

    def decode(self) -> State:
        b = trunc_div(self.get_int("PlayerIDNumber", "PlayerID", required=True), 5)
        if b in {489, 983, 9983}:
            b += 1
        # Protect intermediate arithmetic too; arbitrary malformed files must not
        # rely on Python's unlimited integers to appear game-compatible.
        factor_tp, factor_talent, factor_prestige = checked(9983-b), checked(983-b), checked(489-b)
        region = self.get_int("PlayerIDNumber", "GameRegion", required=True)
        info = self.get_int("PlayerIDNumber", "InfoNumber", required=True)
        tp = checked(trunc_div(info, factor_tp) + trunc_div(checked(region + 4718), 21))
        if not 0 <= tp <= 65000:
            raise BankError("Decoded unspent TP is outside 0–65,000; the map would reset it.")
        state = State(tp=tp, wave=self.get_int("number", "wave", required=True))
        for talent in self.profile["talents"]:
            k = talent["bankkey"]
            active = k == "Prestige"
            raw = self.get_int(talent["section"], k, required=not active)
            factor = factor_prestige if talent["factor"] == "prestige" else factor_talent
            level = trunc_div(trunc_div(raw, factor), talent["scale"]) - talent["encoded_offset"]
            state.talents[k] = level
        maximum = state.talents["Plays"]
        if not 0 <= state.talents["Prestige"] <= maximum:
            state.talents["Prestige"] = maximum
            self.warnings.append("Active prestige uses the map's fallback to maximum prestige.")
        for group, dest in (("kills", state.kills), ("wins", state.wins), ("evolutions", state.evolutions)):
            for spec in self.profile[group]:
                dest[spec["bankkey"]] = self.get_int(spec["section"], spec["bankkey"])
        if any(section == "jj" for section, _ in self.values):
            self.warnings.append("Unverified legacy jj fields are preserved; 0.928 reads class kills from jjj.")
        if ("Challenges", "CLEvasive") in self.values:
            self.warnings.append("Unverified legacy CLEvasive is preserved separately from GCLEvasive.")
        return state

    def signature_status(self, identity: Identity | None = None) -> str:
        node = self.root.find("Signature")
        if node is None:
            return "Unsigned"
        ident = identity or self.identity
        if ident is None or self.path is None:
            return "Identity needed"
        try:
            expected = signature_for(self.root, ident, self.path.stem)
        except BankError as exc:
            return f"Unsupported: {exc}"
        return "Verified" if node.get("value", "").upper() == expected else "Does not match"

    def render(self, target: State, identity: Identity | None = None, *, bank_name: str | None = None,
               unsigned: bool = False) -> tuple[bytes, State, list[str]]:
        if self.errors or self.state is None:
            raise BankError("This bank is read-only: " + "; ".join(self.errors))
        validate_state(target, self.profile)
        name = bank_name or (self.path.stem if self.path else "zombieworldu")
        ident = identity or self.identity
        unchanged_name = self.path is None or name == self.path.stem
        if target == self.state and unchanged_name and not unsigned:
            return self.raw, target.clone(), []
        effective = target.clone()
        notes: list[str] = []
        b = min(effective.tp, 45000)
        overflow = max(effective.tp - 45000, 0)
        if b in {489, 983, 9983}:
            b += 1
            effective.tp += 1
            notes.append(f"The map normalizes TP {target.tp:,} to {effective.tp:,} to avoid a zero divisor.")
        root = copy.deepcopy(self.root)

        def put(section_name: str, key_name: str, number: int) -> None:
            section = next((s for s in root.findall("Section") if s.get("name") == section_name), None)
            if section is None:
                section = ET.SubElement(root, "Section", name=section_name)
            key = next((k for k in section.findall("Key") if k.get("name") == key_name), None)
            if key is None:
                key = ET.SubElement(section, "Key", name=key_name)
                ET.SubElement(key, "Value", int=str(checked(number)))
            else:
                # Existing known nodes were structurally validated by decode.
                key.find("Value").set("int", str(checked(number)))

        # Canonicalize the complete dependent encoding whenever an edit is made.
        put("PlayerIDNumber", "PlayerID", b*5)
        put("PlayerIDNumber", "InfoNumber", b*(9983-b))
        put("PlayerIDNumber", "GameRegion", overflow*21-4718)
        for spec in self.profile["talents"]:
            factor = (489-b) if spec["factor"] == "prestige" else (983-b)
            put(spec["section"], spec["bankkey"], (effective.talents[spec["bankkey"]]+spec["encoded_offset"])*spec["scale"]*factor)
        put("number", "wave", effective.wave)
        for group in ("kills", "wins", "evolutions"):
            values = getattr(effective, group)
            original = getattr(self.state, group)
            for spec in self.profile[group]:
                k = spec["bankkey"]
                # Preserve absent optional values unless explicitly changed.
                if (spec["section"], k) in self.values or values[k] != original[k]:
                    put(spec["section"], k, values[k])
        for signature in root.findall("Signature"):
            root.remove(signature)
        if unsigned:
            notes.append("Export is unsigned. In-game acceptance has not been verified.")
        else:
            if ident is None:
                raise BankError("Enter the bank's author and player handles, or explicitly choose an unsigned test copy.")
            if self.root.find("Signature") is not None and self.signature_status(ident) != "Verified":
                raise BankError("The original signature does not verify with these handles. Correct them before signing an edit, or export an explicitly unsigned test copy.")
            ET.SubElement(root, "Signature", value=signature_for(root, ident, name))
        ET.indent(root, space="    ")
        result = ET.tostring(root, encoding="utf-8", xml_declaration=True) + b"\n"
        reread = Bank(result, self.path, self.profile)
        if reread.errors or reread.state != effective:
            raise BankError("Export did not pass the independent read-back validation.")
        return result, effective, notes


def validate_state(state: State, profile: dict) -> None:
    integer(state.tp, "Unspent TP", 0, 65000)
    integer(state.wave, "Highest wave", 0, 16999)
    for group in ("talents", "kills", "wins", "evolutions"):
        values = getattr(state, group)
        specs = profile[group]
        if set(values) != {s["bankkey"] for s in specs}:
            raise BankError(f"Incomplete {group} state.")
        for spec in specs:
            integer(values[spec["bankkey"]], spec["label"], 0, spec.get("max", INT_MAX))
    if state.talents["Prestige"] > state.talents["Plays"]:
        raise BankError("Active prestige cannot exceed maximum prestige.")


def changes(before: State, after: State, profile: dict) -> list[tuple[str, int, int]]:
    result = []
    for label, a, b in (("Unspent TP", before.tp, after.tp), ("Highest wave", before.wave, after.wave)):
        if a != b:
            result.append((label, a, b))
    for group in ("talents", "kills", "wins", "evolutions"):
        a, b = getattr(before, group), getattr(after, group)
        for spec in profile[group]:
            k = spec["bankkey"]
            if a[k] != b[k]:
                result.append((spec["label"], a[k], b[k]))
    return result


def level_price(spec: dict, level: int) -> int:
    """Price of purchasing the specified level, with exact integer ceiling."""
    if spec["price_curve"] in ("curved", "scaled", "quadratic", True):
        num = spec["pricebase"] * (spec["max"] + 6*level - 3)
        den = 4*spec["max"]
        return (num + den - 1) // den
    return spec["pricebase"]


def write_bank(destination: Path, payload: bytes, source: Bank, *, replace: bool = False) -> Path | None:
    """Validate first, stage and fsync, back up existing destination, atomic replace.

    Source hash is rechecked immediately before commit. Backups never overwrite.
    Full game/account/profile acceptance is outside this file-I/O guarantee.
    """
    if Path(destination).is_symlink():
        raise BankError("Refusing to replace a symbolic link.")
    destination = Path(destination).resolve()
    if destination.suffix.lower() != ".sc2bank":
        raise BankError("The destination must have the .SC2Bank extension.")
    output = Bank(payload, destination, source.profile)
    if output.errors:
        raise BankError("Refusing invalid output: " + "; ".join(output.errors))
    if source.path and (not source.path.exists() or hashlib.sha256(source.path.read_bytes()).hexdigest() != source.digest):
        raise BankError("The original changed after opening. Reload it before exporting.")
    exists = destination.exists()
    if exists and not replace:
        raise BankError("The destination already exists. Choose a new file or explicitly replace it.")
    if exists and destination.is_symlink():
        raise BankError("Refusing to replace a symbolic link.")
    destination.parent.mkdir(parents=True, exist_ok=True)
    old = destination.read_bytes() if exists else None
    token = uuid.uuid4().hex[:8]
    backup: Path | None = None
    fd, temp_name = tempfile.mkstemp(prefix=".zwu-", suffix=".tmp", dir=destination.parent)
    staged = Path(temp_name)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        if staged.read_bytes() != payload:
            raise BankError("Staged file verification failed.")
        if source.path and hashlib.sha256(source.path.read_bytes()).hexdigest() != source.digest:
            raise BankError("The original changed during export. Reload it.")
        if exists:
            if destination.read_bytes() != old:
                raise BankError("The destination changed during export.")
            stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
            backup = destination.with_name(f"{destination.name}.{stamp}.{token}.bak")
            with backup.open("xb") as stream:
                stream.write(old)
                stream.flush()
                os.fsync(stream.fileno())
            if backup.read_bytes() != old:
                raise BankError("Backup verification failed; the destination was not replaced.")
            os.replace(staged, destination)
        else:
            # Hard link provides atomic creation without clobbering a file that
            # appeared after the existence check (Windows NTFS and POSIX).
            os.link(staged, destination)
            staged.unlink()
        if destination.read_bytes() != payload:
            raise BankError("Output read-back failed. A prior-file backup is available." if backup else "Output read-back failed.")
        return backup
    finally:
        staged.unlink(missing_ok=True)
