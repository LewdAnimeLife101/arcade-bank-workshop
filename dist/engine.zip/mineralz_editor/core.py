"""Mineralz bank state and source-derived constraints; integrity fails closed."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from math import isqrt
import copy
import re
import xml.etree.ElementTree as ET

from arcade_editor.xmlbank import XMLBank
from .common import BankError, integer, INT_MAX, load_profile
from zwl_editor.core import inferred_player
from zwl_editor.fixed import SCALE, parse_fixed, format_fixed
from . import protection

@dataclass(eq=True)
class State:
    values: dict[str,int]
    achievements: str
    skin: int = 1
    def clone(self): return copy.deepcopy(self)

def validate(state,profile,*,before=None):
    keys={f"v{i}" for i in range(1,14)}|{"testgames","testnights","version"}
    if set(state.values)!=keys: raise BankError("Incomplete Mineralz state.")
    for spec in profile["fields"]:
        key=spec["key"]
        if spec["section"]!="sec" or key not in state.values or key=="version": continue
        value=state.values[key]
        lower=spec["min"]; upper=spec["max"]
        if spec["type"]=="fixed": lower=parse_fixed(str(lower)); upper=parse_fixed(str(upper))
        integer(value,spec["label"],lower,upper)
    if state.values["version"] not in protection.SUPPORTED_VERSIONS:
        raise BankError("Only the audited 1.2 and 1.3 bank branches are supported; no automatic migration is performed.")
    if before and state.values["version"]!=before.values["version"]: raise BankError("Bank format version cannot be edited.")
    if state.values["v9"]>state.values["v8"]: raise BankError("Wins cannot exceed games played.")
    if state.values["v11"]//SCALE!=state.values["v10"]: raise BankError("The integer part of experience must equal the Probe level.")
    if not re.fullmatch("[0-9]{150}",state.achievements): raise BankError("Achievements must contain exactly 150 ASCII digits.")
    base=profile["achievements_codec"]["base_string"]
    for i in range(108):
        if state.achievements[i] not in (base[i],str(int(base[i])+1)):
            raise BankError(f"Achievement {i+1} has an unsupported digit; no automatic repair is performed.")
    if before and state.achievements[108:]!=before.achievements[108:]: raise BankError("Reserved achievement positions 109–150 must be preserved.")
    integer(state.skin,"Selected Probe skin",-(2**31),INT_MAX)
    # Unknown/externally earned original selections are preserved. A newly
    # selected skin must have prerequisites established by this bank.
    if before and (state.skin!=before.skin or (skin_eligible(before,profile) and not skin_eligible(state,profile))):
        if not skin_eligible(state,profile):
            raise BankError("Selected Probe skin is not unlocked by these records/achievements. Choose Probe or meet the skin's listed requirement.")

def skin_eligible(state,profile):
    spec=next((x for x in profile["skins"] if x["id"]==state.skin),None)
    if spec is None or not spec["eligibility_from_current_bank_only"]: return False
    rule=spec["eligibility"];kind=rule["type"]
    if kind=="default":return True
    if kind in ("night_record","test_games"):return state.values[rule["key"]]>=rule["min"]
    if kind=="achievement":
        i=rule["id"]-1
        return state.achievements[i]!=profile["achievements_codec"]["base_string"][i]
    return False


def skin_options(state,profile):
    result=[]
    for spec in profile["skins"]:
        if not spec["eligibility_from_current_bank_only"] and state.skin!=spec["id"]:continue
        rule=spec["eligibility"];kind=rule["type"]
        detail=(f'{rule["difficulty"]} night {rule["min"]}' if kind=="night_record" else
                '1 test game' if kind=="test_games" else
                f'Achievement {rule["id"]}' if kind=="achievement" else
                'default' if kind=="default" else 'existing selection; external eligibility unverified')
        result.append({"value":spec["id"],"label":f'{spec["label"]} — {detail}'})
    if state.skin not in [x["value"] for x in result]:
        result.append({"value":state.skin,"label":f'Existing unknown selection {state.skin} (preserved)'})
    return result


def talent_points(state,profile):
    base=profile["achievements_codec"]["base_string"]
    earned=sum(a!=b for a,b in zip(state.achievements[:108],base[:108]))
    return 5+sum(state.values[f"v{i}"]//10 for i in range(1,8))+isqrt(state.values["v10"])+state.values["v12"]+earned//7

class Bank(XMLBank):
    def __init__(self,raw,path=None,profile=None,*,player=""):
        self.parse(raw,path)
        self.profile=profile or load_profile(); self.player=player or inferred_player(path)
        self.state=None; self.errors=[]; self.warnings=[]; self.checks={}
        try:
            values={}
            for key in [*(f"v{i}" for i in range(1,14)),"testgames","testnights","version"]:
                kind="fixed" if key in ("v11","version") else "int"
                values[key]=self.get("sec",key,kind,required=True)
            self.state=State(values,self.get("sec","Achievements","string",required=True),self.get("cus","skin","int",default=1))
            validate(self.state,self.profile)
            self.warnings.append("Map publication 2.62 and bank format version are separate. The original bank format is preserved.")
            if values["version"]==parse_fixed("1.2"):
                self.warnings.append("The map migrates format 1.2 on load: v13=0 becomes v12, and nonzero v13 becomes 0. Current streak labels describe format 1.3; this editor preserves the older format.")
            self.warnings.append("The game can reset an invalid main bank and restore/overwrite its three rotating backups. Keep independent copies.")
            expected=None
            if not self.player: self.errors.append("Enter the original player handle and revalidate to check account-dependent protection.")
            else:
                expected=protection.calculate(values,self.state.achievements,self.player)
                for key,calculated in zip(("CP1","CP2"),expected):
                    matched=self.get("sec",key,"fixed",required=True)==calculated
                    self.checks[key]=matched
                    if not matched: self.errors.append(f"{key} does not match the offline model. Edited export is disabled.")
            self.model_verified=bool(getattr(protection,"MODEL_VERIFIED",False))
            if not self.model_verified: self.errors.append("Native protection arithmetic is still under verification; edited Mineralz exports are disabled.")
            if self.root.find("Signature") is not None: self.errors.append("Signed mixed-type banks are unsupported.")
        except BankError as exc: self.errors.append(str(exc))

    @classmethod
    def read(cls,path,profile=None,*,player=""):
        p=Path(path).resolve()
        if p.stat().st_size>4*1024*1024: raise BankError("Bank exceeds the 4 MB limit.")
        return cls(p.read_bytes(),p,profile,player=player)

    def render(self,target):
        if self.errors or self.state is None: raise BankError("Read-only: "+"; ".join(self.errors))
        validate(target,self.profile,before=self.state)
        if target==self.state: return self.raw,[]
        raw_checks=protection.calculate(target.values,target.achievements,self.player)
        root=copy.deepcopy(self.root)
        section=next(s for s in root.findall("Section") if s.get("name")=="sec")
        def put(key,kind,value):
            node=next(k for k in section.findall("Key") if k.get("name")==key)
            child=node.find("Value")
            child.set(kind,format_fixed(value) if kind=="fixed" else str(value))
        for key,value in target.values.items():
            if value!=self.state.values[key]: put(key,"fixed" if key in ("v11","version") else "int",value)
        if target.achievements!=self.state.achievements: put("Achievements","string",target.achievements)
        for key,value in zip(("CP1","CP2"),raw_checks): put(key,"fixed",value)
        if target.skin!=self.state.skin:
            cus=next((s for s in root.findall("Section") if s.get("name")=="cus"),None)
            if cus is None:cus=ET.SubElement(root,"Section",name="cus")
            node=next((k for k in cus.findall("Key") if k.get("name")=="skin"),None)
            if node is None:node=ET.SubElement(cus,"Key",name="skin");ET.SubElement(node,"Value")
            node.find("Value").attrib={"int":str(target.skin)}
        ET.indent(root,space="    ")
        raw=ET.tostring(root,encoding="utf-8",xml_declaration=True)+b"\n"
        reread=Bank(raw,self.path,self.profile,player=self.player)
        if reread.errors or reread.state!=target: raise BankError("Output failed read-back validation: "+"; ".join(reread.errors))
        return raw,["CP1 and CP2 regenerated together; bank format and reserved achievement data preserved.","Protection was checked in a local diagnostic; this output has not completed a published Arcade match."]

def diff(before,after,profile):
    result=[]
    for field in profile["fields"]:
        key=field["key"]
        if key in before.values and before.values[key]!=after.values[key]:
            a,b=before.values[key],after.values[key]
            if field["type"]=="fixed": a,b=format_fixed(a),format_fixed(b)
            result.append(f"{field['label']}: {a} → {b}")
    if before.skin!=after.skin:result.append(f"Selected Probe skin: {before.skin} → {after.skin}")
    for i,(a,b) in enumerate(zip(before.achievements[:108],after.achievements[:108]),1):
        if a!=b: result.append(f"Achievement {i}: changed")
    return result
