"""Synthetic inspection fixture; NOT evidence of native protection correctness."""
import xml.etree.ElementTree as ET
from .common import load_profile
from .core import Bank
from . import protection
from zwl_editor.fixed import parse_fixed, format_fixed

DEMO_PLAYER="1-S2-1-1234567"

def demo_bytes():
    values={f"v{i}":0 for i in range(1,14)}
    values.update(testgames=0,testnights=0,version=parse_fixed("1.3"))
    base=load_profile()["achievements_codec"]["base_string"]
    root=ET.Element("Bank",version="1")
    sec=ET.SubElement(root,"Section",name="sec")
    def put(key,kind,value):
        ET.SubElement(ET.SubElement(sec,"Key",name=key),"Value",{kind:str(value)})
    for key,value in values.items():
        kind="fixed" if key in ("v11","version") else "int"
        put(key,kind,format_fixed(value) if kind=="fixed" else value)
    put("Achievements","string",base)
    for key,value in zip(("CP1","CP2"),protection.calculate(values,base,DEMO_PLAYER)):
        put(key,"fixed",format_fixed(value))
    ET.indent(root,space="    ")
    return ET.tostring(root,encoding="utf-8",xml_declaration=True)

def demo_bank():
    return Bank(demo_bytes(),player=DEMO_PLAYER)
