"""Mineralz Survival 2 bank format, isolated from the Zombie World codecs."""
__version__="0.1.0"
