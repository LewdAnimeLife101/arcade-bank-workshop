"""Staged Mineralz bank protection for format 1.2/1.3.

Integer lookup/interpolation math is corroborated by native diagnostic v5
(8192 scalar grid results) and diagnostic v7 (116 complete checkpoint pairs
accepted by the map's original validation expressions, plus90 normalization
edges). The lookup constants also match the installed executable's numerical
tables. A fresh client in diagnostic v10 reloaded all116 persisted cases and
accepted every checkpoint pair and original-source validator result. This
establishes the supported offline arithmetic model, not a full published-
Arcade match round trip. Callers must still compare both original checkpoints
before changed export and reject excluded arithmetic domains.

Source references: MapScript.galaxy 9951-9995 and 10099-10143 from archive
7664a93c6c5357d5dd5a8d5f7134160a2e8978726749339039f66cd6a85ff6d4.
Values use ordinary integers except v11 and optional version, which use Q12 raw
integers. Achievements is the complete 150-digit string. No private fixtures,
account identifiers, signatures or original map source are bundled.
"""
from __future__ import annotations

import json
import re
from functools import lru_cache

from zwl_editor.common import BankError, INT_MAX, INT_MIN, trunc_div
from zwl_editor.fixed import SCALE, wrap32, int_fixed, parse_fixed, divide, sqrt_raw
from .common import resource_path

MODEL_STATUS = "native v5/v7/v10 corroborated; original checkpoints required; restricted arithmetic domains"
MODEL_VERIFIED = True
SUPPORTED_VERSIONS = (parse_fixed("1.2"), parse_fixed("1.3"))


def _add(a: int, b: int) -> int:
    return wrap32(a+b)


def _multiply(a: int, b: int) -> int:
    # Arithmetic right shift is the selected fixed-multiply candidate.
    return wrap32((a*b)//SCALE)


def _product(items: list[int]) -> int:
    result = items[0]
    for item in items[1:]:
        result = _multiply(result, item)
    return result


@lru_cache(maxsize=1)
def _tables() -> tuple[tuple[int, ...], tuple[int, ...]]:
    try:
        data = json.loads(resource_path("data/native_math.json").read_text(encoding="utf-8"))
        pow2 = tuple(data["pow2_q31"])
        log2 = tuple(data["log2_q31"])
        if (data["scale_bits"] != 31 or data["intervals"] != 256 or
                len(pow2) != 257 or len(log2) != 257 or
                pow2[0] != 1 << 31 or pow2[-1] != 1 << 32 or
                log2[0] != 0 or log2[-1] != 1 << 31 or
                any(type(v) is not int for v in pow2+log2) or
                any(a >= b for table in (pow2, log2) for a, b in zip(table, table[1:]))):
            raise ValueError("Invalid math lookup table")
        return pow2, log2
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise BankError("Mineralz native math tables are missing or invalid.") from exc


def _pow2(raw: int) -> int:
    """Native-equivalent positive finite output domain; reject overflow.

    The 12 fractional exponent bits split into an 8-bit interval and a 4-bit
    interpolation remainder. Knots are Q31; final conversion to Q12 truncates
    via a right shift. Exponent 19 or greater would overflow positive fixed.
    Negative exponents naturally underflow to zero.
    """
    if type(raw) is not int or not INT_MIN <= raw <= INT_MAX:
        raise BankError("Mineralz Pow2 input must fit raw signed 32-bit fixed.")
    whole, fraction = divmod(raw, SCALE)
    if whole >= 19:
        raise BankError("Mineralz Pow2 output exceeds the supported positive fixed range.")
    table, _ = _tables()
    index, remainder = divmod(fraction, 16)
    q31 = table[index] + ((table[index+1]-table[index])*remainder >> 4)
    return q31 >> (19-whole)


def _power(a: int, b: int) -> int:
    # Native Pow is this composition, not a direct host floating-point power.
    # The intervening Log2 and multiply results are already quantized fixed.
    return _pow2(_multiply(_log2(a), b))


def _log2(raw: int) -> int:
    if type(raw) is not int or raw > INT_MAX:
        raise BankError("Mineralz Log2 input is outside positive signed fixed range.")
    if raw <= 0:
        raise BankError("Mineralz Log2 requires a positive fixed input.")
    _, table = _tables()
    bit = raw.bit_length()-1
    denominator = 1 << bit
    index, remainder = divmod((raw-denominator)*256, denominator)
    q31 = table[index] + (table[index+1]-table[index])*remainder//denominator
    return (bit-12)*SCALE + (q31 >> 19)


def _log(raw: int, base: int) -> int:
    # Primary shipped NativeLib.galaxy defines libNtve_gf_Log as
    # Log2(value)/Log2(base), with both native results already fixed values.
    return divide(_log2(raw), _log2(base))


def _modulo(raw: int, modulus: int) -> int:
    if modulus == 0:
        raise BankError("Mineralz ModF candidate has a zero divisor.")
    return wrap32(raw-trunc_div(raw, modulus)*modulus)


def _handle_term(player: str, remove: int) -> int:
    if player == "":
        return int_fixed(1234)
    if not re.fullmatch(r"[1-9][0-9]*-S2-[1-9][0-9]*-[0-9]+", player):
        raise BankError("Mineralz needs the original full player handle.")
    # Source StringReplace(handle,"",1,8/10), inclusive 1-based endpoints.
    suffix = player[remove:]
    if not suffix or not suffix.isascii() or not suffix.isdigit():
        raise BankError("Mineralz handle slice is unsupported by this candidate.")
    number = int(suffix)
    if number > INT_MAX:
        raise BankError("Mineralz handle slice overflows a signed integer.")
    return int_fixed(number)


def calculate(values: dict[str, int], achievements: str, player: str) -> tuple[int, int]:
    """Return (CP1_raw,CP2_raw) using staged native-corroborated arithmetic.

    Supported version branches have identical expression shapes; the bank's
    actual version raw value remains part of both expressions. No upgrading is
    performed. Every operation uses integers; no host floating point is used.
    Verification state is deliberately independent of an individual result.
    """
    if not re.fullmatch(r"[0-9]{150}", achievements):
        raise BankError("Mineralz Achievements needs exactly 150 ASCII digits.")
    version = values.get("version", parse_fixed("1.3"))
    if type(version) is not int:
        raise BankError("Mineralz version must be a raw fixed integer.")
    if version not in SUPPORTED_VERSIONS:
        raise BankError("Only Mineralz format 1.2/1.3 expressions are implemented.")
    fields = ("testgames", "testnights") + tuple(f"v{i}" for i in range(1,14))
    fixed: dict[str, int] = {}
    for field in fields:
        if field not in values and field != "v13":
            raise BankError(f"Missing Mineralz protection input {field}.")
        number = values.get(field, 0)
        if isinstance(number, bool) or not isinstance(number, int) or not INT_MIN <= number <= INT_MAX:
            raise BankError(f"Mineralz {field} must fit a signed 32-bit integer.")
        # GetAsFixed on the integer-stored v12 returns zero, rather than an
        # automatic conversion or raw-bit reinterpretation. Native v4/v5
        # explicitly measured this mismatch, including nonzero v12 inputs.
        fixed[field] = number if field == "v11" else (0 if field == "v12" else int_fixed(number))
    a = [0] + [divide(int_fixed(int(achievements[i:i+5])), int_fixed(100))
               for i in range(0,150,5)]

    def term(field: str, index: int) -> int:
        return divide(_add(fixed[field], a[index]), a[index+1])

    cp1_base = _product([
        term("testgames",1), term("testnights",3), term("v1",5),
        term("v2",7), term("v3",9),
        divide(sqrt_raw(_handle_term(player,8)), version),
    ])
    cp1_exponent = _product([
        term("v4",21), term("v5",23), term("v6",25),
        term("v7",27), term("v10",29),
    ])
    cp1_modulus = _product([
        term("v8",11), term("v9",13), term("v11",15),
        term("v12",17), term("v13",19),
    ])
    cp1 = _modulo(_power(cp1_base, cp1_exponent), cp1_modulus)

    cp2_base = _product([
        term("v8",21), term("v7",23), term("testnights",25),
        term("v6",27), term("v5",29),
        divide(sqrt_raw(_handle_term(player,10)), version),
    ])
    cp2_exponent = _product([
        term("v4",1), term("v3",3), term("v2",5),
        term("v12",7), term("v11",9),
    ])
    cp2_log_base = _product([
        term("testgames",11), term("v9",13), term("v13",15),
        term("v1",17), term("v10",19),
    ])
    cp2 = _log(_power(cp2_base, cp2_exponent), cp2_log_base)
    return cp1, cp2
