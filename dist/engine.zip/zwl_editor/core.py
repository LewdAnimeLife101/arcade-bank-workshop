"""Liberty 0.233 state, dependency checks and conservative copy export."""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from pathlib import Path
from decimal import Decimal, InvalidOperation
import copy
import hashlib
import re
import xml.etree.ElementTree as ET

from .common import BankError, HANDLE, INT_MAX, INT_MIN, checked, integer, load_profile, resource_path, trunc_div
from .fixed import SCALE, wrap32, int_fixed, parse_fixed, format_fixed, divide, root_ratio


@dataclass(eq=True)
class Hero:
    purchased: bool = False
    xp: int = 0
    level: int = 1
    prestige: int = 0
    ascensions: str = "00000000"


@dataclass(eq=True)
class Soul:
    type: int = 0
    stats: list[int] = field(default_factory=lambda: [0]*8)  # raw fixed units


@dataclass(eq=True)
class State:
    kills: int = 0
    dust: int = 0
    best_solo: int = 1
    heroes: dict[int, Hero] = field(default_factory=lambda: {i:Hero() for i in range(1,13)})
    challenges: dict[int, bool] = field(default_factory=lambda: {i:False for i in range(1,7)})
    souls: dict[int, Soul] = field(default_factory=lambda: {i:Soul() for i in range(1,101)})
    settings: dict[str, bool | int] = field(default_factory=dict)

    def clone(self):
        return copy.deepcopy(self)


def inferred_player(path: Path | None) -> str:
    if path and path.parent.parent.name.lower() == "banks":
        player = path.parent.parent.parent.name
        if HANDLE.fullmatch(player):
            return player
    return ""


def handle_number(player: str, start: int, end: int) -> int:
    if not HANDLE.fullmatch(player):
        raise BankError("Enter the original player's handle, for example 1-S2-1-1234567.")
    part = player[start-1:end]
    if not part or not part.isdigit():
        raise BankError("The handle has unsupported characters at the map's numeric slice positions.")
    return int(part)


def challenge_number(player: str, challenge: int) -> int:
    factor = max(1, min(99, handle_number(player, 9, 10)))
    # Pow receives a fixed value and returns a signed wrapping fixed result.
    squared_raw = int_fixed((challenge*factor)**2)
    return min(400000, max(challenge, trunc_div(squared_raw, SCALE)))


def checks_for(state: State, player: str, *, ceil_root=False) -> dict[tuple[str,str], int]:
    """Five active LoadStats checks, preserving the source's operation order."""
    p4 = handle_number(player,8,11)
    p3 = handle_number(player,9,11)
    p3_other = handle_number(player,8,10)
    p2 = handle_number(player,10,11)
    prestige = 0
    unlocked = 0
    for i in range(1,13):
        hero = state.heroes[i]
        prestige = wrap32(prestige + int_fixed(hero.xp))
        prestige = wrap32(prestige + int_fixed(hero.level-1))
        prestige = wrap32(prestige + int_fixed(hero.prestige))
        for bit in hero.ascensions:
            prestige = wrap32(prestige + int_fixed(int(bit)*100))
        if hero.purchased:
            unlocked += i*(i+1)
    # Source does dust*10 in integer arithmetic, then adds to a fixed variable.
    soul_sum = int_fixed(wrap32(state.dust*10))
    for i in range(1,101):
        soul = state.souls[i]
        if soul.type:
            for value in soul.stats:
                soul_sum = wrap32(soul_sum + value)
    return {
        ("Version","Version"): root_ratio(int_fixed(state.kills),int_fixed(p4+1),ceil_root=ceil_root),
        ("Version","Previous"): root_ratio(prestige,int_fixed(p4+2),ceil_root=ceil_root),
        ("Version","Upcoming"): root_ratio(int_fixed(unlocked),int_fixed(p3_other)+13312,ceil_root=ceil_root),
        ("TimePlayed","Time"): root_ratio(soul_sum,int_fixed(p3+1),self_denominator=True,ceil_root=ceil_root),
        ("Primary","BC"): divide(int_fixed(state.best_solo**2),int_fixed(p2+1)),
    }


class Bank:
    def __init__(self, raw: bytes, path: Path | None = None, profile: dict | None = None, *, player: str = ""):
        if len(raw)>4*1024*1024:
            raise BankError("Bank exceeds the 4 MB limit.")
        try:
            text=raw.decode("utf-8-sig")
        except UnicodeDecodeError as exc:
            raise BankError("Only UTF-8 SC2 banks are supported.") from exc
        if "<!DOCTYPE" in text.upper() or "<!ENTITY" in text.upper():
            raise BankError("DTD and entities are unsupported.")
        try:
            self.root=ET.fromstring(text,parser=ET.XMLParser(target=ET.TreeBuilder(insert_comments=True,insert_pis=True)))
        except ET.ParseError as exc:
            raise BankError(f"Invalid bank XML: {exc}") from exc
        if self.root.tag!="Bank": raise BankError("Expected a Bank XML document.")
        self.raw,self.path,self.profile=raw,path,profile or load_profile()
        self.player=player or inferred_player(path)
        self.digest=hashlib.sha256(raw).hexdigest()
        self.values={}; self.errors=[]; self.warnings=[]; self.checks={}; self.state=None
        self.souls_profile=__import__("json").loads(resource_path("data/souls_profile.json").read_text(encoding="utf-8-sig"))
        sections=set()
        for section in self.root.findall("Section"):
            name=section.get("name")
            if name is None or name in sections: raise BankError("Missing or duplicate section names.")
            sections.add(name)
            for key in section.findall("Key"):
                k=key.get("name")
                if k is None or (name,k) in self.values: raise BankError("Missing or duplicate bank keys.")
                self.values[(name,k)]=key
        try:
            if self.path and self.path.name.lower()!="directstrike.sc2bank":
                self.warnings.append("This map loads DirectStrike.SC2Bank; keep that filename when installing.")
            if not {"Primary","Version","Purchases"}.issubset(sections):
                raise BankError("This is not an established Liberty bank. Missing required sections; no automatic conversion is available.")
            self.state=self.decode()
            validate(self.state,self.profile,self.souls_profile,before=self.state)
            self.warnings.append("Existing values outside current purchase/UI limits are preserved. New edits must fit the audited limits.")
            self.check_integrity()
            if self.root.find("Signature") is not None:
                self.errors.append("Signed mixed-type banks are unsupported. A stale signature will not be copied to an edited file.")
        except BankError as exc:
            self.errors.append(str(exc))

    @classmethod
    def read(cls,path,profile=None,*,player=""):
        p=Path(path).resolve()
        if p.stat().st_size>4*1024*1024: raise BankError("Bank exceeds the 4 MB limit.")
        return cls(p.read_bytes(),p,profile,player=player)

    def get(self, section, key, kind, default=None):
        node=self.values.get((section,key))
        if node is None: return default
        children=[e for e in node if isinstance(e.tag,str)]
        if len(children)!=1 or children[0].tag!="Value" or set(children[0].attrib)!={kind} or len(children[0]) or any((t or "").strip() for t in (node.text,children[0].text,children[0].tail)):
            raise BankError(f"{section}/{key}: expected one {kind} Value.")
        text=children[0].get(kind)
        if kind=="int": return integer(text,f"{section}/{key}",INT_MIN,INT_MAX)
        if kind=="fixed": return parse_fixed(text)
        if kind=="flag":
            if text not in ("0","1"): raise BankError(f"{section}/{key}: flag must be 0 or 1.")
            return text=="1"
        return text

    def challenge_key(self, i):
        number=challenge_number(self.player,i)
        # Existing engine formatting is authoritative. Preserve its spelling.
        matches=[]
        for section,key in self.values:
            if section=="CLHistory" and key.startswith("C"):
                try:
                    if Decimal(key[1:])==number: matches.append(key)
                except InvalidOperation: pass
        if len(matches)>1: raise BankError("Ambiguous equivalent challenge keys.")
        return matches[0] if matches else f"C{number}"

    def decode(self):
        state=State(kills=self.get("Primary","Primary","int",0),dust=trunc_div(self.get("Settings","Ratio","int",0),13),best_solo=self.get("Primary","BS","int",1))
        for i in range(1,13):
            state.heroes[i]=Hero(self.get("Purchases",f"H{i}","flag",False),self.get("Primary",f"H{i}K","int",0),self.get("Primary",f"H{i}L","int",1),self.get("Primary",f"H{i}P","int",0),self.get("Primary",f"H{i}A","string","00000000"))
        if self.player:
            for i in range(1,7): state.challenges[i]=self.get("CLHistory",self.challenge_key(i),"flag",False)
        else:
            self.warnings.append("Player handle needed to decode account-dependent challenge keys and integrity checks.")
        for i in range(1,101):
            if ("SoulType",f"Soul{i}") in self.values:
                state.souls[i]=Soul(self.get("SoulType",f"Soul{i}","int",0),[self.get("SoulStat",f"Soul{i}Stat{j}","fixed",0) for j in range(1,9)])
        for key,kind in (("Particles","flag"),("Visuals","flag"),("ZealotTaunt","flag"),("skipwavethreshold","int")):
            value=self.get("Settings",key,kind,None)
            if value is not None: state.settings[key]=value
        return state

    def check_integrity(self):
        if not self.player:
            self.errors.append("Player handle is required. Enter it and reload validation before editing.")
            return
        expected=checks_for(self.state,self.player)
        for (section,key),value in expected.items():
            actual=self.get(section,key,"fixed",0)
            if key=="BC" and (("Primary","BS") not in self.values or actual==SCALE):
                matched=True  # Explicit sentinel in original loader, not used to generate exports.
            else:
                matched=actual==value
            self.checks[f"{section}/{key}"]=matched
            if not matched: self.errors.append(f"{section}/{key} fails the modeled map check. Export is disabled to avoid the map's wipe path.")

    def render(self,target:State):
        if self.errors or self.state is None: raise BankError("Read-only: "+"; ".join(self.errors))
        validate(target,self.profile,self.souls_profile,before=self.state)
        if target==self.state: return self.raw,[]
        root=copy.deepcopy(self.root)
        def put(section,key,kind,value):
            s=next((s for s in root.findall("Section") if s.get("name")==section),None)
            if s is None: s=ET.SubElement(root,"Section",name=section)
            k=next((k for k in s.findall("Key") if k.get("name")==key),None)
            if k is None:
                k=ET.SubElement(s,"Key",name=key); ET.SubElement(k,"Value")
            v=k.find("Value")
            if v is None: raise BankError("Cannot replace an unsupported existing value.")
            if v.attrib and set(v.attrib)!={kind}: raise BankError(f"{section}/{key}: existing value has a different type.")
            text=format_fixed(value) if kind=="fixed" else ("1" if value else "0") if kind=="flag" else str(value)
            v.set(kind,text)
        def changed(group,key,kind,old,new):
            if old!=new: put(group,key,kind,new)
        changed("Primary","Primary","int",self.state.kills,target.kills)
        changed("Primary","BS","int",self.state.best_solo,target.best_solo)
        if target.dust!=self.state.dust: put("Settings","Ratio","int",checked(target.dust*13))
        for i in range(1,13):
            old,new=self.state.heroes[i],target.heroes[i]
            changed("Purchases",f"H{i}","flag",old.purchased,new.purchased)
            for suffix,attr,kind in (("K","xp","int"),("L","level","int"),("P","prestige","int"),("A","ascensions","string")):
                changed("Primary",f"H{i}{suffix}",kind,getattr(old,attr),getattr(new,attr))
        for i in range(1,7):
            if target.challenges[i]!=self.state.challenges[i]:
                key=self.challenge_key(i)
                number=challenge_number(self.player,i)
                if any(challenge_number(self.player,j)==number for j in range(1,31) if j!=i):
                    raise BankError("This account has colliding challenge keys; editing that challenge is unsafe.")
                put("CLHistory",key,"flag",target.challenges[i])
        for i in range(1,101):
            old,new=self.state.souls[i],target.souls[i]
            if old!=new:
                # Match source removal of cleared slots; orphaned unknown metadata is retained.
                if not new.type:
                    for s in root.findall("Section"):
                        for k in list(s.findall("Key")):
                            if (s.get("name")=="SoulType" and k.get("name")==f"Soul{i}") or (s.get("name")=="SoulStat" and k.get("name") in {f"Soul{i}Stat{j}" for j in range(1,9)}): s.remove(k)
                else:
                    put("SoulType",f"Soul{i}","int",new.type)
                    for j,v in enumerate(new.stats,1): put("SoulStat",f"Soul{i}Stat{j}","fixed",v)
        for key,value in target.settings.items():
            if self.state.settings.get(key)!=value: put("Settings",key,"flag" if key!="skipwavethreshold" else "int",value)
        expected=checks_for(target,self.player)
        # Native rounding is inferred from snapshots. Avoid outputs sensitive to
        # a one-raw-unit SquareRoot rounding difference until runtime tests exist.
        ceiling=checks_for(target,self.player,ceil_root=True)
        if ceiling!=expected: raise BankError("This edit is sensitive to unverified native square-root rounding. Choose nearby values; export is blocked pending a game-engine test.")
        for (section,key),value in expected.items(): put(section,key,"fixed",value)
        ET.indent(root,space="    ")
        raw=ET.tostring(root,encoding="utf-8",xml_declaration=True)+b"\n"
        reread=Bank(raw,self.path,self.profile,player=self.player)
        if reread.errors or reread.state!=target: raise BankError("Export failed read-back validation: "+"; ".join(reread.errors))
        return raw,["All five modeled integrity fields regenerated together.","Native behavior is corroborated by saved banks; edited files have not been tested in a live game."]


def validate(state,profile,souls_profile,*,before=None):
    integer(state.kills,"Kill balance",0,INT_MAX)
    integer(state.dust,"Dust",0,INT_MAX//13)
    integer(state.best_solo,"Best solo difficulty",0,INT_MAX if before and state.best_solo==before.best_solo else 30)
    if set(state.heroes)!=set(range(1,13)) or set(state.souls)!=set(range(1,101)) or set(state.challenges)!=set(range(1,7)):
        raise BankError("Incomplete hero, soul or challenge state.")
    for spec in profile["heroes"]:
        hero=state.heroes[spec["id"]]
        if not isinstance(hero.purchased,bool): raise BankError("Purchased must be a flag.")
        if not re.fullmatch("[01]{8}",hero.ascensions): raise BankError(f"{spec['label']}: ascensions must be eight binary digits.")
        allowed={s["id"] for s in spec["ascensions"] if s.get("available",False)}
        old=before.heroes[spec["id"]] if before else None
        if any(c=="1" and i not in allowed and (old is None or old.ascensions[i-1]!="1") for i,c in enumerate(hero.ascensions,1)):
            raise BankError(f"{spec['label']}: an ascension bit is unsupported by this map profile.")
        integer(hero.level,spec["label"]+" level",1,(20+10*hero.ascensions.count("1")) if old is None or (hero.level,hero.ascensions)!=(old.level,old.ascensions) else INT_MAX)
        integer(hero.prestige,spec["label"]+" prestige",0,spec["prestige_max"] if old is None or hero.prestige!=old.prestige else INT_MAX)
        integer(hero.xp,spec["label"]+" XP",0,524287)
    for value in state.challenges.values():
        if not isinstance(value,bool): raise BankError("Challenge completion must be a flag.")
    caps={tier["code"]:tier["stats2_to5_cap"] for tier in souls_profile["tiers"]}
    for i,soul in state.souls.items():
        unchanged=before is not None and soul==before.souls[i]
        integer(soul.type,f"Soul {i} tier",0,INT_MAX if unchanged else 15)
        if len(soul.stats)!=8: raise BankError("A soul needs eight saved stats.")
        if not soul.type:
            if any(soul.stats): raise BankError("An empty soul must have zero stats in the edit state.")
            continue
        if unchanged:
            for value in soul.stats: integer(value,f"Soul {i} fixed stat",INT_MIN,INT_MAX)
            continue
        cap=caps[soul.type]
        for j,value in enumerate(soul.stats,1):
            maximum=cap*(10 if j==1 else 1)*SCALE if j<=5 else (14*SCALE if j in (6,8) else INT_MAX)
            integer(value,f"Soul {i} stat {j}",0,maximum)
            if j in (6,8) and value%SCALE: raise BankError("Unique effect codes must be whole numbers.")
    for key,value in state.settings.items():
        if key=="skipwavethreshold": integer(value,"Skip-wave threshold",INT_MIN if before and before.settings.get(key)==value else 0,INT_MAX)
        elif key in ("Particles","Visuals","ZealotTaunt"):
            if not isinstance(value,bool): raise BankError("Setting must be a flag.")
        else: raise BankError("Unsupported setting edit.")


def diff(before,after,profile):
    result=[]
    for label,key in (("Kill balance","kills"),("Dust","dust"),("Best solo difficulty","best_solo")):
        a,b=getattr(before,key),getattr(after,key)
        if a!=b: result.append(f"{label}: {a:,} → {b:,}")
    for spec in profile["heroes"]:
        a,b=before.heroes[spec["id"]],after.heroes[spec["id"]]
        for key in ("purchased","xp","level","prestige","ascensions"):
            if getattr(a,key)!=getattr(b,key): result.append(f"{spec['label']} {key}: {getattr(a,key)} → {getattr(b,key)}")
    for i in range(1,7):
        if before.challenges[i]!=after.challenges[i]: result.append(f"Challenge {i}: {before.challenges[i]} → {after.challenges[i]}")
    for i in range(1,101):
        if before.souls[i]!=after.souls[i]: result.append(f"Soul {i}: changed")
    for key,value in after.settings.items():
        if before.settings.get(key)!=value: result.append(f"Setting {key}: {before.settings.get(key)} → {value}")
    return result
