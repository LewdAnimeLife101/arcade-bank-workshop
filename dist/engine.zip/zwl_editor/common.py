"""Shared XML/file utility primitives, without a map-specific codec."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import copy
import hashlib
import json
import os
import re
import sys
import tempfile
import uuid
import xml.etree.ElementTree as ET
from datetime import datetime, timezone

INT_MIN, INT_MAX = -(2**31), 2**31 - 1
HANDLE = re.compile(r"[1-9][0-9]*-S2-[1-9][0-9]*-[1-9][0-9]*\Z")


class BankError(ValueError):
    """A user-actionable bank or validation error."""


def resource_path(relative: str) -> Path:
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent.parent))
    parts = Path(relative).parts
    if parts and parts[0] in ("data", "docs"):
        return base / parts[0] / "liberty" / Path(*parts[1:])
    return base / relative


def load_profile() -> dict:
    return json.loads(resource_path("data/map_profile.json").read_text(encoding="utf-8-sig"))


def integer(value: object, label: str, low: int = 0, high: int = INT_MAX) -> int:
    if isinstance(value, bool) or not re.fullmatch(r"-?[0-9]+", str(value)):
        raise BankError(f"{label}: enter a whole number.")
    try:
        result = int(str(value))
    except ValueError as exc:
        raise BankError(f"{label}: the number is too long.") from exc
    if not low <= result <= high:
        raise BankError(f"{label}: must be between {low:,} and {high:,}.")
    return result


def trunc_div(a: int, b: int) -> int:
    if b == 0:
        raise BankError("The bank's encoding has a zero divisor.")
    return (abs(a) // abs(b)) * (-1 if (a < 0) != (b < 0) else 1)


def checked(value: int) -> int:
    return integer(value, "Encoded integer", INT_MIN, INT_MAX)


def write_bank(destination: Path, payload: bytes, source: Bank, *, replace: bool = False) -> Path | None:
    """Validate first, stage and fsync, back up existing destination, atomic replace.

    Source hash is rechecked immediately before commit. Backups never overwrite.
    Full game/account/profile acceptance is outside this file-I/O guarantee.
    """
    if Path(destination).is_symlink():
        raise BankError("Refusing to replace a symbolic link.")
    destination = Path(destination).resolve()
    if destination.suffix.lower() != ".sc2bank":
        raise BankError("The destination must have the .SC2Bank extension.")
    from .core import Bank
    output = Bank(payload, destination, source.profile, player=source.player)
    if output.errors:
        raise BankError("Refusing invalid output: " + "; ".join(output.errors))
    if source.path and (not source.path.exists() or hashlib.sha256(source.path.read_bytes()).hexdigest() != source.digest):
        raise BankError("The original changed after opening. Reload it before exporting.")
    exists = destination.exists()
    if exists and not replace:
        raise BankError("The destination already exists. Choose a new file or explicitly replace it.")
    if exists and destination.is_symlink():
        raise BankError("Refusing to replace a symbolic link.")
    destination.parent.mkdir(parents=True, exist_ok=True)
    old = destination.read_bytes() if exists else None
    token = uuid.uuid4().hex[:8]
    backup: Path | None = None
    fd, temp_name = tempfile.mkstemp(prefix=".zwu-", suffix=".tmp", dir=destination.parent)
    staged = Path(temp_name)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        if staged.read_bytes() != payload:
            raise BankError("Staged file verification failed.")
        if source.path and hashlib.sha256(source.path.read_bytes()).hexdigest() != source.digest:
            raise BankError("The original changed during export. Reload it.")
        if exists:
            if destination.read_bytes() != old:
                raise BankError("The destination changed during export.")
            stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
            backup = destination.with_name(f"{destination.name}.{stamp}.{token}.bak")
            with backup.open("xb") as stream:
                stream.write(old)
                stream.flush()
                os.fsync(stream.fileno())
            if backup.read_bytes() != old:
                raise BankError("Backup verification failed; the destination was not replaced.")
            os.replace(staged, destination)
        else:
            # Hard link provides atomic creation without clobbering a file that
            # appeared after the existence check (Windows NTFS and POSIX).
            os.link(staged, destination)
            staged.unlink()
        if destination.read_bytes() != payload:
            raise BankError("Output read-back failed. A prior-file backup is available." if backup else "Output read-back failed.")
        return backup
    finally:
        staged.unlink(missing_ok=True)
