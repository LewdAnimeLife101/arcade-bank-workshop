"""Galaxy fixed-point model corroborated against three local bank snapshots.

32-bit wrapping raw values, twelve fractional bits. The proprietary native
SquareRoot is not executed here: unsigned-input integer-root behavior is an
inference that matched all stored checks. Live-game export testing remains
necessary. Decimal parsing uses nearest representable fixed value.
"""
from decimal import Decimal, InvalidOperation, DecimalException, ROUND_HALF_UP
from math import isqrt
from .common import BankError, trunc_div

SCALE = 4096

def wrap32(value: int) -> int:
    return ((value + 2**31) % 2**32) - 2**31

def int_fixed(value: int) -> int:
    return wrap32(value*SCALE)

def parse_fixed(text: str) -> int:
    try:
        value = Decimal(text)
        if not value.is_finite() or value.copy_abs() > Decimal(524288):
            raise BankError("Fixed value is outside the supported range.")
        raw = int((value*SCALE).to_integral_value(rounding=ROUND_HALF_UP))
    except (DecimalException, ValueError, OverflowError) as exc:
        raise BankError("Invalid fixed-point value.") from exc
    if not -(2**31) <= raw < 2**31:
        raise BankError("Fixed value overflows 32 bits.")
    return raw

def format_fixed(raw: int) -> str:
    return format(Decimal(raw)/SCALE, "f")

def divide(a: int, b: int) -> int:
    return wrap32(trunc_div(a*SCALE, b))

def sqrt_raw(raw: int) -> int:
    return isqrt((raw & 0xffffffff)*SCALE)

def root_ratio(raw: int, denominator: int, *, self_denominator=False, ceil_root=False) -> int:
    root = sqrt_raw(raw)
    if ceil_root and root*root != (raw & 0xffffffff)*SCALE:
        root += 1
    divisor = wrap32(denominator + (root if self_denominator else 0))
    return divide(root, divisor)
