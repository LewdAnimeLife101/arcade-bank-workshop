"""Synthetic profile fixture. Contains no personal account or game data."""
import xml.etree.ElementTree as ET
from .core import Bank, State, checks_for
from .fixed import format_fixed

DEMO_PLAYER="1-S2-1-1234567"

def demo_bytes():
    root=ET.Element("Bank",version="1")
    sections={}
    def put(s,k,t,value):
        if s not in sections: sections[s]=ET.SubElement(root,"Section",name=s)
        node=ET.SubElement(sections[s],"Key",name=k)
        ET.SubElement(node,"Value",{t:str(value)})
    state=State(kills=12500,dust=150,best_solo=4)
    for i,h in state.heroes.items():
        h.purchased=i<=3
        h.level=5
        h.xp=25
        put("Purchases",f"H{i}","flag",int(h.purchased))
        for suffix,value,t in (("K",h.xp,"int"),("L",h.level,"int"),("P",h.prestige,"int"),("A",h.ascensions,"string")):
            put("Primary",f"H{i}{suffix}",t,value)
    put("Primary","Primary","int",state.kills)
    put("Primary","BS","int",state.best_solo)
    put("Settings","Ratio","int",state.dust*13)
    put("Settings","Visuals","flag",1)
    put("Settings","Particles","flag",1)
    put("Settings","skipwavethreshold","int",100)
    for (s,k),value in checks_for(state,DEMO_PLAYER).items(): put(s,k,"fixed",format_fixed(value))
    ET.indent(root,space="    ")
    return ET.tostring(root,encoding="utf-8",xml_declaration=True)

def demo_bank():
    return Bank(demo_bytes(),player=DEMO_PLAYER)
