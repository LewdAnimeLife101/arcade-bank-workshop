"""Zombie World Liberty bank editor, audited map 0.233."""
__version__ = "0.1.0"
